﻿// ===============================
// AUTHOR          : Prashanth
// CREATE DATE     : 15/01/17
// PURPOSE         : Extestion methods 
// SPECIAL NOTES   :
// ===============================
// Change History:
//
//==================================
using System;
namespace PMU
{
    public static class TypeCommonExtension
    {
        public static bool IsNumeric(this string str)
        {
            int retValue;
            return int.TryParse(str, out retValue);
        }

        public static string DefaultText(this string str, string text)
        {
            return str.Trim() == "" ? text : str;
        }

        public static int ToInt(this string str)
        {
            int retValue;
            int.TryParse(str, out retValue);
            return retValue;
        }


        public static int ToInt(this object str)
        {
            if (str == DBNull.Value)
            {
                return 0;
            }
            else if (str == null)
            {
                return 0;
            }
            else
            {
                int retValue;
                int.TryParse(str.ToString(), out retValue);
                return retValue;
            }
        }

        public static decimal ToDecimal(this object str)
        {
            if (str == DBNull.Value)
            {
                return 0;
            }
            else
            {
                decimal retValue;
                decimal.TryParse(str.ToString(), out retValue);
                return retValue;
            }
        }
        public static DateTime? ToDateTime(this object str)
        {
            if (str == DBNull.Value)
            {
                return null;
            }
            else if (str == string.Empty)
            {
                return null;
            }
            else
            {
                DateTime retValue;
                DateTime.TryParse(str.ToString(), out retValue);
                return retValue;
            }
        }
        public static DateTime ToDateTimeBasic(this object str)
        {
            if (str == DBNull.Value)
            {
                return System.DateTime.MinValue;
            }
            else if (str == string.Empty)
            {
                return System.DateTime.MinValue;
            }
            else
            {
                DateTime retValue;
                DateTime.TryParse(str.ToString(), out retValue);
                return retValue;
            }
        }


        public static DateTime IsDateTime(this string str)
        {
            DateTime retValue;
            DateTime.TryParse(str, out retValue);
            return retValue;
        }

        public static bool IsEmpty(this string str)
        {
            return str.Trim() == string.Empty;
        }
        public static bool IsNullOrEmpty(this string str)
        {
            return str.Trim() == string.Empty || str == null;
        }

        public static object ToObject(this int? val)
        {
            if (val == null || val == 0)
                return DBNull.Value;
            else
                return val;
        }

        public static object ToObject(this int val)
        {
            if (val == 0)
                return DBNull.Value;
            else
                return val;
        }


        public static object ToDbObject(this string val)
        {
            if (val == null || val == string.Empty)
                return DBNull.Value;
            else
                return val;
        }


        public static object ToDbObject(this DateTime val)
        {
            if (val == null || val == DateTime.MinValue)
                return DBNull.Value;
            else
                return val;
        }

        public static object ToDbObject(this object val)
        {
            if (val == null)
                return DBNull.Value;
            else if (val.ToStr() == string.Empty)
                return DBNull.Value;
            else
                return val;
        }

        public static string ToStr(this object val)
        {
            if (val == DBNull.Value || val == null)
                return "";
            else
                return val.ToString().Trim();
        }

        public static bool ToBoolean(this object val)
        {
            if (val == DBNull.Value)
                return false;
            else if (val.ToString().ToLower() == "false" || val.ToString() == "0")
                return false;
            else
                return true;
        }

        public static char ToChar(this bool val)
        {
            if (val)
                //return '1';
                return 'Y';
            else
                //return '0';
                return 'N';
        }
        public static char ToCharBasic(this object val)
        {
            if (val == null || val == DBNull.Value || val.ToStr() == string.Empty)
                return ' ';
            else
                return val.ToStr().ToCharArray()[0];
        }
        public static System.Collections.IDictionary ToDictionary(this object obj)
        {
            System.Collections.Generic.Dictionary<string, object> objDescr = new System.Collections.Generic.Dictionary<string, object>();

            foreach (System.ComponentModel.PropertyDescriptor descriptor in System.ComponentModel.TypeDescriptor.GetProperties(obj))
            {
                objDescr.Add(descriptor.Name, descriptor.GetValue(obj));
            }
            return objDescr;
        }
        public static void SafeDispose(this IDisposable obj)
        {
            if (obj != null)
                obj.Dispose();
        }

        public static string ToPhoneNumberFormat(this string obj)
        {
            if (obj != null && obj != string.Empty && obj.Length >= 10)
            {
                obj = obj.Insert(3, "-");
                obj = obj.Insert(7, "-");
            }
            return obj;
        }
        public static string ToDatetimeddmmyyyy(this object obj)
        {
            if (obj == DBNull.Value || obj == null || Convert.ToString(obj) == string.Empty)
                return null;
            else
                return Convert.ToString(Convert.ToDateTime(obj).ToString("dd-MMM-yyyy"));
        }
        public static string ToDatetimemmddyyyy(this object obj)
        {
            if (obj == DBNull.Value || obj == null)
                return null;
            else
                return Convert.ToString(Convert.ToDateTime(obj).ToString("MM/dd/yyyy"));
        }

        //public static object ToEmptyToNull(this int val)
        //{
        //    if (val() == string.Empty)
        //        return DBNull.Value;
        //    else
        //        return val;
        //}
    }
}