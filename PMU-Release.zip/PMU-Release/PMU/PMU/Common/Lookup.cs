﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public static class PropertyLookup
    {
        public const string SectorList = "SectorList";
        public const string SectorTypeList = "Manufacturing/Service";
        public const string SubSectorList = "SubSectorList";
        public const string JobRoleList = "JobRoleList";
        public const string GetCertificateTemplateTypeList = "CertificateTemplate";
        public const string GetDisbursementModeTypeList = "Mode Of Disbursement";
        //public const string GetDisbursementModeTypeList = "DisbursementMode";
        //public const string GetPlacementApplicableDisbursmentList = "PlacementDisbursement";
        public const string GetPlacementApplicableDisbursmentList = "Applicable for Placement Disbursement";
        public const string GetTrainingPartnerTypeList = "GetTrainingPartnerTypeList";
        public const string GetTrainingTypes = "Training Type";
        public const string GetProjectType = "Project Type";
        public const string ProjectType = "ProjectType";
        public const string VerficationStatus = "Batch Approval Status";
        public const string ReasonVerificationStatus = "Reason Verification Status";
    }
    public static class TabLookup
    {
        public const string CandidateDetails = "Candidate Details";
        public const string CandidateInformation = "Candidate Information";
        public const string RPLProjectType = "RPL Project Type";
        public const string ProjectDetails = "Project Details"; 
    }

    public static class Lookup
    {
        public const string RozgarMela = "Rozgar Mela";
        public const string PlacementOfficerPortal = "Organization Type";
        public const string Officials = "Officials";
        public const string EmployerType = "Type Of Employer";
        public const string Employer = "Employer";
        public const string WageEmploymentProof = "TypeofDocumentProofWageEmployment";
        public const string SelfEmploymentProof = "TypeofDocumentProofSelfEmployment";
        public const string Training = "Training Type";
    }

}