﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web;
namespace PMU
{
    [Serializable]
    public static class SessionMgr
    {
        public static int? ProjectID
        {
            get
            {
                if (HttpContext.Current.Session["ProjectID"] == null)
                {
                    HttpContext.Current.Session["ProjectID"] = 0;
                }
                return (int)HttpContext.Current.Session["ProjectID"];
            }
            set
            {
                HttpContext.Current.Session["ProjectID"] = value;
            }
        }
        

       public static string TrainingPartner
        {
            get
            {
                if (HttpContext.Current.Session["TrainingPartner"] == null)
                {
                    HttpContext.Current.Session["TrainingPartner"] =string.Empty;
                }
                return (string)HttpContext.Current.Session["TrainingPartner"];
            }
            set
            {
                HttpContext.Current.Session["TrainingPartner"] = value;
            }
        }

        public static int? PartnerID
        {
            get
            {
                if (HttpContext.Current.Session["PartnerID"] == null)
                {
                    HttpContext.Current.Session["PartnerID"] = 0;
                }
                return (int)HttpContext.Current.Session["PartnerID"];
            }
            set
            {
                HttpContext.Current.Session["PartnerID"] = value;
            }
        }

        public static string TrainingType
        {
            get
            {
                if (HttpContext.Current.Session["TrainingType"] == null)
                {
                    HttpContext.Current.Session["TrainingType"] = string.Empty;
                }
                return (string)HttpContext.Current.Session["TrainingType"];
            }
            set
            {
                HttpContext.Current.Session["TrainingType"] = value;
            }
        }

        public static int? TrainingTypeID
        {
            get
            {
                if (HttpContext.Current.Session["TrainingTypeID"] == null)
                {
                    HttpContext.Current.Session["TrainingTypeID"] =0;
                }
                return (int)HttpContext.Current.Session["TrainingTypeID"];
            }
            set
            {
                HttpContext.Current.Session["TrainingTypeID"] = value;
            }
        }

        public static int LocationCount
        {
            get
            {
                if (HttpContext.Current.Session["LocationCount"] == null)
                {
                    HttpContext.Current.Session["LocationCount"] = 0;
                }
                return (int)HttpContext.Current.Session["LocationCount"];
            }
            set
            {
                HttpContext.Current.Session["LocationCount"] = value;
            }
        }

        public static UserModel LoginUserDetails
        {
            get
            {
                if (HttpContext.Current.Session["UserModel"] == null)
                {
                    HttpContext.Current.Session["UserModel"] = new UserModel();
                }
                return (UserModel)HttpContext.Current.Session["UserModel"];
            }
            set
            {
                HttpContext.Current.Session["UserModel"] = value;
            }
        }

        public static IList<Location> LocationList
        {
            get
            {
                if (HttpContext.Current.Session["LocationList"] == null)
                {
                    HttpContext.Current.Session["LocationList"] = new List<Location>();
                }
                return (List<Location>)HttpContext.Current.Session["LocationList"];
            }
            set
            {
                HttpContext.Current.Session["LocationList"] = value;
            }
        }

        public static IList<TrainingLocations> TrainingLocationsList
        {
            get
            {
                if (HttpContext.Current.Session["TrainingLocationsList"] == null)
                {
                    HttpContext.Current.Session["TrainingLocationsList"] = new List<TrainingLocations>();
                }
                return (List<TrainingLocations>)HttpContext.Current.Session["TrainingLocationsList"];
            }
            set
            {
                HttpContext.Current.Session["TrainingLocationsList"] = value;
            }
        }

        public static IList<ProjectJobRole> ProjectJobRole
        {
            get
            {
                if (HttpContext.Current.Session["ProjectJobRole"] == null)
                {
                    HttpContext.Current.Session["ProjectJobRole"] = new List<ProjectJobRole>();
                }
                return (List<ProjectJobRole>)HttpContext.Current.Session["ProjectJobRole"];
            }
            set
            {
                HttpContext.Current.Session["ProjectJobRole"] = value;
            }
        }

        public static IList<ManageContacts> ManageContacts
        {
            get
            {
                if (HttpContext.Current.Session["ManageContacts"] == null)
                {
                    HttpContext.Current.Session["ManageContacts"] = new List<ManageContacts>();
                }
                return (List<ManageContacts>)HttpContext.Current.Session["ManageContacts"];
            }
            set
            {
                HttpContext.Current.Session["ManageContacts"] = value;
            }
        }
    }
}