﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text;
using PMU.Infrastructure;
using PMU.Models;

namespace PMU.Controllers
{
    public class AccountController : Controller
    {
        // GET: ChangePassword
        string _candId = string.Empty;
        DbAction _dba = new DbAction();
        string _candidateId = string.Empty;

        [HttpGet]
        public ActionResult ChangePassword()
        {
            string value = Convert.ToString(Session["45daylogin"]);

            ViewBag.myVar = value;

            string changepwd = Convert.ToString(Session["45daypwdchange"]);
            ViewBag.pwdchange = changepwd;

            ChangePassword alert = new ChangePassword();
            alert.MessageAlert = "";
            return View(alert);
        }

        [HttpPost]
        public ActionResult ChangePassword(ChangePassword changepwd)
        {
            var user = SessionMgr.LoginUserDetails;//(UserModel)Session["UserModel"];
            string message = "";
            string oldpassword = changepwd.OldPassword;
            string newpassword = changepwd.ConfirmPassword;
            string confpwd = changepwd.NewPassword;

            Encryption encrypt = new Encryption();

            string encryptedOldPassword = Encryption.EncryptPassword(oldpassword);

            string encryptedPassword = Encryption.EncryptPassword(newpassword);

            DataTable dt = _dba.ChangePassword(encryptedOldPassword, encryptedPassword, user.UserId, user.Username);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    message = dt.Rows[i][0].ToString();
                    //if (message == "Password changed succesfully.")
                    if (message == "Password has been changed succesfully.")
                    {
                        changepwd.MessageAlert = "Emailsent";
                        Session.Abandon();
                        return View(changepwd);
                    }
                    else if (message == "Old password and new password should not be same.")
                    {
                        ViewBag.Validation = "Old password and new password should not be same.";
                        return View(changepwd);
                    }
                    else if (message == "Old password entered is incorrect.")
                    {
                        ViewBag.Validation = "Old password entered is incorrect.";
                        return View(changepwd);
                    }
                }
            }
            else
            {
                ViewBag.Validation = "Old password entered is incorrect.";
                return View(changepwd);
            }
            return View(changepwd);
        }

        public ActionResult LoginExpire(string UserName)
        {
            string value = Convert.ToString(Session["45daylogin"]);
            ViewBag.myVar = value;
            string changepwd = Convert.ToString(Session["45daypwdchange"]);
            ViewBag.pwdchange = changepwd;
            ChangePassword changePassword = new ChangePassword();
            changePassword.CandidateID = UserName;
            changePassword.MessageAlert = "";
            return View(changePassword);
        }

        [HttpPost]
        public ActionResult LoginExpire(ChangePassword changepwd)
        {
            string message = "";
            string oldpassword = changepwd.OldPassword;
            string newpassword = changepwd.ConfirmPassword;
            string confpwd = changepwd.NewPassword;

            Encryption encrypt = new Encryption();

            string encryptedOldPassword = Encryption.EncryptPassword(oldpassword);

            string encryptedPassword = Encryption.EncryptPassword(newpassword);

            DataTable dt = _dba.ChangeExpiredPassword(encryptedOldPassword, encryptedPassword, changepwd.CandidateID);

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    message = dt.Rows[i][0].ToString();
                    //if (message == "Password changed succesfully.")
                    if (message == "Password has been changed succesfully.")
                    {
                        changepwd.MessageAlert = "Emailsent";
                        Session.Abandon();
                        return View(changepwd);
                    }
                    else if (message == "Old password and new password should not be same.")
                    {
                        ViewBag.Validation = "Old password and new password should not be same.";
                        return View(changepwd);
                    }
                    else if (message == "Old password entered is incorrect.")
                    {
                        ViewBag.Validation = "Old password entered is incorrect.";
                        return View(changepwd);
                    }
                }
            }
            else
            {
                ViewBag.Validation = "Old password entered is incorrect.";
                return View(changepwd);
            }
            return View(changepwd);
        }

      

        // GET: ForgotPassword
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            ForgotPassword alert = new ForgotPassword();
            alert.MessageAlert = "";
            return View(alert);
        }
        [HttpPost]
        public ActionResult ForgotPassword(ForgotPassword forgotPasswordObj)
        {
            string subject = ConfigurationManager.AppSettings["Subject"];
            string url = ConfigurationManager.AppSettings["URL"];
            string message = "";
            if (ModelState.IsValid)
            {
                try
                {
                    string uName = forgotPasswordObj.ContactCode;
                    DataTable reader = _dba.CheckUserID(uName);
                    if (reader.Rows.Count > 0)
                    {
                        string flag = reader.Rows[0]["Column1"].ToString();
                        var userId = reader.Rows[0]["UserID"].ToString();
                        string encryptednId = Utility.ConvertStringToHex(userId, System.Text.Encoding.Unicode);
                        MailMessage mail = new MailMessage();

                        ModelState.Clear();
                        if (flag == "Confirmation Email sent.")
                        {
                            string candName;
                            if (!reader.Rows[0].IsNull("Fullname") && !string.IsNullOrEmpty(reader.Rows[0]["Fullname"].ToString()))
                                candName = Convert.ToString(reader.Rows[0]["Fullname"]);
                            else
                                candName = "User";

                            if (!reader.Rows[0].IsNull("Email") && !string.IsNullOrEmpty(reader.Rows[0]["Email"].ToString()))
                                mail.To.Add(Convert.ToString(reader.Rows[0]["Email"]));

                            Session["Email"] = Convert.ToString(reader.Rows[0]["Email"]);
                            mail.Subject = subject;
                            StringBuilder Body = new StringBuilder();
                            Body.Append("Dear ")
                                .Append(candName)
                                .Append(",<br/><br/>Please click on the below url to reset your password to login to SDMS Portal for PMU.<br/><br/>")
                                .Append(url + encryptednId)
                                .Append("<br/><br/>The link will be valid for next 24 hours.")
                                .Append("If you have any questions, please raise a support ticket in JIRA (https://nsdcsupport.atlassian.net/servicedesk/customer/portal/10).")
                                .Append("<br/><br/>Thanks, <br/> NSDC SDMS Team");

                            string From = ConfigurationManager.AppSettings["From"].ToString();
                            string Pwd = ConfigurationManager.AppSettings["Pwd"].ToString();
                            mail.Body = Body.ToString();
                            mail.IsBodyHtml = true;
                            mail.From = new MailAddress(From);
                            SmtpClient smtp = new SmtpClient();
                            smtp.Host = ConfigurationManager.AppSettings["Host"].ToString();
                            smtp.Credentials = new System.Net.NetworkCredential(From, Pwd);
                            smtp.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"].ToString());
                            smtp.EnableSsl = true;
                            smtp.Send(mail);
                            //string nowtime = currenttime;
                            for (int i = 0; i < reader.Rows.Count; i++)
                            {
                                message = reader.Rows[i][0].ToString();
                                if (message == "Confirmation Email sent.")
                                {
                                    forgotPasswordObj.MessageAlert = "Emailsent";
                                    //-------SMS Notification-------//
                                    string msgBody = ConfigurationManager.AppSettings["ForgotPwdSuceessOTP"] + Convert.ToString(reader.Rows[0]["Email"]);
                                    Logger.LogMessage("ForgotPasswordSMS msgBody:" + msgBody + '/' + userId);
                                    //string MobileNo = "888453395";
                                    string mobileNo = Convert.ToString(reader.Rows[0]["CentreMobile"]);
                                    if (!string.IsNullOrEmpty(mobileNo))
                                        Utility.SendShortMessage(mobileNo, msgBody);
                                    //-------SMS Notification-------//
                                    return View(forgotPasswordObj);
                                    //Session.Abandon();
                                }
                            }
                        }
                        else
                        {
                            for (int i = 0; i < reader.Rows.Count; i++)
                            {
                                message = reader.Rows[i][0].ToString();
                            }

                            if (message == "Confirmation Email sent.")
                            {
                                forgotPasswordObj.MessageAlert = "Emailsent";
                                return View(forgotPasswordObj);
                            }
                            else if (message == "Reset link already sent.")
                            {
                                forgotPasswordObj.Confirmation = "alreadysent";
                                return View(forgotPasswordObj);
                            }
                            else if (message == "User Does Not Exists.")
                            {
                                ViewBag.Validation = "User Does Not Exists.";
                                return View(forgotPasswordObj);
                            }
                            forgotPasswordObj.MessageAlert = message;
                        }
                    }
                }

                catch (SqlException ex)
                {
                    ViewBag.Validation = "User Does Not Exists.";
                }
                catch (Exception ex)
                {
                    ViewBag.Validation = "User Does Not Exists.";
                }
            }
            return View(forgotPasswordObj);
        }

        [HttpGet]
        public ActionResult ForgotPasswordReset(string nID)
        {
            ForgotPasswordReset forgotobj = new ForgotPasswordReset();
            forgotobj.CandidateID = ConvertHexToString(nID, System.Text.Encoding.Unicode);
            string decryptedpassword = forgotobj.CandidateID;
            DataTable dt = new DataTable();
            dt = _dba.CheckRequestPasswordChange(decryptedpassword);
            string flag = dt.Rows[0]["Column1"].ToString();
            _candidateId = decryptedpassword;
            HttpCookie MyCookie = new HttpCookie("Background");
            MyCookie.Value = _candidateId;
            Response.Cookies.Add(MyCookie);
            return View(forgotobj);
        }

        [HttpPost]
        public ActionResult ForgotPasswordReset(ForgotPasswordReset forgotobj)
        {
            string message = "";
            var httpCookie = Request.Cookies["Background"];
            if (httpCookie != null)
            {
                var userId = Convert.ToInt32(httpCookie.Value);
                var password = Encryption.EncryptPassword(forgotobj.Password);
                DataTable dt = _dba.SaveNewPassword(password, userId);

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        message = dt.Rows[i][0].ToString();
                        if (message == "Password has been changed succesfully.")
                        {
                            forgotobj.MessageAlert = "Emailsent";
                            return View(forgotobj);
                        }
                        else if (message == "Old password and new password should not be same.")
                        {
                            ViewBag.MyVar = "Old password and new password should not be same.";
                        }
                    }
                }
            }
            return View(forgotobj);
        }

        public static string ConvertHexToString(String hexInput, System.Text.Encoding encoding)
        {
            int numberChars = hexInput.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hexInput.Substring(i, 2), 16);
            }
            return encoding.GetString(bytes);
        }
    }
}