﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMU.Infrastructure;
using PMU.Models;
using PMU.Repository;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using PMU.Model;

namespace PMU.Controllers
{
    [SessionExpire]
    public class BatchController : Controller
    {
        private DbAction dbAction = new DbAction();

        public ActionResult ApprovedBatch()
        {
            ManageBatchViewModel viewModel = new ManageBatchViewModel();

            DataTable dt = new DataTable();
            var dlldata = new List<DropDownDDL>();
            dt = dbAction.Get_BatchStatusApproved();
            dlldata.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });
            viewModel.BatchStatusAprList = dlldata;
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL dropcan = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["DropDownID"]),
                        tDisplayName = dt.Rows[i]["DropDownValue"].ToString()
                    };
                    dlldata.Add(dropcan);
                }
            }
            viewModel.BatchStatusAprList = dlldata;

            //For jobrole ddl
            var jobroledlldata = new List<DropDownDDL>();
            dt = dbAction.Get_ApprovedBatchJobRole();
            jobroledlldata.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });
            viewModel.JobRoleList = jobroledlldata;
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL jobrole = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["JobRoleID"]),
                        tDisplayName = dt.Rows[i]["JobRole"].ToString()
                    };
                    jobroledlldata.Add(jobrole);
                }
            }
            viewModel.JobRoleList = jobroledlldata;

            return View(viewModel);
        }

        public JsonResult GetApprovedBatch(string approvedStatus, string jobRole)
        {
            var user = SessionMgr.LoginUserDetails;
            var viewModel = new ManageBatchViewModel();
            DataTable dt = new DataTable();
            viewModel.ManageBatchList = new List<ManageBatch>();

            dt = dbAction.GetViewApprovedBatchList(approvedStatus, user.ContactId.ToStr(), user.CentreId.ToStr());
            foreach (DataRow dr in dt.Rows)
            {
                ManageBatch manageBatch = new ManageBatch();
                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchName"])))
                {
                    manageBatch.BatchName = dr["BatchName"] as string;
                }
                else
                {
                    manageBatch.BatchID = 0;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["SmartCentreBatchID"])))
                {
                    manageBatch.SmartCentreBatchID = Convert.ToInt32(dr["SmartCentreBatchID"]);
                    if (manageBatch.SmartCentreBatchID > 0)
                    {
                        int pending, ImageCount, pendingCount;
                        List<BatchAssetPartialModel1> imgVerifiedList;
                        DataTable stsList, batchStatusList;
                        List<DropDownDDL> photoVerificationStatus;

                        stsList = dbAction.PhotoVerificationStatusList();
                        photoVerificationStatus = ListVerificationStatus(stsList);
                        pending = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Pending.ToString()).nIndex ?? 0;
                        batchStatusList = dbAction.GetBatchByBatchID(Convert.ToInt32(manageBatch.SmartCentreBatchID));
                        imgVerifiedList = ListVerifiedImages(batchStatusList);

                        ImageCount = imgVerifiedList.Count();
                        pendingCount = imgVerifiedList.FindAll(a => (a.VerificationStatus == pending)).Count();

                        if (ImageCount > 0)
                        {
                            if (ImageCount >= pendingCount && pendingCount == 0)
                                manageBatch.AssetVerificationStatus = VerificationStatus.Verified.ToString();
                            else
                                manageBatch.AssetVerificationStatus = VerificationStatus.Pending.ToString();
                        }
                        else
                            manageBatch.AssetVerificationStatus = "No Assets Yet";
                    }
                }

                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchStartDate"])))
                {
                    manageBatch.BatchStartDate = Convert.ToDateTime(dr["BatchStartDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.BatchStartDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchEndDate"])))
                {
                    manageBatch.BatchEndDate = Convert.ToDateTime(dr["BatchEndDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.BatchEndDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["PreferedAssessmentDate"])))
                {
                    manageBatch.PreferedAssessmentDate = Convert.ToDateTime(dr["PreferedAssessmentDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.PreferedAssessmentDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["JobRole"])))
                {
                    manageBatch.Jobrole = (string)dr["JobRole"];
                }
                else
                {
                    manageBatch.Jobrole = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["TrainerName"])))
                {
                    manageBatch.TrainerName = (string)dr["TrainerName"];
                }
                else
                {
                    manageBatch.TrainerName = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["EnrolledCandidates"])))
                {
                    manageBatch.TotalCandidatesinBatch = (int)dr["EnrolledCandidates"];
                }
                else
                {
                    manageBatch.TotalCandidatesinBatch = 0;
                }
                viewModel.ManageBatchList.Add(manageBatch);
                Logger.LogMessage("GetApprovedBatch ManageBatchList Count:" + viewModel.ManageBatchList.Count);
            }

            if (!string.IsNullOrEmpty(jobRole))
            {
                viewModel.ManageBatchList = viewModel.ManageBatchList.FindAll(a => a.Jobrole == jobRole);
            }

            return Json(viewModel.ManageBatchList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ViewEnrollcandidateDetails(string batchId)
        {
            var viewModel = new CandidateEnrollmentViewModel();
            var user = SessionMgr.LoginUserDetails;
            DataSet ds = new DataSet();
            ds = dbAction.GetEnrollCandiadateList(batchId, user.CentreId.ToStr());

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string SCBatchID = Convert.ToString(dr["SmartCentreBatchID"]);
                Session["SmartCentreBatchID"] = SCBatchID;
                //viewModel.BatchId = Convert.ToString(dr["BatchID"]);
                viewModel.BatchName = Convert.ToString(dr["BatchName"]);
                viewModel.BatchStartDate = Convert.ToDateTime(dr["BatchStartDate"]).ToString("dd-MMM-yyyy");
                viewModel.BatchEndDate = Convert.ToDateTime(dr["BatchEndDate"]).ToString("dd-MMM-yyyy");
                viewModel.PreferedAssessmentDate = Convert.ToDateTime(dr["PreferedAssessmentDate"]).ToString("dd-MMM-yyyy");
                viewModel.Trainer = Convert.ToString(dr["TrainerName"]);
                viewModel.EnrolledSoFar = Convert.ToInt32(dr["Enroled"]);
                viewModel.EnrolmentClosureDate = Convert.ToDateTime(dr["EnrolmentClosureDate"]).ToString("dd-MMM-yyyy");
                viewModel.Approvalstatus = Convert.ToString(dr["BatchApprovalStatus"]);
                viewModel.EnrolmentRemaining = Convert.ToString(dr["EnrolmentRemaining"]);
            }
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                viewModel.Scheme = Convert.ToString(row["SchemeName"]);
                viewModel.TrainingType = Convert.ToString(row["TrainingType"]);
                //viewModel.ProjectType = row["ProjectType"]==DBNull.Value? "": Convert.ToString(row["ProjectType"]);
                //viewModel.Sector = Convert.ToString(row["SSCName"]);
                viewModel.Sector = Convert.ToString(row["SectorName"]);
                viewModel.SubSector = Convert.ToString(row["SubSectorName"]);
                viewModel.JobRole = Convert.ToString(row["JobRole"]);
                viewModel.JobRoleDurationInHours = Convert.ToString(row["Duration"]);
                viewModel.Batch_size = Convert.ToString(row["BatchSize"]);
                viewModel.HasBridgeCourse = row["HasBridgeCourse"] == DBNull.Value ? false : Convert.ToBoolean(row["HasBridgeCourse"]);
                viewModel.BridgeCourseHours = row["BridgeCourseHours"] == DBNull.Value ? 0 : Convert.ToDecimal(row["BridgeCourseHours"]);
            }
            RegisteredCandidate regCandidate;
            viewModel.EnrolledCandidatesList = new List<RegisteredCandidate>();
            foreach (DataRow dr in ds.Tables[3].Rows)
            {
                regCandidate = new RegisteredCandidate();
                //regCandidate.BatchId = Convert.ToInt32(BatchId);
                regCandidate.BatchName = Convert.ToString(batchId);
                regCandidate.CandidateId = Convert.ToString(dr["CandID"]);
                regCandidate.CentreCandID = Convert.ToString(dr["CentreCandID"]);
                regCandidate.CandidateName = Convert.ToString(dr["CandidateName"]);
                regCandidate.Gender = Convert.ToString(dr["Gender"]);
                regCandidate.RegistrationDate =  Convert.ToDateTime(dr["DateofRegistration"]).ToString("dd-MMM-yyyy");  //Convert.ToString(dr["DateofRegistration"]);
                regCandidate.AadharVerificationStatus = Convert.ToString(dr["AadhaarVerificationStatus"]);
                regCandidate.AlternateIdVerificationStatus = Convert.ToString(dr["AlternateIDVerificationStatus"]);
                regCandidate.MobileNoExists = Convert.ToString(dr["MobileNumberExistsinsystem"]);
                regCandidate.MobileOTPStatus = Convert.ToString(dr["MobileOTPVerificationStatus"]);
                regCandidate.EligibleForDisbursement = Convert.ToString(dr["EligibleforDisbursement"]);
                regCandidate.EligibleForEnrollment = Convert.ToString(dr["EligibleForEnrolment"]);
                regCandidate.count = ds.Tables[2].Rows.Count;
                viewModel.EnrolledCandidatesList.Add(regCandidate);
            }
            return View(viewModel);
        }

        private List<DropDownDDL> ListVerificationStatus(DataTable dt)
        {
            var photoVerificationStatus = new List<DropDownDDL>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL varificationStatus = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["DropDownID"]),
                        tDisplayName = dt.Rows[i]["DropDownValue"].ToString(),
                    };
                    photoVerificationStatus.Add(varificationStatus);
                }
            }

            return photoVerificationStatus;
        }

        private List<BatchAssetPartialModel1> ListVerifiedImages(DataTable dt)
        {
            List<BatchAssetPartialModel1> VerifiedImgList = new List<BatchAssetPartialModel1>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BatchAssetPartialModel1 varificationImg = new BatchAssetPartialModel1()
                    {
                        ImageName = dt.Rows[i]["ImageName"].ToString(),
                        Description = dt.Rows[i].IsNull("Description") ? string.Empty : dt.Rows[i]["Description"].ToString(),
                        VerificationStatus = Convert.ToInt32(dt.Rows[i]["VerificationStatus"]),
                        VerifiedBy = dt.Rows[i].IsNull("VerifiedBy") ? 0 : Convert.ToInt32(dt.Rows[i]["VerifiedBy"]),
                        TCUserID = Convert.ToInt32(dt.Rows[i]["TC_UserID"]),
                        TimeString = Convert.ToString(dt.Rows[i]["UploadTime"]),
                        Date = dt.Rows[i].IsNull("Date") ? (DateTime?)null : Convert.ToDateTime(dt.Rows[i]["Date"]),
                        GuestOfHonor = dt.Rows[i].IsNull("GuestOfHounour") ? string.Empty : dt.Rows[i]["GuestOfHounour"].ToString(),
                        GuestOfHonorType = dt.Rows[i].IsNull("GuestOfHounourType") ? 0 : Convert.ToInt32(dt.Rows[i]["GuestOfHounourType"])
                    };
                    VerifiedImgList.Add(varificationImg);
                }
            }

            return VerifiedImgList;
        }

        private void BatchAssetImageList(CandidateEnrollmentViewModel viewModel, string BatchId, string BatchPhotoattach)
        {
            if (Directory.Exists(BatchPhotoattach))
            {
                int pending, Approved;
                string fileName = string.Empty;
                string name = string.Empty;
                var files = Directory.EnumerateFiles(BatchPhotoattach, "*.*", SearchOption.AllDirectories);
                var ImageList = new List<BatchAssetPartialModel1>();

                DataTable stsList = dbAction.PhotoVerificationStatusList();
                List<DropDownDDL> photoVerificationStatus = ListVerificationStatus(stsList);

                pending = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Pending.ToString()).nIndex ?? 0;
                Approved = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Verified.ToString()).nIndex ?? 0;

                DataTable batchStatusList = dbAction.GetBatchByBatchID(Convert.ToInt32(BatchId));
                List<BatchAssetPartialModel1> imgVerifiedList = ListVerifiedImages(batchStatusList);
                viewModel.ImageCount = imgVerifiedList.Count();
                imgVerifiedList = imgVerifiedList.FindAll(a => (a.VerificationStatus == pending || a.VerificationStatus == Approved));

                foreach (var item in files)
                {
                    name = item;
                    fileName = Path.GetFileName(name);
                    FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    br.Close();
                    fs.Close();

                    DataTable dtUpload = new DataTable("Attachments");
                    DataColumn dc = new DataColumn("1");
                    dc.DataType = System.Type.GetType("System.Byte[]");
                    dtUpload.Columns.Add(dc);

                    DataRow dr = dtUpload.NewRow();
                    dr["1"] = bytes;
                    dtUpload.Rows.Add(dr);

                    string image = "data:image/png;base64," + Convert.ToBase64String((byte[])dtUpload.Rows[0][0]);

                    if (imgVerifiedList.Exists(a => a.ImageName == fileName))
                    {
                        BatchAssetPartialModel1 res = imgVerifiedList.Find(a => a.ImageName == fileName);
                        ImageList.Add(new BatchAssetPartialModel1
                        {
                            image = image,
                            ImageName = fileName,
                            Description = res.Description,
                            Date = res.Date,
                            GuestOfHonor = res.GuestOfHonor,
                            GuestOfHonorType = res.GuestOfHonorType,
                            TimeString = res.TimeString,
                            Verfication = photoVerificationStatus.Find(a => a.nIndex == res.VerificationStatus).tDisplayName
                        });
                    }
                }
                viewModel.BatchName = BatchId;
                viewModel.ImageList = ImageList;
            }
        }

    }
}


