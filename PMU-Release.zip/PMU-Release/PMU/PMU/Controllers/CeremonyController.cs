﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMU.Infrastructure;
using PMU.Models;
using PMU.Repository;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Transactions;
using PMU.Model;

namespace PMU.Controllers
{

    [SessionExpire]
    public class CeremonyController : Controller
    {
        // GET: Ceremony
        private DbAction dbAction = new DbAction();

        public ActionResult DisplayAssessedBatches()
        {
            DispalyAssessedBatch viewModel = new DispalyAssessedBatch();

            // set DropDown values from Taxonomy for Ceremony status
            DataTable dt = new DataTable();
            var dlldata = new List<DropDownDDL>();
            dt = dbAction.CeremonyStatusList();
            dlldata.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL dropcan = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["DropDownID"]),
                        tDisplayName = dt.Rows[i]["DropDownValue"].ToString()
                    };
                    dlldata.Add(dropcan);
                }
            }
            viewModel.CeremonyStatusList = dlldata;
            viewModel.CeremonyStatus = TempData["CeremonyStatus"].ToStr();
            viewModel.FromDate = TempData["AssessfrmDate"].ToStr();
            viewModel.ToDate = TempData["AssesstoDate"].ToStr();
            viewModel.TrainingPartnerName = TempData["trainingPartner"].ToStr();
            viewModel.BatchName = TempData["batchesList"].ToStr();
           if (!string.IsNullOrEmpty(viewModel.FromDate))
            {
                viewModel.IsBack = "true";
            }
           else
            {
                viewModel.IsBack = "false";
            }
            return View(viewModel);
        }

        public ActionResult CertificationCeremony(string batchId,string AssessfrmDate, string AssesstoDate, string CeremonyStatus, string trainingPartner,string batchesList)
        {
            var viewModel = new CandidateEnrollmentViewModel();
            DataSet ds = new DataSet();
            var TCemail = string.Empty;
            TempData["AssessfrmDate"] = AssessfrmDate;
            TempData["AssesstoDate"] = AssesstoDate;
            TempData["CeremonyStatus"] = CeremonyStatus;
            TempData["trainingPartner"] = trainingPartner;
            TempData["batchesList"] = batchesList;
            if (string.IsNullOrEmpty(batchId))
            {
                if (!string.IsNullOrEmpty(Convert.ToString(Session["SmartCentreBatchID"])))
                {
                    batchId = Session["SmartCentreBatchID"].ToString();
                }
                else
                {
                    return RedirectToAction("DisplayAssessedBatches");
                }
            }
            ds = dbAction.GetCeremonyStatusList(batchId);

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string SCBatchID = Convert.ToString(dr["SmartCentreBatchID"]);
                Session["SmartCentreBatchID"] = SCBatchID;
                viewModel.CeremonyStatus = Convert.ToInt32(dr["CeremonyStatus"].ToString());
                Session["CeremonyStatus"] = viewModel.CeremonyStatus;
                viewModel.BatchName = Convert.ToString(dr["BatchName"]);
                TCemail = Convert.ToString(dr["TCEmail"]);
                Session["CentreEmail"] = TCemail.ToString();

                //For Batch Ceremony status Display
                viewModel.ReasonForRejection = string.IsNullOrEmpty(Convert.ToString(dr["ReasonForRejection"])) ? (int?)null : Convert.ToInt32(dr["ReasonForRejection"]);
                viewModel.RejectionDescription = string.IsNullOrEmpty(Convert.ToString(dr["RejectionDescription"])) ? string.Empty : Convert.ToString(dr["RejectionDescription"]);
                viewModel.Remarks = string.IsNullOrEmpty(Convert.ToString(dr["Remarks"])) ? string.Empty : Convert.ToString(dr["Remarks"]);
                viewModel.CeremonyText = string.IsNullOrEmpty(Convert.ToString(dr["ceremonyText"])) ? string.Empty : Convert.ToString(dr["ceremonyText"]);
                viewModel.ReasonText = string.IsNullOrEmpty(Convert.ToString(dr["ReasonText"])) ? string.Empty : Convert.ToString(dr["ReasonText"]);

            }
            foreach (DataRow row in ds.Tables[1].Rows)
            {
                viewModel.JobRole = Convert.ToString(row["JobRole"]);
            }
            RegisteredCandidate regCandidate;
            viewModel.EnrolledCandidatesList = new List<RegisteredCandidate>();
            foreach (DataRow dr in ds.Tables[2].Rows)
            {
                regCandidate = new RegisteredCandidate();
                regCandidate.BatchName = Convert.ToString(batchId);
                regCandidate.CandidateId = Convert.ToString(dr["CandID"]);
                regCandidate.CentreCandID = Convert.ToString(dr["CentreCandID"]);
                regCandidate.CandidateName = Convert.ToString(dr["CandidateName"]);
                regCandidate.Grade = dr.IsNull("Grade") ? "-" : Convert.ToString(dr["Grade"]);
                regCandidate.Result = dr.IsNull("ResultText") ? "" : Convert.ToString(dr["ResultText"]);
                regCandidate.count = ds.Tables[2].Rows.Count;
                viewModel.EnrolledCandidatesList.Add(regCandidate);
            }
            DataTable dt = new DataTable();
            dt = dbAction.GetGuestOfHonourDDL();
            var dlldata = new List<DropDownDDL>();
            dlldata.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL dropcan = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["DropDownID"]),
                        tDisplayName = dt.Rows[i]["DropDownValue"].ToString()
                    };
                    dlldata.Add(dropcan);
                }
            }
            viewModel.UploadImage.GuestOfHonorTypeList = dlldata;

            DataTable dataT = new DataTable();
            dataT = dbAction.GetReasonForRejectionDDL();
            var Reasondata = new List<DropDownDDL>();
            Reasondata.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });
            if (dataT.Rows.Count > 0)
            {
                for (int i = 0; i < dataT.Rows.Count; i++)
                {
                    DropDownDDL dropcan = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dataT.Rows[i]["DropDownID"]),
                        tDisplayName = dataT.Rows[i]["DropDownValue"].ToString()
                    };
                    Reasondata.Add(dropcan);
                }
            }
            viewModel.CeremonyModel.RejectionReasonList = Reasondata;

            return View(viewModel);
        }

        // Data table action for pagination 
        [HttpPost]
        public ActionResult LoadBatchData(string ceremonySts, string trainingPartner, string batchName, string fromDate, string toDate)
        {
            // get Start (paging start index) and length (page size for paging)
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = 1+ Request.Form.GetValues("start").FirstOrDefault().ToInt();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            //Get Sort columns value
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();

            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start.ToInt();
            int totalRecords = 0;

            List<AssessedBatch> objBatchList = null;

            DateTime? fromDt = null, toDt = null;
            if (!string.IsNullOrEmpty(fromDate))
                fromDt = DateTime.ParseExact(fromDate, "dd-MMM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            if (!string.IsNullOrEmpty(toDate))
                toDt = DateTime.ParseExact(toDate, "dd-MMM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

            if (Utility.IsValidSqlDateTime(fromDt) && Utility.IsValidSqlDateTime(toDt))
            {
                objBatchList = new List<AssessedBatch>();

                DataTable dt = new DataTable();
                {
                    dt = dbAction.GetFilterBatchList(ceremonySts, trainingPartner, batchName, fromDt, toDt, skip, pageSize, sortColumn, sortColumnDir);
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            AssessedBatch objBatch = new AssessedBatch();

                            if (!string.IsNullOrEmpty(Convert.ToString(dr["BATCH NAME"])))
                            {
                                objBatch.ManageBatch.BatchName = dr["BATCH NAME"] as string;
                            }
                            else
                            {
                                objBatch.ManageBatch.BatchID = 0;
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(dr["SmartcentrebatchID"])))
                            {
                                objBatch.ManageBatch.SmartCentreBatchID = Convert.ToInt32(dr["SmartcentrebatchID"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["PIA NAME"])))
                            {
                                objBatch.TrainingPartner.Name = dr["PIA NAME"] as string;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["LOCATION ID"])))
                            {
                                objBatch.LocationID = Convert.ToInt32(dr["LOCATION ID"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["LOCATION NAME"])))
                            {
                                objBatch.LocationName = Convert.ToString(dr["LOCATION NAME"]);
                            }

                            if (!string.IsNullOrEmpty(Convert.ToString(dr["CEREMONY STATUS"])))
                            {
                                objBatch.ManageBatch.AssetVerificationStatus = dr["CEREMONY STATUS"] as string;
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["ASSESSMENT DATE"])))
                            {
                                objBatch.ManageBatch.PreferedAssessmentDate = string.IsNullOrEmpty(Convert.ToString(dr["ASSESSMENT DATE"])) ? "" : Convert.ToDateTime(dr["ASSESSMENT DATE"]).ToString("dd-MMM-yyyy");
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["PASSED COUNT"])))
                            {
                                objBatch.PassedCount = Convert.ToInt32(dr["PASSED COUNT"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["FAILED COUNT"])))
                            {
                                objBatch.FailedCount = Convert.ToInt32(dr["FAILED COUNT"]);
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(dr["NOT APPEARED"])))
                            {
                                objBatch.NotAppearedCount = Convert.ToInt32(dr["NOT APPEARED"]);
                            }
                            objBatchList.Add(objBatch);

                            totalRecords = !string.IsNullOrEmpty(Convert.ToString(dr["TotalRecords"])) ? Convert.ToInt32(dr["TotalRecords"]) : 0;
                        }
                    }
                }
            }
            var v = (from a in objBatchList select a);

            var data = v.ToList();
            return Json(new { draw = draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = data }, JsonRequestBehavior.AllowGet);

        }


        #region Json Methods 

        public JsonResult GetTrainingPartnersList()
        {
            List<TrainingPartner> TrainingPartnerList = new List<TrainingPartner>();

            DataTable dtable = new DataTable();
            dtable = dbAction.TrainingPartnerList();
            if (dtable.Rows.Count > 0)
            {
                for (int i = 0; i < dtable.Rows.Count; i++)
                {
                    TrainingPartner tp = new TrainingPartner()
                    {
                        PartnerID = Convert.ToInt32(dtable.Rows[i]["PartnerID"]),
                        PartnerName = dtable.Rows[i]["PartnerName"].ToString()
                    };
                    TrainingPartnerList.Add(tp);
                }
            }
            return Json(TrainingPartnerList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBatchList(string PartnerID)
        {
            List<ManageBatch> BatchList = null;
            int tp = (int.TryParse(PartnerID, out tp)) ? tp : 0;
            {
                BatchList = new List<ManageBatch>();
                DataTable dtable = new DataTable();
                dtable = dbAction.GetBatchListByPartner(tp);
                if (dtable.Rows.Count > 0)
                {
                    for (int i = 0; i < dtable.Rows.Count; i++)
                    {
                        ManageBatch batch = new ManageBatch()
                        {
                            BatchID = Convert.ToInt32(dtable.Rows[i]["BatchID"]),
                            BatchName = dtable.Rows[i]["BatchName"].ToString(),
                            SmartCentreBatchID = Convert.ToInt32(dtable.Rows[i]["SmartCentreBatchID"]),
                        };
                        BatchList.Add(batch);
                    }
                }
            }

            var jsonResult = Json(BatchList, JsonRequestBehavior.AllowGet);
            jsonResult.MaxJsonLength = int.MaxValue;
            return jsonResult;
            //return Json(BatchList, JsonRequestBehavior.AllowGet);
        }

        //public JsonResult GetFilterBatchList(string ceremonySts, string trainingPartner, string batchID,string fromDate,string toDate)
        //{
        //    List<AssessedBatch> objBatchList = null;
        //    int ceremonyID, trainingPartn, smartCentreBatchID;

        //    DateTime? fromDt = null, toDt= null;
        //    if (!string.IsNullOrEmpty(fromDate))
        //        fromDt = Convert.ToDateTime(fromDate);
        //    if (!string.IsNullOrEmpty(toDate))
        //        toDt = Convert.ToDateTime(toDate);

        //    if (Utility.IsValidSqlDateTime(fromDt) && Utility.IsValidSqlDateTime(fromDt))
        //    {
        //        DataTable dt = new DataTable();
        //        objBatchList = new List<AssessedBatch>();

        //        ceremonyID = Convert.ToInt32(ceremonySts);
        //        trainingPartn = Convert.ToInt32(trainingPartner);
        //        smartCentreBatchID = Convert.ToInt32(batchID);

        //        dt = dbAction.GetFilterBatchList(ceremonyID, trainingPartn, smartCentreBatchID,fromDt,toDt);
        //        if (dt.Rows.Count > 0)
        //        {
        //            foreach (DataRow dr in dt.Rows)
        //            {
        //                AssessedBatch objBatch = new AssessedBatch();

        //                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchName"])))
        //                {
        //                    objBatch.ManageBatch.BatchName = dr["BatchName"] as string;
        //                }
        //                else
        //                {
        //                    objBatch.ManageBatch.BatchID = 0;
        //                }

        //                if (!string.IsNullOrEmpty(Convert.ToString(dr["SmartCentreBatchID"])))
        //                {
        //                    objBatch.ManageBatch.SmartCentreBatchID = Convert.ToInt32(dr["SmartCentreBatchID"]);
        //                    if (objBatch.ManageBatch.SmartCentreBatchID > 0)
        //                    {
        //                        int pending, ImageCount, pendingCount;
        //                        List<BatchAssetPartialModel1> imgVerifiedList;
        //                        DataTable stsList, batchStatusList;
        //                        List<DropDownDDL> photoVerificationStatus;

        //                        stsList = dbAction.PhotoVerificationStatusList();
        //                        photoVerificationStatus = ListVerificationStatus(stsList);
        //                        pending = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Pending.ToString()).nIndex ?? 0;
        //                        batchStatusList = dbAction.GetBatchByBatchID(Convert.ToInt32(objBatch.ManageBatch.SmartCentreBatchID));
        //                        imgVerifiedList = ListVerifiedImages(batchStatusList);

        //                        ImageCount = imgVerifiedList.Count();
        //                        pendingCount = imgVerifiedList.FindAll(a => (a.VerificationStatus == pending)).Count();

        //                        if (ImageCount > 0)
        //                        {
        //                            if (ImageCount >= pendingCount && pendingCount == 0)
        //                                objBatch.ManageBatch.AssetVerificationStatus = VerificationStatus.Verified.ToString();
        //                            else
        //                                objBatch.ManageBatch.AssetVerificationStatus = VerificationStatus.Pending.ToString();
        //                        }
        //                        else
        //                            objBatch.ManageBatch.AssetVerificationStatus = "No Assets Yet";
        //                    }
        //                }
        //                objBatchList.Add(objBatch);
        //            }
        //        }
        //    }

        //    return Json(objBatchList, JsonRequestBehavior.AllowGet);
        //}

        public JsonResult GetApprovedBatch(string approvedStatus, string jobRole)
        {
            var user = SessionMgr.LoginUserDetails;
            var viewModel = new ManageBatchViewModel();
            DataTable dt = new DataTable();
            viewModel.ManageBatchList = new List<ManageBatch>();

            dt = dbAction.GetViewApprovedBatchList(approvedStatus, user.ContactId.ToStr(), user.CentreId.ToStr());
            foreach (DataRow dr in dt.Rows)
            {
                ManageBatch manageBatch = new ManageBatch();
                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchName"])))
                {
                    manageBatch.BatchName = dr["BatchName"] as string;
                }
                else
                {
                    manageBatch.BatchID = 0;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["SmartCentreBatchID"])))
                {
                    manageBatch.SmartCentreBatchID = Convert.ToInt32(dr["SmartCentreBatchID"]);
                    if (manageBatch.SmartCentreBatchID > 0)
                    {
                        int pending, ImageCount, pendingCount;
                        List<BatchAssetPartialModel1> imgVerifiedList;
                        DataTable stsList, batchStatusList;
                        List<DropDownDDL> photoVerificationStatus;

                        stsList = dbAction.PhotoVerificationStatusList();
                        photoVerificationStatus = ListVerificationStatus(stsList);
                        pending = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Pending.ToString()).nIndex ?? 0;
                        batchStatusList = dbAction.GetBatchByBatchID(Convert.ToInt32(manageBatch.SmartCentreBatchID));
                        imgVerifiedList = ListVerifiedImages(batchStatusList);

                        ImageCount = imgVerifiedList.Count();
                        pendingCount = imgVerifiedList.FindAll(a => (a.VerificationStatus == pending)).Count();

                        if (ImageCount > 0)
                        {
                            if (ImageCount >= pendingCount && pendingCount == 0)
                                manageBatch.AssetVerificationStatus = VerificationStatus.Verified.ToString();
                            else
                                manageBatch.AssetVerificationStatus = VerificationStatus.Pending.ToString();
                        }
                        else
                            manageBatch.AssetVerificationStatus = "No Assets Yet";
                    }
                }

                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchStartDate"])))
                {
                    manageBatch.BatchStartDate = Convert.ToDateTime(dr["BatchStartDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.BatchStartDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["BatchEndDate"])))
                {
                    manageBatch.BatchEndDate = Convert.ToDateTime(dr["BatchEndDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.BatchEndDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["PreferedAssessmentDate"])))
                {
                    manageBatch.PreferedAssessmentDate = Convert.ToDateTime(dr["PreferedAssessmentDate"]).ToString("dd-MMM-yyyy");
                }
                else
                {
                    manageBatch.PreferedAssessmentDate = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["JobRole"])))
                {
                    manageBatch.Jobrole = (string)dr["JobRole"];
                }
                else
                {
                    manageBatch.Jobrole = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["TrainerName"])))
                {
                    manageBatch.TrainerName = (string)dr["TrainerName"];
                }
                else
                {
                    manageBatch.TrainerName = string.Empty;
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dr["EnrolledCandidates"])))
                {
                    manageBatch.TotalCandidatesinBatch = (int)dr["EnrolledCandidates"];
                }
                else
                {
                    manageBatch.TotalCandidatesinBatch = 0;
                }
                viewModel.ManageBatchList.Add(manageBatch);
                Logger.LogMessage("GetApprovedBatch ManageBatchList Count:" + viewModel.ManageBatchList.Count);
            }

            if (!string.IsNullOrEmpty(jobRole))
            {
                viewModel.ManageBatchList = viewModel.ManageBatchList.FindAll(a => a.Jobrole == jobRole);
            }

            return Json(viewModel.ManageBatchList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SubmitBatchCeremonyStatus(string batchName, string Cerstatus, string CerStatusDescrip = null, string rejVal = null, string rejValText = null, string rejDesc = null)
        {
            var status = false;
            int res = 0;
            string TCEmail = string.Empty;
            if (!string.IsNullOrEmpty(batchName))
            {
                string batchID = Session["SmartCentreBatchID"].ToString();
                TCEmail = Session["CentreEmail"].ToString();

                int smartCentreBatchID;
                int ceremonyStatus = (int)CeremonyStatus.SentToNSDCPMU;

                if (Cerstatus == "Approve")
                    ceremonyStatus = (int)CeremonyStatus.VerifiedbyNSDCPMU; //VerifiedbyNSDCPMU
                else if (Cerstatus == "Reject")
                    ceremonyStatus = (int)CeremonyStatus.RejectedbyNSDCPMU; //RejectedbyNSDCPMU

                if (int.TryParse(batchID, out smartCentreBatchID))
                {
                    if (rejVal.Equals("-1") || string.IsNullOrEmpty(rejVal))
                        rejVal = null;
                    if (string.IsNullOrEmpty(rejDesc))
                        rejDesc = null;

                    using (TransactionScope transactionScope = new TransactionScope())
                    {
                        try
                        {
                            if (ceremonyStatus == (int)CeremonyStatus.RejectedbyNSDCPMU)
                            {
                                if (!string.IsNullOrEmpty(TCEmail))
                                    SendEmailAsCeremonyRejected(TCEmail, rejValText, rejDesc, CerStatusDescrip);
                            }

                            res = dbAction.UpdateCeremonyStatus(smartCentreBatchID, ceremonyStatus, CerStatusDescrip, rejVal, rejDesc);
                        }
                        catch (TransactionException ex)
                        {
                            transactionScope.Dispose();
                        }
                        transactionScope.Complete();
                    }

                    if (res > 0)
                    {
                        Session["CeremonyStatus"] = ceremonyStatus;
                        status = true;
                    }
                }
            }

            if (status)
                return Json(new { redirectUrl = Url.Action("CertificationCeremony", "Ceremony"), isRedirect = true }, JsonRequestBehavior.AllowGet);
            else
                return Json(false, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBatchAssetDescription(CandidateEnrollmentViewModel viewModel, string BatchId, string ImageName)
        {
            DataTable dt = new DataTable();
            dt = dbAction.GetBatchAssetsDescription(viewModel, BatchId, ImageName);
            viewModel.Description = dt.Rows[0]["Description"].ToString();
            return Json(viewModel, JsonRequestBehavior.AllowGet);
        }


        #endregion

        #region Partial View Result

        public PartialViewResult DisplayBatchAssetOnPageLoad(CandidateEnrollmentViewModel viewModel)
        {
            string BatchId = "";
            if (Session != null && Session["SmartCentreBatchID"].ToString() != null)
                BatchId = Session["SmartCentreBatchID"].ToString();
            string BatCeremonystatus = Session["CeremonyStatus"].ToString();

            string BatchPhotoattach = ConfigurationManager.AppSettings["Batch_Assets"];
            BatchPhotoattach = Path.Combine(BatchPhotoattach, BatchId);
            viewModel.CeremonyStatus = Convert.ToInt32(BatCeremonystatus);

            BatchAssetImageList(viewModel, BatchId, Utility.BuildAssetPath(ConfigurationManager.AppSettings["StorageRootPath"], BatchPhotoattach));
            return PartialView("_BatchAssets", viewModel);
        }

        public PartialViewResult ApproveBatchAsset(CandidateEnrollmentViewModel viewModel, string BatchID, string ImgName)
        {
            var userDetails = SessionMgr.LoginUserDetails;
            DataTable dt = new DataTable();
            string userID = userDetails.UserId.ToString();//Session["UserID"].ToString();
            bool isErrorOccurs = false;
            string errorMsg = string.Empty;
            int VerificationStatusID;

            string BatchPhotoattach = ConfigurationManager.AppSettings["Batch_Assets"];
            BatchPhotoattach = Path.Combine(BatchPhotoattach, BatchID);

            DataTable stsList = dbAction.PhotoVerificationStatusList();
            List<DropDownDDL> photoVerificationStatus = ListVerificationStatus(stsList);

            VerificationStatusID = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Verified.ToString()).nIndex ?? 0;

            if (VerificationStatusID > 0)
            {
                dt = dbAction.ApproveDenyBatchAssetsDescription(viewModel, userID, BatchID, ImgName, VerificationStatusID);
                BatchAssetImageList(viewModel, BatchID, Utility.BuildAssetPath(ConfigurationManager.AppSettings["StorageRootPath"], BatchPhotoattach));
            }
            else
            {
                isErrorOccurs = true;
                errorMsg = "Status Not Found";
            }
            if (isErrorOccurs)
            {
                var res = System.Web.HttpContext.Current.Response;
                res.StatusCode = 001;
                res.StatusDescription = errorMsg;
                return PartialView("_BatchAssets", viewModel);
            }
            return PartialView("_BatchAssets", viewModel);
        }

        public PartialViewResult DenyBatchAsset(CandidateEnrollmentViewModel viewModel, string BatchID, string ImgName)
        {
            var userDetails = SessionMgr.LoginUserDetails;
            DataTable dt = new DataTable();
            string userID = userDetails.UserId.ToString();//Session["UserID"].ToString();
            bool isErrorOccurs = false;
            string errorMsg = string.Empty;
            int VerificationStatusID;

            string BatchPhotoattach = ConfigurationManager.AppSettings["Batch_Assets"];
            BatchPhotoattach = Path.Combine(BatchPhotoattach, BatchID);

            DataTable stsList = dbAction.PhotoVerificationStatusList();
            List<DropDownDDL> photoVerificationStatus = ListVerificationStatus(stsList);

            VerificationStatusID = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Denied.ToString()).nIndex ?? 0;

            if (VerificationStatusID > 0)
            {
                dt = dbAction.ApproveDenyBatchAssetsDescription(viewModel, userID, BatchID, ImgName, VerificationStatusID);
                BatchAssetImageList(viewModel, BatchID, Utility.BuildAssetPath(ConfigurationManager.AppSettings["StorageRootPath"], BatchPhotoattach));
            }
            else
            {
                isErrorOccurs = true;
                errorMsg = "Status Not Found";
            }
            if (isErrorOccurs)
            {
                var res = System.Web.HttpContext.Current.Response;
                res.StatusCode = 001;
                res.StatusDescription = errorMsg;
                return PartialView("_BatchAssets", viewModel);
            }
            return PartialView("_BatchAssets", viewModel);
        }

        #endregion

        #region Private Methods 
        private List<DropDownDDL> ListVerificationStatus(DataTable dt)
        {
            var photoVerificationStatus = new List<DropDownDDL>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DropDownDDL varificationStatus = new DropDownDDL()
                    {
                        nIndex = Convert.ToInt32(dt.Rows[i]["DropDownID"]),
                        tDisplayName = dt.Rows[i]["DropDownValue"].ToString(),
                    };
                    photoVerificationStatus.Add(varificationStatus);
                }
            }

            return photoVerificationStatus;
        }

        private List<BatchAssetPartialModel1> ListVerifiedImages(DataTable dt)
        {
            List<BatchAssetPartialModel1> VerifiedImgList = new List<BatchAssetPartialModel1>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BatchAssetPartialModel1 varificationImg = new BatchAssetPartialModel1()
                    {
                        ImageName = dt.Rows[i]["ImageName"].ToString(),
                        Description = dt.Rows[i].IsNull("Description") ? string.Empty : dt.Rows[i]["Description"].ToString(),
                        VerificationStatus = Convert.ToInt32(dt.Rows[i]["VerificationStatus"]),
                        VerifiedBy = dt.Rows[i].IsNull("VerifiedBy") ? 0 : Convert.ToInt32(dt.Rows[i]["VerifiedBy"]),
                        TCUserID = Convert.ToInt32(dt.Rows[i]["TC_UserID"]),
                        TimeString = Convert.ToString(dt.Rows[i]["UploadTime"]),
                        Date = dt.Rows[i].IsNull("Date") ? (DateTime?)null : Convert.ToDateTime(dt.Rows[i]["Date"]),
                        GuestOfHonor = dt.Rows[i].IsNull("GuestOfHounour") ? string.Empty : dt.Rows[i]["GuestOfHounour"].ToString(),
                        GuestOfHonorType = dt.Rows[i].IsNull("GuestOfHounourType") ? 0 : Convert.ToInt32(dt.Rows[i]["GuestOfHounourType"])
                    };
                    VerifiedImgList.Add(varificationImg);
                }
            }

            return VerifiedImgList;
        }

        private void BatchAssetImageList(CandidateEnrollmentViewModel viewModel, string BatchId, string BatchPhotoattach)
        {
            if (Directory.Exists(BatchPhotoattach))
            {
                int pending, Approved;
                string fileName = string.Empty;
                string name = string.Empty;
                var files = Directory.EnumerateFiles(BatchPhotoattach, "*.*", SearchOption.AllDirectories);
                var ImageList = new List<BatchAssetPartialModel1>();

                DataTable stsList = dbAction.PhotoVerificationStatusList();
                List<DropDownDDL> photoVerificationStatus = ListVerificationStatus(stsList);

                pending = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Pending.ToString()).nIndex ?? 0;
                Approved = photoVerificationStatus.Find(a => a.tDisplayName == VerificationStatus.Verified.ToString()).nIndex ?? 0;

                DataTable batchStatusList = dbAction.GetBatchByBatchID(Convert.ToInt32(BatchId));
                List<BatchAssetPartialModel1> imgVerifiedList = ListVerifiedImages(batchStatusList);
                viewModel.ImageCount = imgVerifiedList.Count();
                imgVerifiedList = imgVerifiedList.FindAll(a => (a.VerificationStatus == pending || a.VerificationStatus == Approved));

                foreach (var item in files)
                {
                    name = item;
                    fileName = Path.GetFileName(name);
                    FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);
                    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                    br.Close();
                    fs.Close();

                    DataTable dtUpload = new DataTable("Attachments");
                    DataColumn dc = new DataColumn("1");
                    dc.DataType = System.Type.GetType("System.Byte[]");
                    dtUpload.Columns.Add(dc);

                    DataRow dr = dtUpload.NewRow();
                    dr["1"] = bytes;
                    dtUpload.Rows.Add(dr);

                    string image = "data:image/png;base64," + Convert.ToBase64String((byte[])dtUpload.Rows[0][0]);

                    if (imgVerifiedList.Exists(a => a.ImageName == fileName))
                    {
                        BatchAssetPartialModel1 res = imgVerifiedList.Find(a => a.ImageName == fileName);
                        ImageList.Add(new BatchAssetPartialModel1
                        {
                            image = image,
                            ImageName = fileName,
                            Description = res.Description,
                            Date = res.Date,
                            GuestOfHonor = res.GuestOfHonor,
                            GuestOfHonorType = res.GuestOfHonorType,
                            TimeString = res.TimeString,
                            Verfication = photoVerificationStatus.Find(a => a.nIndex == res.VerificationStatus).tDisplayName
                        });
                    }
                }
                viewModel.BatchName = BatchId;
                viewModel.ImageList = ImageList;
            }
        }

        private static void SendEmailAsCeremonyRejected(string emailID, string rejectionReason, string rejectionDesc, string remarks)
        {
            DbAction dba = new DbAction();
            Email mail = new Email();
            string body = string.Empty;

            try
            {
                EmailContent emailContent = new EmailContent();
                emailContent.EmailTo = emailID;
                emailContent.EmailCC = emailID;
                emailContent.Subject = "Certification Ceremony Photograph Status";
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                emailContent.ContentPath = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/EmailContent/CeremonyRejectContent.txt");

                body = System.IO.File.ReadAllText(emailContent.ContentPath);
                if (string.IsNullOrEmpty(remarks))
                    remarks = "Not Provided";

                body = body.Replace("@REJECTION_REASON", rejectionReason);
                body = body.Replace("@REJECTION_DESC", rejectionDesc);
                body = body.Replace("@REMARKS", remarks);

                emailContent.MailContent = body;

                Email.SendMailMailMessageAsCeremonyRejected(emailContent);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
        }

        #endregion

    }
}