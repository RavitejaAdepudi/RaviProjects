﻿using PMU.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using PMU.Infrastructure;
using System.Net.Mail;
using System.Runtime.Remoting.Messaging;

namespace PMU.Controllers
{

    public partial class ProjectsController : Controller
    {
        #region CreateProject

        [HttpGet]
        public ActionResult CreateProject()
        {
            SessionMgr.LocationList = null;
            SessionMgr.ProjectJobRole = null;
            ProjectViewModel viewModel = new ProjectViewModel();
            viewModel.TrainingType = SessionMgr.TrainingType;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            viewModel.TrainingTypeID = SessionMgr.TrainingTypeID.ToInt();

            if (SessionMgr.PartnerID != null && SessionMgr.TrainingPartner != null)
            {
                viewModel.TrainingPartnerID = SessionMgr.PartnerID.ToInt();
                viewModel.AccountID = SessionMgr.PartnerID.ToStr();
                viewModel.TrainingPartner = SessionMgr.TrainingPartner.ToStr();
            }
            else
            {
                viewModel.TrainingPartnerID = 0;
                viewModel.TrainingPartner = string.Empty;
            }
            viewModel = BindDropDowns(viewModel);
            viewModel.ProjectJobRoleDetails = ProjectJobRole();
            viewModel.TrainingPartnerDetails = TrainingTypeDetails();
            var requestedAction = Request.UrlReferrer.LocalPath;
            if (requestedAction != "/Projects/CreateProject")
                TempData["Status"] = string.Empty;
            else
            {
                TempData.Keep("Status");
            }
            Logger.LogMessage(requestedAction.ToString());
            return View(viewModel);
        }

        public TrainingPartner TrainingTypeDetails()
        {
            List<TrainingPartner> trainingPartnerList = new List<TrainingPartner>();
            TrainingPartner trainingPartner = new TrainingPartner();
            return trainingPartner;
        }

        public ProjectJobRole ProjectJobRole()
        {
            ProjectJobRole projectJobRole = new ProjectJobRole();
            projectJobRole.JobroleCode = "";
            projectJobRole.Sector = "";
            projectJobRole.SectorType = "";
            projectJobRole.SectorTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.SectorTypeList);
            //projectJobRole.SectorList = dbA.GetCommonDropdownLookup(PropertyLookup.SectorList);
            //projectJobRole.ProjectJobroleList = dbA.GetCommonDropdownLookup(PropertyLookup.JobRoleList);
            projectJobRole.ProjectJobroleList = new List<DropDownDDL>();
            return projectJobRole;
        }

        public ProjectViewModel BindDropDowns(ProjectViewModel viewModel)
        {
            viewModel.TrainingPartnerTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetTrainingPartnerTypeList);
            viewModel.TrainingTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetTrainingTypes, TabLookup.CandidateInformation);
            viewModel.ProjectTypeList = dbA.GetProjectTypeByTrainingType(viewModel.TrainingType);
            //if (viewModel.TrainingType == "RPL")
            //{               
            //    //viewModel.ProjectTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.ProjectType, TabLookup.RPLProjectType);
            //}
            //else
            //{             
            //    //viewModel.ProjectTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetProjectType,TabLookup.ProjectDetails);
            //}
            viewModel.PlacementApplicableDisbursmentList = dbA.GetCommonDropdownLookup(PropertyLookup.GetPlacementApplicableDisbursmentList);
            //viewModel.DisbursementModeTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetDisbursementModeTypeList);
            viewModel.DisbursementModeTypeList = new List<DropDownDDL>();
            viewModel.CertificateTemplateTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetCertificateTemplateTypeList);
            viewModel.SectorTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.SectorTypeList);
            return viewModel;
        }

        [HttpPost]
        public ActionResult CreateProject(ProjectViewModel viewModel)
        {
            List<ProjectJobRole> selectedProjectJobRole = new List<ProjectJobRole>();//Add Selected Employers to list
            string infoMessage = string.Empty;
            string status = string.Empty;
            string projectJobRolePartail = string.Empty;
            ProjectViewModel projectViewModel = new ProjectViewModel();
            try
            {

                if (viewModel.TrainingType.ToUpper() == "RPL")
                {
                    if (ModelState.ContainsKey("{DisbursementModeID}"))
                        ModelState["{DisbursementModeID}"].Errors.Clear();
                    if (ModelState.ContainsKey("{PlacementDisbursementID}"))
                        ModelState["{PlacementDisbursementID}"].Errors.Clear();
                }
                //if (SessionMgr.ProjectJobRole == null || SessionMgr.ProjectJobRole.Count() <= 0)
                //{
                //    ModelState.AddModelError("ProjectJobRoleDetailsErromsg", "Please add JobRole Details");
                //}
                //if (viewModel.TrainingType.ToUpper() == "SPECIAL PROJECT")
                //{
                if (viewModel.CertificateTemplate?.ToUpper() == "CUSTOM TEMPLATE")
                {
                    if (viewModel.CustomCertificateTemplateId == -1)
                    {
                        ModelState.AddModelError("CustomCertificateTemplateId", "Please Select Customtemplate Logo Type");
                    }
                    else
                    {
                        var fileStatus = true;
                        for (int i = 0; i < viewModel.CustomTemplateType.GovtLogoCount; i++)
                        {
                            if (viewModel.CustomTemplateType.CustomFileSelectedGovt[i].AssetId == 0)
                            {
                                fileStatus = false;
                            }
                        }
                        for (int i = 0; i < viewModel.CustomTemplateType.CorporateLogoCount; i++)
                        {
                            if (viewModel.CustomTemplateType.CustomFileSelectedCorporate[i].AssetId == 0)
                            {
                                fileStatus = false;
                            }
                        }

                        if (!fileStatus)
                        {
                            ModelState.AddModelError("CustomCertificateTemplateId", "Please Select Customtemplate all Logos");
                        }
                    }
                }
                //}
                if (ModelState.IsValid)//&& viewModel.ProjectJobRoleTarget != 0
                {
                    if (SessionMgr.ProjectJobRole.Count() == 0)
                    {
                        ModelState.AddModelError("ProjectJobRoleDetailsErromsg", "Please add Job Role Details");
                    }
                    var jobRoleCount = SessionMgr.ProjectJobRole.Sum(x => x.JobRoleTarget);
                    if (jobRoleCount != viewModel.ProjectJobRoleTarget)
                    {
                        ModelState.AddModelError("ProjectJobRoleTarget", "Project Target hasn't been consumed completely, please assign complete Targets across the Job Roles before submitting the Project");
                    }
                    if (viewModel.StartDate.ToDateTime() > viewModel.EndDate.ToDateTime())
                    {
                        ModelState.AddModelError("StartDate", "Start Date Should be less than EndDate");
                    }
                    Dictionary<string, string> retValue = dbA.CheckIsProjectValid(viewModel.ProjectName, SessionMgr.TrainingTypeID.ToStr(), viewModel.ProjectJobRoleTarget);
                    string projectValidation = retValue["ProjectValidation"];
                    string schemLevelValidation = retValue["SchemLevelValidation"];
                    if (projectValidation != "Valid")
                    {
                        ModelState.AddModelError("ProjectName", "This Project Name already exists, Please Enter different Project Name");
                    }
                    if (schemLevelValidation != "Valid")
                    {
                        ModelState.AddModelError("ProjectJobRoleTarget", schemLevelValidation);
                    }
                }

                if (ModelState.IsValid)
                {
                    var check = Request.Form["hidBackDate"];
                    if (Convert.ToBoolean(check))
                        if (string.IsNullOrEmpty(viewModel.BatchBackDate))
                            ModelState.AddModelError("BatchBackDateErrorMsg", "Please select Batch Back Date.");
                }

                if (ModelState.IsValid)
                {
                    if (viewModel.ProjectType?.ToLower() == "rpl camps" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxRplCampFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "RPL Camps Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxRplCampFee"].ToInt() + "");
                    if (viewModel.ProjectType?.ToLower() == "employer's premises" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxEmployerPremisesFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "Employer's Premises Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxEmployerPremisesFee"].ToInt() + "");
                    if (viewModel.ProjectType?.ToLower() == "rpl centres" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxRPLCentresFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "Rpl Centres Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxRPLCentresFee"].ToInt() + "");
                }
                if (ModelState.IsValid)
                {
                    if (viewModel.CustomTemplateLogo != null)
                    {
                        try
                        {
                            HttpPostedFileBase postFile = viewModel.CustomTemplateLogo;
                            string fileName = GetFileName(postFile);
                            postFile.SaveAs(Server.MapPath(Path.Combine(ConfigurationManager.AppSettings["PMUProjectUploadFilesLocation"].ToString(), fileName)));
                            viewModel.CustomTemplateLogoURL = ConfigurationManager.AppSettings["PMUProjectUploadFilesLocation"];
                            viewModel.FileName = fileName;
                        }
                        catch (Exception ex)
                        {
                            Logger.LogException(ex);
                        }
                    }
                    //Logger.LogMessage("Test log" + viewModel.ProjectType);
                    //IList<Location> locationList = new List<Location>();
                    //Location location;
                    //foreach (var item in SessionMgr.LocationList)
                    //{
                    //    location = new Location();
                    //    List<int> listSelectedLocationJobRole = new List<int>();
                    //    foreach (var selectedJobRole in item.SelectedJobRoleList)
                    //    {
                    //        listSelectedLocationJobRole.Add(selectedJobRole.ToInt());
                    //    }
                    //    location.LocationID = item.LocationID;
                    //    location.SelectedJobRoleList = listSelectedLocationJobRole;
                    //    locationList.Add(location);
                    //}
                    //viewModel.PartnerID = SessionMgr.LoginUserDetails.PartnerId;
                    //viewModel.ProjectJobRoleList = selectedProjectJobRole;
                    //viewModel.LocationList = locationList;
                    DataTable dt = dbA.SaveSPIAProject(viewModel);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        if (dt.Columns.Contains("Result"))
                        {
                            if (dt.Rows[0]["Result"].ToStr() == "Added Successfully")
                            {
                                string password = string.Empty;
                                //Utility.GenerateRandomPassword(out password);
                                password = Encryption.DecryptPassword(dt.Rows[0]["Password"].ToString());
                                ViewBag.Status = "Success";
                                status = "Success";
                                SessionMgr.ProjectJobRole = null;
                                ModelState.Clear();
                                viewModel.CustomTemplateType = new CustomTemplateType();
                                viewModel.CertificateTemplateTypeID = "-1";
                                try
                                {
                                    SendEmailsToPlacementOfficer(dt.Rows[0]["SPOCName"].ToStr(), dt.Rows[0]["SPOCEmail"].ToStr(), dt.Rows[0]["ContactCode"].ToString(), password, viewModel.TrainingType);
                                }
                                catch (Exception ex)
                                {
                                    Logger.LogException(ex);
                                }
                            }
                            else if (dt.Rows[0]["Result"].ToStr() == "Already Exists")
                            {
                                ViewBag.Status = "Exists";
                                status = "Exists";
                            }
                        }
                        else
                        {
                            ViewBag.Status = "Failure";
                            status = "Failure";
                        }
                    }
                    infoMessage = string.Empty;
                }
                else
                {
                    infoMessage = string.Join("</br> ", ModelState.Values
                                                             .SelectMany(x => x.Errors)
                                                             .Select(x => x.ErrorMessage));
                }
            }

            catch (Exception ex)
            {
                Logger.LogException(ex);
                projectViewModel.TrainingType = viewModel.TrainingType;
                projectViewModel = BindDropDowns(projectViewModel);
                projectViewModel.ProjectJobRoleDetails = ProjectJobRole();
                projectViewModel.TrainingPartnerDetails = TrainingTypeDetails();
                projectViewModel.ProjectJobRoleList = SessionMgr.ProjectJobRole;
                ViewBag.Status = "Failure";

                projectViewModel.CertificateTemplateTypeID = viewModel.CertificateTemplateTypeID;
                projectViewModel.CustomCertificateTemplateId = viewModel.CustomCertificateTemplateId;
                projectViewModel.CustomTemplateType = viewModel.CustomTemplateType;

                return View(projectViewModel);
                //status = "Failure";
                //return Json(new { Status = status, InfoMessage = infoMessage });
            }
            projectViewModel.TrainingType = viewModel.TrainingType;
            ViewBag.Status = status;
            projectViewModel = BindDropDowns(projectViewModel);
            projectViewModel.DisbursementModeTypeList = dbA.GetDisbursementModeByPlacement(viewModel.PlacementDisbursementID.ToStr());
            projectViewModel.ProjectJobRoleDetails = ProjectJobRole();
            projectViewModel.TrainingPartnerDetails = TrainingTypeDetails();
            projectViewModel.ProjectJobRoleList = SessionMgr.ProjectJobRole;
            projectViewModel.TrainingType = SessionMgr.TrainingType;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            projectViewModel.TrainingTypeID = SessionMgr.TrainingTypeID.ToInt();

            projectViewModel.CertificateTemplateTypeID = viewModel.CertificateTemplateTypeID;
            projectViewModel.CustomCertificateTemplateId = viewModel.CustomCertificateTemplateId;
            projectViewModel.CustomTemplateType = viewModel.CustomTemplateType;

            return View(projectViewModel);
            //projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleDetails", SessionMgr.ProjectJobRole);
            //return Json(new { Status = status,InfoMessage = infoMessage});
        }

        public ActionResult AddProjectLocationJobRole(Location location)
        {
            IList<Location> locationList = new List<Location>();
            try
            {
                if (SessionMgr.LocationList.Count() > 0)
                {
                    locationList = SessionMgr.LocationList;
                    if (locationList.Any(x => x.LocationID == location.LocationID.ToInt()))
                    {
                        return Json("Exists", JsonRequestBehavior.AllowGet);
                    }
                    locationList.Add(location);
                    //locationList = new List<Location>(locationList.Concat(locationList));
                }
                else
                {
                    locationList = new List<Location>();
                    locationList.Add(location);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.LocationList = locationList;
            return PartialView("_Location", SessionMgr.LocationList);
        }

        public ActionResult RemoveProjectLocationJobRole(string locationID)
        {
            IList<Location> locationJobRoleList = new List<Location>();
            try
            {
                locationJobRoleList = SessionMgr.LocationList;
                var item = locationJobRoleList.FirstOrDefault(x => x.LocationID.ToString() == locationID);
                locationJobRoleList.Remove(item);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.LocationList = locationJobRoleList;
            return PartialView("_Location", locationJobRoleList);
        }

        public ActionResult AddProjectJobRole(ProjectJobRole location)
        {
            IList<ProjectJobRole> projectJobRoleList = new List<ProjectJobRole>();
            try
            {
                if (SessionMgr.ProjectJobRole.Count() > 0)
                {
                    projectJobRoleList = SessionMgr.ProjectJobRole;
                    if (projectJobRoleList.Any(x => x.JobroleID == location.JobroleID.ToInt()))
                    {
                        return Json("Exists", JsonRequestBehavior.AllowGet);
                    }
                    projectJobRoleList.Add(location);
                    //locationList = new List<Location>(locationList.Concat(locationList));
                }
                else
                {
                    projectJobRoleList = new List<ProjectJobRole>();
                    projectJobRoleList.Add(location);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.ProjectJobRole = projectJobRoleList;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            return PartialView("_JobRoleDetails", SessionMgr.ProjectJobRole);
        }

        public ActionResult AddProjectJobRole1(ProjectJobRole location)
        {
            IList<ProjectJobRole> projectJobRoleList = new List<ProjectJobRole>();
            try
            {
                if (SessionMgr.ProjectJobRole.Count() > 0)
                {
                    projectJobRoleList = SessionMgr.ProjectJobRole;
                    if (projectJobRoleList.Any(x => x.JobroleID == location.JobroleID.ToInt()))
                    {
                        return Json("Exists", JsonRequestBehavior.AllowGet);
                    }
                    projectJobRoleList.Add(location);
                    //locationList = new List<Location>(locationList.Concat(locationList));
                }
                else
                {
                    projectJobRoleList = new List<ProjectJobRole>();
                    projectJobRoleList.Add(location);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.ProjectJobRole = projectJobRoleList;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            return PartialView("_JobRoleTarget", SessionMgr.ProjectJobRole);
        }

        public ActionResult EditProjectJobRole(ProjectJobRole location)
        {
            IList<ProjectJobRole> projectJobRoleList = new List<ProjectJobRole>();
            try
            {
                if (location.hidJobRoleId != "0")
                {
                    if (SessionMgr.ProjectJobRole.Count() > 0)
                    {
                        projectJobRoleList = SessionMgr.ProjectJobRole;
                        if (projectJobRoleList.Any(x => x.JobroleID == location.hidJobRoleId.ToInt()))
                        {
                            projectJobRoleList.Remove(projectJobRoleList.First(x => x.JobroleID == location.hidJobRoleId.ToInt()));
                            projectJobRoleList.Add(location);
                        }
                    }
                    else
                    {
                        projectJobRoleList = new List<ProjectJobRole>();
                        projectJobRoleList.Add(location);
                    }
                }

                else
                {
                    projectJobRoleList = SessionMgr.ProjectJobRole;
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.ProjectJobRole = projectJobRoleList;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            if (SessionMgr.TrainingType == "RPL")
                return PartialView("_JobRoleTarget", SessionMgr.ProjectJobRole);
            else
                return PartialView("_JobRoleDetails", SessionMgr.ProjectJobRole);
        }

        public ActionResult RemoveProjectJobRole(string jobRoleID)
        {
            //  string result = dbA.GetJobRoleDelete(SessionMgr.ProjectID.ToInt(), jobRoleID.ToInt());

            IList<ProjectJobRole> locationJobRoleList = new List<ProjectJobRole>();
            try
            {
                locationJobRoleList = SessionMgr.ProjectJobRole;
                var item = locationJobRoleList.FirstOrDefault(x => x.JobroleID == jobRoleID.ToInt());
                locationJobRoleList.Remove(item);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.ProjectJobRole = locationJobRoleList;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            return PartialView("_JobRoleDetails", locationJobRoleList);
        }

        public ActionResult GetJobRoleBySector(string sectorID, string SectorTypeID)
        {
            IList<DropDownDDL> jobRolelist = new List<DropDownDDL>();
            try
            {
                jobRolelist = dbA.GetJobRoleBySector(sectorID, SectorTypeID);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return Json(jobRolelist, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetSectorBySectorType(string sectorTypeID)
        {
            IList<DropDownDDL> jobRolelist = new List<DropDownDDL>();
            try
            {
                jobRolelist = dbA.GetSectorBySectorType(sectorTypeID);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return Json(jobRolelist, JsonRequestBehavior.AllowGet);
        }


        public ActionResult GetDisbursementModeByPlacement(string placementID)
        {
            IList<DropDownDDL> disbursementList = new List<DropDownDDL>();
            try
            {
                disbursementList = dbA.GetDisbursementModeByPlacement(placementID);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return Json(disbursementList, JsonRequestBehavior.AllowGet);
        }

        private string GetFileName(HttpPostedFileBase postFile)
        {
            StringBuilder fileName = new StringBuilder();
            try
            {
                fileName.Append(Path.GetFileNameWithoutExtension(postFile.FileName));
                fileName.Append(DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                fileName.Append(Guid.NewGuid());
                fileName.Append(Path.GetExtension(postFile.FileName));
            }
            catch (Exception)
            {
                throw;
            }
            return fileName.ToString();
        }


        #endregion

        #region PIA Details
        public ActionResult GetPIADetails(string piaName)
        {
            IList<TrainingPartner> traingPartnerList = new List<TrainingPartner>();
            try
            {
                traingPartnerList = dbA.GetSearchTrainingPartnerDetails(piaName);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return PartialView("_SearchPIA", traingPartnerList);
        }

        [HttpPost]
        public ActionResult CreatePIA(TrainingPartner traingPartner)
        {
            string status = "Failure";
            string infoMessage = string.Empty;
            string password = string.Empty;
            string UserName = string.Empty;
            try
            {
                if (ModelState.IsValid)
                {
                    traingPartner.ContactID = SessionMgr.LoginUserDetails.ContactId;
                    traingPartner.CentreID = SessionMgr.LoginUserDetails.CentreId;
                    traingPartner.RandomPassword = Utility.GenerateRandomPassword(out password);

                    DataTable dt = new DataTable();
                    dt = dbA.SavePIADetails(traingPartner);
                    if (dt != null)
                    {
                        if (dt.Rows.Count > 0)
                        {
                            status = Convert.ToString(dt.Rows[0]["result"].ToString());
                            if (status == "AddedSuccessfully")
                            {
                                // SendEmailsToPlacementOfficer(traingPartner.SPOCName, traingPartner.SPOCEmail, dt.Rows[0]["UserName"].ToString(), password);
                                UserName = dt.Rows[0]["UserName"].ToString();
                            }
                            else if (status == "Exists")
                            {

                            }
                        }

                    }
                }
                else
                {
                    infoMessage = string.Join("</br> ", ModelState.Values
                                            .SelectMany(x => x.Errors)
                                            .Select(x => x.ErrorMessage)); ;
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                infoMessage = "Some Error has occurred, Please try after some time or Contact admin";
            }
            return Json(new { Status = status, UserName = UserName, Password = password, InfoMessage = infoMessage }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        private static bool SendEmailsToPlacementOfficer(string name, string emailID, string loginid, string userPassword, string trainingType)
        {
            DbAction dba = new DbAction();
            Email mail = new Email();
            string body = string.Empty;

            try
            {
                EmailContent emailContent = new EmailContent();
                emailContent.Firstname = name;
                emailContent.EmailTo = emailID;
                emailContent.EmailCC = emailID;
                emailContent.EmailBCC = ConfigurationManager.AppSettings["EmailBCC"].ToString().Split(',');
                emailContent.loginID = loginid;
                if (trainingType == "Special Project")
                {
                    emailContent.Url = ConfigurationManager.AppSettings["WebsiteUrlSPIA"].ToString();
                    emailContent.ContentId = "SPIA";
                    emailContent.Subject = ConfigurationManager.AppSettings["SPIALoginDetails"].ToString();
                }
                else
                {
                    emailContent.Url = ConfigurationManager.AppSettings["WebsiteUrlPIA"].ToString();
                    emailContent.ContentId = "PIA";
                    emailContent.Subject = ConfigurationManager.AppSettings["PIALoginDetails"].ToString();
                }
                emailContent.Randpassword = userPassword;
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                emailContent.ContentPath = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/EmailContent/EmailContent.txt");
                Email.SendMailMailMessage(emailContent);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                return false;
            }
        }

        [HttpPost]
        public string EditProject(ProjectViewModel viewModel)
        {
            List<ProjectJobRole> selectedProjectJobRole = new List<ProjectJobRole>();//Add Selected Employers to list
            string infoMessage = string.Empty;
            string status = string.Empty;
            string projectJobRolePartail = string.Empty;
            ProjectViewModel projectViewModel = new ProjectViewModel();
            try
            {

                if (viewModel.TrainingType.ToUpper() == "RPL")
                {
                    if (ModelState.ContainsKey("{DisbursementModeID}"))
                        ModelState["{DisbursementModeID}"].Errors.Clear();
                    if (ModelState.ContainsKey("{PlacementDisbursementID}"))
                        ModelState["{PlacementDisbursementID}"].Errors.Clear();
                }

                if (viewModel.CertificateTemplate?.ToUpper() == "CUSTOM TEMPLATE")
                {
                    if (viewModel.CustomTemplateLogo == null)
                    {
                        ModelState.AddModelError("CustomTemplateLogo", "Please Select Customtemplate Logo");
                    }
                }

                if (ModelState.IsValid)//&& viewModel.ProjectJobRoleTarget != 0
                {
                    if (SessionMgr.ProjectJobRole.Count() == 0)
                    {
                        ModelState.AddModelError("ProjectJobRoleDetailsErromsg", "Please add Job Role Details");
                    }
                    var jobRoleCount = SessionMgr.ProjectJobRole.Sum(x => x.JobRoleTarget);
                    if (jobRoleCount != viewModel.ProjectJobRoleTarget)
                    {
                        ModelState.AddModelError("ProjectJobRoleTarget", "Project Target hasn't been consumed completely, please assign complete Targets across the Job Roles before submitting the Project");
                    }
                    if (viewModel.StartDate.ToDateTime() > viewModel.EndDate.ToDateTime())
                    {
                        ModelState.AddModelError("StartDate", "Start Date Should be less than EndDate");
                    }
                    //Dictionary<string, string> retValue = dbA.CheckIsProjectValid(viewModel.ProjectName, SessionMgr.TrainingTypeID.ToStr(), viewModel.ProjectJobRoleTarget);
                    //string projectValidation = retValue["ProjectValidation"];
                    //string schemLevelValidation = retValue["SchemLevelValidation"];
                    //if (projectValidation != "Valid")
                    //{
                    //    ModelState.AddModelError("ProjectName", "This Project Name already exists, Please Enter different Project Name");
                    //}
                    //if (schemLevelValidation != "Valid")
                    //{
                    //    ModelState.AddModelError("ProjectJobRoleTarget", schemLevelValidation);
                    //}
                }

                if (ModelState.IsValid)
                {
                    var check = Request.Form["hidBackDate"];
                    if (Convert.ToBoolean(check))
                        if (string.IsNullOrEmpty(viewModel.BatchBackDate))
                            ModelState.AddModelError("BatchBackDateErrorMsg", "Please select Batch Back Date.");
                }

                if (ModelState.IsValid)
                {
                    if (viewModel.ProjectType?.ToLower() == "rpl camps" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxRplCampFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "RPL Camps Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxRplCampFee"].ToInt() + "");
                    if (viewModel.ProjectType?.ToLower() == "employer's premises" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxEmployerPremisesFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "Employer's Premises Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxEmployerPremisesFee"].ToInt() + "");
                    if (viewModel.ProjectType?.ToLower() == "rpl centres" && viewModel.PIAFee > ConfigurationManager.AppSettings["MaxRPLCentresFee"].ToInt())
                        ModelState.AddModelError("PIAFee", "Rpl Centres Fee should be less than or Equal to " + ConfigurationManager.AppSettings["MaxRPLCentresFee"].ToInt() + "");
                }
                if (ModelState.IsValid)
                {
                    if (viewModel.CustomTemplateLogo != null)
                    {
                        try
                        {
                            HttpPostedFileBase postFile = viewModel.CustomTemplateLogo;
                            string fileName = GetFileName(postFile);
                            postFile.SaveAs(Server.MapPath(Path.Combine(ConfigurationManager.AppSettings["PMUProjectUploadFilesLocation"].ToString(), fileName)));
                            viewModel.CustomTemplateLogoURL = ConfigurationManager.AppSettings["PMUProjectUploadFilesLocation"];
                            viewModel.FileName = fileName;
                        }
                        catch (Exception ex)
                        {
                            Logger.LogException(ex);
                        }
                    }
                    DataTable dt = dbA.EditRPLProject(viewModel);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        if (dt.Columns.Contains("Result"))
                        {
                            if (dt.Rows[0]["Result"].ToStr() == "Edited Successfully")
                            {
                                string password = string.Empty;
                                //Utility.GenerateRandomPassword(out password);
                                password = Encryption.DecryptPassword(dt.Rows[0]["Password"].ToString());
                                ViewBag.Status = "Success";
                                status = "Success";
                                // SessionMgr.ProjectJobRole = null;
                                ModelState.Clear();
                                try
                                {
                                    if (SendEmailsToPlacementOfficer(dt.Rows[0]["SPOCName"].ToStr(), dt.Rows[0]["SPOCEmail"].ToStr(), dt.Rows[0]["ContactCode"].ToString(), password, viewModel.TrainingType))
                                        dbA.InsertEmailSendingStatus(SessionMgr.LoginUserDetails.UserId, dt.Rows[0]["SPOCEmail"].ToStr(), 1);
                                    else
                                        dbA.InsertEmailSendingStatus(SessionMgr.LoginUserDetails.UserId, dt.Rows[0]["SPOCEmail"].ToStr(), 0);
                                }
                                catch (Exception ex)
                                {
                                    dbA.InsertEmailSendingStatus(SessionMgr.LoginUserDetails.UserId, dt.Rows[0]["SPOCEmail"].ToStr(), 0);
                                    infoMessage = "ERROR Occured while sending Mail.";
                                    Logger.LogException(ex);
                                }
                                infoMessage = "Job Roles has been Edited Successfully";
                            }
                            else if (dt.Rows[0]["Result"].ToStr() == "Already Exists")
                            {
                                ViewBag.Status = "Exists";
                                status = "Exists";
                            }
                        }
                        else
                        {
                            ViewBag.Status = "Failure";
                            status = "Failure";
                            infoMessage = "Error Occred While Processing";
                        }
                    }
                    // infoMessage = string.Empty;
                }
                else
                {
                    infoMessage = string.Join("</br> ", ModelState.Values
                                                             .SelectMany(x => x.Errors)
                                                             .Select(x => x.ErrorMessage));
                }
            }

            catch (Exception ex)
            {
                Logger.LogException(ex);
                projectViewModel.TrainingType = viewModel.TrainingType;
                projectViewModel = BindDropDowns(projectViewModel);
                projectViewModel.ProjectJobRoleDetails = ProjectJobRole();
                projectViewModel.TrainingPartnerDetails = TrainingTypeDetails();
                projectViewModel.ProjectJobRoleList = SessionMgr.ProjectJobRole;
                ViewBag.Status = "Failure";
                // return "Error Occured.";
                return ex.ToString();
                //status = "Failure";
                //return Json(new { Status = status, InfoMessage = infoMessage });
            }
            projectViewModel.TrainingType = viewModel.TrainingType;
            ViewBag.Status = status;
            projectViewModel = BindDropDowns(projectViewModel);
            projectViewModel.DisbursementModeTypeList = dbA.GetDisbursementModeByPlacement(viewModel.PlacementDisbursementID.ToStr());
            projectViewModel.ProjectJobRoleDetails = ProjectJobRole();
            projectViewModel.TrainingPartnerDetails = TrainingTypeDetails();
            projectViewModel.ProjectJobRoleList = SessionMgr.ProjectJobRole;
            projectViewModel.TrainingType = SessionMgr.TrainingType;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            projectViewModel.TrainingTypeID = SessionMgr.TrainingTypeID.ToInt();
            return infoMessage;
            //projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleDetails", SessionMgr.ProjectJobRole);
            //return Json(new { Status = status,InfoMessage = infoMessage});
        }
    }
}