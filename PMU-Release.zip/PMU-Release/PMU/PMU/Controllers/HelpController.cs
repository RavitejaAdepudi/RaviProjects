﻿using System.Web.Mvc;
using System.Configuration;
using System.IO;

namespace PMU.Controllers
{
    public class HelpController : Controller
    {
        // GET: Help
        public ActionResult Index()
        {
            //ViewBag.Path =  Path.Combine(HostingEnvironment.ApplicationPhysicalPath,ConfigurationManager.AppSettings["UserManualCertificateCeromany"].ToStr());           
            return View();
        }
        public ActionResult DownloadFileCertificateCeremony()
        {
            string virtualPath=ConfigurationManager.AppSettings["UserManualCertificateCeromany"].ToStr();
            return File(virtualPath, System.Net.Mime.MediaTypeNames.Application.Octet, Path.GetFileName(virtualPath));
        }
        public ActionResult DownloadFileProject()
        {
            string virtualPath = ConfigurationManager.AppSettings["UserManualProject"].ToStr();
            return File(virtualPath, System.Net.Mime.MediaTypeNames.Application.Octet, Path.GetFileName(virtualPath));
        }
    }
}