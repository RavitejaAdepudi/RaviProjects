﻿using PMU.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using PMU.Infrastructure;
using System.Data;
using System.Configuration;

namespace PMU.Controllers
{
    [SessionExpire]
    public class LocationController : Controller
    {

        DbAction dbA = new DbAction();
        #region Address
        public JsonResult GetAddressDetails(string PINCode)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel = dbA.GetAddressDetails(PINCode, viewModel);
            Logger.LogMessage("GetAddressDetails LocalityList Count:" + viewModel.LocalityList.Count);
            return Json(viewModel, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetPostOfficeDetails(string PINCode, string Locality)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel.PostOfficeList = dbA.GetPostOfficeDetails(PINCode, Locality);
            Logger.LogMessage("GetAddressDetails PostOfficeList Count:" + viewModel.PostOfficeList.Count);
            return Json(viewModel.PostOfficeList, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCityVillageTownDetails(string PINCode, string Locality, string PostOffice)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel.TraineeVillageTownCityList = dbA.GetCityVillageTownDetails(PINCode, Locality, PostOffice);
            Logger.LogMessage("GetAddressDetails TraineeVillageTownCityList Count:" + viewModel.TraineeVillageTownCityList.Count);
            return Json(viewModel.TraineeVillageTownCityList, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetSubDistrictDetails(string PINCode, string Locality, string PostOffice, string Village)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel.TraineeSubDistrictList = dbA.GetSubDistrictDetails(PINCode, Locality, PostOffice, Village);

            Logger.LogMessage("GetAddressDetails TraineeSubDistrictList Count:" + viewModel.TraineeSubDistrictList.Count);
            return Json(viewModel.TraineeSubDistrictList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetStatetDetails(string PINCode, string Locality, string PostOffice, string Village, string SubDistrict)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel.TraineeStateList = dbA.GetStatetDetails(PINCode, Locality, PostOffice, Village, SubDistrict);

            Logger.LogMessage("GetAddressDetails TraineeStateList Count:" + viewModel.TraineeStateList.Count);
            return Json(viewModel.TraineeStateList, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetDistrictDetails(string PINCode, string Locality, string PostOffice, string Village, string SubDistrict, string State)
        {
            var viewModel = new TrainingLocations();
            Logger.LogMessage("GetAddressDetails PINCode:" + PINCode);
            viewModel.TraineeDistrictList = dbA.GetDistrictDetails(PINCode, Locality, PostOffice, Village, SubDistrict, State);

            Logger.LogMessage("GetAddressDetails TraineeDistrictList Count:" + viewModel.TraineeDistrictList.Count);
            return Json(viewModel.TraineeDistrictList, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetGeoSpecialDetails(string IsStateorDistrict, string StateorDistrictId)
        {
            string GeoSpecialDetails = string.Empty;

            GeoSpecialDetails = dbA.GetGeoSpecialDetails(IsStateorDistrict, StateorDistrictId, Convert.ToString(SessionMgr.LoginUserDetails.CentreId));
            Logger.LogMessage("GetGeoSpecialDetails GeoSpecialDetails:" + GeoSpecialDetails);
            return Json(GeoSpecialDetails, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetState()
        {
            var viewModel = new TrainingLocations();

            viewModel.TraineeStateList = dbA.GetState();
            //Logger.LogMessage("GetState TraineeStateList.Count:" + viewModel.TraineeStateList.Count);
            return Json(viewModel.TraineeStateList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDistrict(string StateId)
        {
            var viewModel = new TrainingLocations();

            Logger.LogMessage("GetDistrict StateId:" + StateId);
            viewModel.TraineeDistrictList = dbA.GetDistrict(StateId);
            //Session["State"] = viewModel.TraineeStateList;
            //Session["District"] = viewModel.TraineeDistrictList;
            //Session["SubDistrict"] = viewModel.TraineeSubDistrictList;
            //Session["City"] = viewModel.TraineeVillageTownCityList;
            //Logger.LogMessage("GetDistrict TraineeDistrictList.Count:" + viewModel.TraineeDistrictList.Count);
            return Json(viewModel.TraineeDistrictList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetConstituency(string StateId)
        {
            TrainingLocations viewModel = new TrainingLocations();
            try
            {
                Logger.LogMessage("GetConstituency StateId:" + StateId);
                viewModel.ConstituencyList = dbA.GetConstituency(StateId);
                //Session["State"] = viewModel.TraineeStateList;
                //Session["District"] = viewModel.TraineeDistrictList;
                //Session["SubDistrict"] = viewModel.TraineeSubDistrictList;
                //Session["City"] = viewModel.TraineeVillageTownCityList;
                //Logger.LogMessage("GetConstituency ConstituencyList.Count:" + viewModel.ConstituencyList.Count);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return Json(viewModel.ConstituencyList, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Locations
        public ActionResult GetContactSearchDetails(string contactName)
        {
            ManageContacts manageContacts = new ManageContacts();
            IEnumerable<ManageContacts> manageContactsList = new List<ManageContacts>();
            try
            {
                string partnerId = Convert.ToString(SessionMgr.LoginUserDetails.PartnerId);
                string projectID = Convert.ToString(SessionMgr.ProjectID);
                if (contactName != null)
                {
                    manageContactsList = dbA.GetContactSearchDetails(projectID, partnerId, contactName);
                }
                ViewData["IsPopup"] = "true";
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return PartialView("_ContactSearch", manageContactsList);
        }

        public ActionResult AddSearchContactDetails(ManageContacts manageContacts)
        {
            //ManageContacts manageContacts = new ManageContacts();
            IList<ManageContacts> manageContactsList = new List<ManageContacts>();
            try
            {
                //manageContacts.ManageContactID = Convert.ToInt32(ManageContactID);
                //manageContacts.ContactName = ContactName;
                //manageContacts.Email = Email;
                //manageContacts.MobileNumber = MobileNumber;
                //manageContacts.AadhaarNumber = AadhaarNumber;
                //manageContacts.IsSpoc = false;
                //manageContacts.Status = 'N';
                //manageContactsList = dbA.GetContactDetails(locationID.ToInt(), SessionMgr.ProjectID, SessionMgr.LoginUserDetails.PartnerId.ToStr());

                bool flag = false;
                if (SessionMgr.ManageContacts != null)
                {
                    flag = SessionMgr.ManageContacts.Any(x => x.ManageContactID == manageContacts.ManageContactID.ToInt());
                }
                if (flag)
                {
                    return Json("Exists", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    if (SessionMgr.ManageContacts != null)
                    {
                        manageContactsList = (List<ManageContacts>)SessionMgr.ManageContacts;
                    }
                    manageContactsList.Add(manageContacts);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.ManageContacts = manageContactsList;
            ViewData["IsPopup"] = "false";
            //ViewData["locationID"] = locationID;
            return PartialView("_ContactSearch", manageContactsList);
        }

        public ActionResult RemoveSearchContactDetails(string manageContactID)
        {
            IList<ManageContacts> manageContactsList = new List<ManageContacts>();
            try
            {
                manageContactsList = (List<ManageContacts>)SessionMgr.ManageContacts;
                var item = manageContactsList.FirstOrDefault(x => x.ManageContactID.ToString() == manageContactID);
                manageContactsList.Remove(item);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.ManageContacts = manageContactsList;
            ViewData["IsPopup"] = "false";
            //ViewData["locationID"] = locationID;
            return PartialView("_ContactSearch", manageContactsList);
        }
        /// <summary>
        /// Load location Hostel capacity edit
        /// </summary>
        /// <param name="isLoadLocation"></param>
        /// <param name="locationID"></param>
        /// <param name="projectID"></param>
        /// <param name="isViewLocation"></param>
        /// <returns></returns>
        #region New Locations
        public ActionResult LoadLocationDetails(bool isLoadLocation, int locationID, int projectID, bool isViewLocation)
        {
            SessionMgr.TrainingLocationsList = null;
            SessionMgr.ManageContacts = null;
            TrainingLocations trainingLocations = new TrainingLocations();
            if (isLoadLocation)
            {
                trainingLocations = dbA.BindLocationDetails(projectID, SessionMgr.PartnerID.ToInt(), locationID);
                if (isViewLocation)
                {
                    ViewBag.LocationTitle = locationID + " - " + trainingLocations.LocationName;
                    ViewBag.IsEdit = "false";
                }
                else
                {
                    ViewBag.LocationTitle = "Edit Location " + locationID + " - " + trainingLocations.LocationName;
                    ViewBag.IsEdit = "true";
                }
            }
            else
            {
                trainingLocations = dbA.BindLocationDetails();
                ViewBag.LocationTitle = "Add Location";
                ViewBag.IsEdit = "false";
            }

            //Manage contacts popup
            ManageContactsViewModel viewmodel = new ManageContactsViewModel();
            Session["OTP"] = null;
            viewmodel.AadhaarVerificationStatus = "Not Provided";
            viewmodel.MobileOTPVerificationStatus = "Not Provided";
            viewmodel.CreatedBy = SessionMgr.LoginUserDetails.UserId;
            dbA.GetAllDdlList(viewmodel);
            trainingLocations.ManageContactsDetails = viewmodel;

            trainingLocations.ProjectID = SessionMgr.ProjectID.ToInt();
            trainingLocations.TrainingType = SessionMgr.TrainingType;
            trainingLocations.TrainingTypeID = SessionMgr.TrainingTypeID.ToInt();
            trainingLocations.PartnerID = SessionMgr.PartnerID.ToInt();
            trainingLocations.PartnerName = SessionMgr.TrainingPartner;
            return PartialView("_Location", trainingLocations);
        }
        public ActionResult AddLocationJobRole(TrainingLocations location)
        {
            IList<TrainingLocations> locationList = new List<TrainingLocations>();
            try
            {
                bool isValid = true;
                if (SessionMgr.TrainingLocationsList.Count() > 0)
                {
                    //locationList = SessionMgr.TrainingLocationsList;
                    locationList = dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                    locationList = locationList.Concat(SessionMgr.TrainingLocationsList.Where(x => x.Status == 'N')).OrderBy(x => x.JobRoleID).ToList();
                    if (locationList.Any(x => x.JobRoleID == location.JobRoleID.ToInt()))
                    {
                        return Json("Exists", JsonRequestBehavior.AllowGet);
                    }
                    int? sumOflocationtarget = locationList.Sum(x => x.JobRoleTarget);
                    sumOflocationtarget = sumOflocationtarget.ToInt() + location.JobRoleTarget.ToInt();
                    Dictionary<string, string> retValue = dbA.ProjectWiseTarget(SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget.ToInt(), sumOflocationtarget.ToInt(), location.LocationID, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.PartnerID.ToInt());
                    string validationMessage = retValue["ValidMessage"];
                    int remainingTarget = retValue["RemaingTarget"].ToInt();
                    location.RemainingJobRoleTarget = remainingTarget;
                    if (validationMessage == "Valid")
                    {
                        locationList.Add(location);
                    }
                    else
                    {
                        isValid = false;
                        return Json(new { IsValid = isValid, validationMessage = validationMessage }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    locationList = dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                    if (locationList.Any(x => x.JobRoleID == location.JobRoleID.ToInt()))
                    {
                        return Json("Exists", JsonRequestBehavior.AllowGet);
                    }
                    int? sumOflocationtarget = locationList.Sum(x => x.JobRoleTarget);
                    sumOflocationtarget = sumOflocationtarget.ToInt() + location.JobRoleTarget.ToInt();
                    Dictionary<string, string> retValue = dbA.ProjectWiseTarget(SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget.ToInt(), sumOflocationtarget.ToInt(), location.LocationID, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.PartnerID.ToInt());
                    string validationMessage = retValue["ValidMessage"];
                    int remainingTarget = retValue["RemaingTarget"].ToInt();
                    location.RemainingJobRoleTarget = remainingTarget;
                    if (validationMessage == "Valid")
                    {
                        locationList.Add(location);
                    }
                    else
                    {
                        isValid = false;
                        return Json(new { IsValid = isValid, validationMessage = validationMessage }, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.TrainingLocationsList = locationList;
            return PartialView("_LocationJobRoleDetails", locationList);
        }
        public ActionResult EditLocationJobRole(TrainingLocations location)
        {
            IList<TrainingLocations> locationJobRoleList = new List<TrainingLocations>();
            try
            {
                bool isValid = true;
                //bool candidateCountStatus = true;
                char status;
                locationJobRoleList = dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                var itemResult = locationJobRoleList.FirstOrDefault(x => x.JobRoleID == location.JobRoleID);
                if (itemResult != null)
                    status = itemResult.Status;
                else
                {
                    status = 'N';
                }
                //if (status == 'I')
                //{
                //    candidateCountStatus = dbA.IsAllowToReduceCoutRespectToCadidate(location.JobRoleID, location.JobRoleTarget.ToInt());
                //    if (candidateCountStatus == false)
                //        return Json(new { IsValid = false, validationMessage = "Target Count Should not be reduced than Candidates Registered or Enrolled" }, JsonRequestBehavior.AllowGet);
                //}
                locationJobRoleList = locationJobRoleList.Concat(SessionMgr.TrainingLocationsList.Where(x => x.Status == 'N')).OrderBy(x => x.JobRoleID).ToList();
                //int? sumOflocationtarget = locationJobRoleList.Sum(x => x.JobRoleTarget);
                int? sumOflocationtarget = locationJobRoleList.Where(x => x.JobRoleID != location.JobRoleID).Sum(x => x.JobRoleTarget);
                sumOflocationtarget = sumOflocationtarget.ToInt() + location.JobRoleTarget.ToInt();
                Dictionary<string, string> retValue = dbA.ProjectWiseTarget(SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget.ToInt(), sumOflocationtarget.ToInt(), location.LocationID, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.PartnerID.ToInt());
                string validationMessage = retValue["ValidMessage"];
                int remainingTarget = retValue["RemaingTarget"].ToInt();
                location.RemainingJobRoleTarget = remainingTarget;
                if (validationMessage == "Valid")
                {
                    foreach (var item in locationJobRoleList.Where(w => w.JobRoleID == location.JobRoleID))
                    {
                        item.JobRoleTarget = location.JobRoleTarget;
                        item.RemainingJobRoleTarget = location.RemainingJobRoleTarget;
                        item.JobRoleName = location.JobRoleName;
                        item.SelectedJobRolesNames = location.SelectedJobRolesNames;
                        item.JobRoleID = location.JobRoleID;
                    }
                }
                else
                {
                    isValid = false;
                    return Json(new { IsValid = isValid, validationMessage = validationMessage }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.TrainingLocationsList = locationJobRoleList;
            return PartialView("_LocationJobRoleDetails", locationJobRoleList);
        }
        public ActionResult RemoveLocationJobRole(string JobRoleID, string locationID)
        {
            string result = string.Empty;
            string partialResult = string.Empty;
            string locationJobRolePartial = string.Empty;
            string projectJobRolePartail = string.Empty;
            bool isDataBaseDelete = false;
            IList<TrainingLocations> locationJobRoleList = new List<TrainingLocations>();
            try
            {
                locationJobRoleList = SessionMgr.TrainingLocationsList;
                var item = locationJobRoleList.FirstOrDefault(x => x.JobRoleID.ToString() == JobRoleID);
                var status = item.Status;
                if (status == 'I')
                {
                    result = dbA.RemoveLocationJobRole(SessionMgr.ProjectID.ToInt(), locationID.ToInt(), JobRoleID.ToInt(), SessionMgr.TrainingTypeID.ToInt());
                    locationJobRoleList = dbA.GetLocationJobRoleList(locationID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                    locationJobRoleList = locationJobRoleList.Concat(SessionMgr.TrainingLocationsList.Where(x => x.Status == 'N')).OrderBy(x => x.JobRoleID).ToList();
                    //Bind Project and Location
                    locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.PartnerId));
                    projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.PartnerId));
                    isDataBaseDelete = true;
                }
                else
                {
                    locationJobRoleList.Remove(item);
                    result = "Record has been Deleted Successfully";
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.TrainingLocationsList = locationJobRoleList;
            partialResult = ControllerContext.RenderPartialToString("_LocationJobRoleDetails", locationJobRoleList);
            return Json(new { partialResult = partialResult, status = result, isDataBaseDelete = isDataBaseDelete, locationJobRolePartial = locationJobRolePartial, projectJobRolePartail = projectJobRolePartail }, JsonRequestBehavior.AllowGet);
        }
        #endregion New Locations

        #region Existing Locations
        public ActionResult AddLocationJobRoleForExistingLocation(TrainingLocations location)
        {
            IList<TrainingLocations> locationList = new List<TrainingLocations>();
            var locationJobRolePartial = string.Empty;
            var projectJobRolePartail = string.Empty;
            var JobRolePartial = string.Empty;
            string validationMessage = string.Empty;
            int remainingTarget = 0;
            bool isValid = true;
            try
            {

                //locationList = SessionMgr.TrainingLocationsList;
                locationList = dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                //locationList = locationList.Concat(SessionMgr.TrainingLocationsList.Where(x => x.Status == 'N')).OrderBy(x => x.JobRoleID).ToList();
                if (locationList.Any(x => x.JobRoleID == location.JobRoleID.ToInt()))
                {
                    return Json("Exists", JsonRequestBehavior.AllowGet);
                }
                int? sumOflocationtarget = locationList.Sum(x => x.JobRoleTarget);
                sumOflocationtarget = sumOflocationtarget.ToInt() + location.JobRoleTarget.ToInt();
                Dictionary<string, string> retValue = dbA.ProjectWiseTarget(SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget.ToInt(), sumOflocationtarget.ToInt(), location.LocationID, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.PartnerID.ToInt());
                validationMessage = retValue["ValidMessage"];
                remainingTarget = retValue["RemaingTarget"].ToInt();
                location.RemainingJobRoleTarget = remainingTarget;
                if (validationMessage == "Valid")
                {
                    //locationList.Add(location);
                    var addition = dbA.AddLocationJobRole(SessionMgr.PartnerID.ToInt(), location.LocationID, SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget, SessionMgr.TrainingTypeID.ToInt());
                }
                else
                {
                    isValid = false;
                    return Json(new { IsValid = isValid, validationMessage = validationMessage }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            SessionMgr.TrainingLocationsList = locationList;
            projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId));
            locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.UserId));
            JobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleDetails", dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt()));
            return Json(new { JobRoleResult = JobRolePartial, locationJobRoleResult = locationJobRolePartial, projectJobRoleResult = projectJobRolePartail }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult EditLocationJobRoleForExistingLocation(TrainingLocations location)
        {
            IList<TrainingLocations> locationJobRoleList = new List<TrainingLocations>();
            var locationJobRolePartial = string.Empty;
            var projectJobRolePartail = string.Empty;
            var JobRolePartial = string.Empty;
            string validationMessage = string.Empty;
            int remainingTarget = 0;
            bool isValid = true;
            try
            {
                //bool candidateCountStatus = true;
                char status;
                locationJobRoleList = dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                var itemResult = locationJobRoleList.FirstOrDefault(x => x.JobRoleID == location.JobRoleID);
                if (itemResult != null)
                    status = itemResult.Status;
                else
                {
                    status = 'N';
                }
                //if (status == 'I')
                //{
                //    candidateCountStatus = dbA.IsAllowToReduceCoutRespectToCadidate(location.JobRoleID, location.JobRoleTarget.ToInt());
                //    if (candidateCountStatus == false)
                //        return Json(new { IsValid = false, validationMessage = "Target Count Should not be reduced than Candidates Registered or Enrolled" }, JsonRequestBehavior.AllowGet);
                //}
                locationJobRoleList = locationJobRoleList.Concat(SessionMgr.TrainingLocationsList.Where(x => x.Status == 'N')).OrderBy(x => x.JobRoleID).ToList();
                //int? sumOflocationtarget = locationJobRoleList.Sum(x => x.JobRoleTarget);
                int? sumOflocationtarget = locationJobRoleList.Where(x => x.JobRoleID != location.JobRoleID).Sum(x => x.JobRoleTarget);
                sumOflocationtarget = sumOflocationtarget.ToInt() + location.JobRoleTarget.ToInt();
                Dictionary<string, string> retValue = dbA.ProjectWiseTarget(SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget.ToInt(), sumOflocationtarget.ToInt(), location.LocationID, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.PartnerID.ToInt());
                validationMessage = retValue["ValidMessage"];
                remainingTarget = retValue["RemaingTarget"].ToInt();
                location.RemainingJobRoleTarget = remainingTarget;
                if (validationMessage == "Valid")
                {
                    var update = dbA.UpdateLocationJobRole(SessionMgr.PartnerID.ToInt(), location.LocationID, SessionMgr.ProjectID.ToInt(), location.JobRoleID, location.JobRoleTarget, SessionMgr.TrainingTypeID.ToInt());
                }
                else
                {
                    isValid = false;
                    return Json(new { IsValid = isValid, validationMessage = validationMessage }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId));
            locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.UserId));
            JobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleDetails", dbA.GetLocationJobRoleList(location.LocationID, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt()));
            return Json(new { JobRoleResult = JobRolePartial, locationJobRoleResult = locationJobRolePartial, projectJobRoleResult = projectJobRolePartail }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RemoveLocationJobRoleForExistingLocation(string JobRoleID, string locationID)
        {
            string result = string.Empty;
            string partialResult = string.Empty;
            string locationJobRolePartial = string.Empty;
            string projectJobRolePartail = string.Empty;
            bool isDataBaseDelete = false;
            try
            {
                result = dbA.RemoveLocationJobRole(SessionMgr.ProjectID.ToInt(), locationID.ToInt(), JobRoleID.ToInt(), SessionMgr.TrainingTypeID.ToInt());
                //Bind Project and Location
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            partialResult = ControllerContext.RenderPartialToString("_LocationJobRoleDetails", dbA.GetLocationJobRoleList(locationID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt()));
            projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId));
            locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.UserId));
            isDataBaseDelete = true;
            return Json(new { partialResult = partialResult, status = result, isDataBaseDelete = isDataBaseDelete, locationJobRolePartial = locationJobRolePartial, projectJobRolePartail = projectJobRolePartail }, JsonRequestBehavior.AllowGet);
        }
        #endregion Existing Location

        [HttpPost]
        public ActionResult SubmitLocation(TrainingLocations viewModel)
        {
            var status = string.Empty;
            var redirectUrl = string.Empty;
            var infoMessage = string.Empty;
            string password = string.Empty;
            var locationJobRolePartial = string.Empty;
            var projectJobRolePartail = string.Empty;
            // bool isNewLocation = false;
            //if (viewModel.LocationID == 0)
            //    isNewLocation = true;
            //else
            //    isNewLocation = false;

            viewModel.ManageContactsList = SessionMgr.ManageContacts;
            viewModel.LocationJobRoleDetailsList = SessionMgr.TrainingLocationsList;
            try
            {
                if (viewModel.LocationID == 0)
                {
                    if (viewModel.SelectedSPOCID != 0)
                    {
                        var toupdate = viewModel.ManageContactsList.Where(x => x.ManageContactID == viewModel.SelectedSPOCID);//Update the Selected SPOC Flag
                        foreach (var item in toupdate)
                        {
                            item.IsSpoc = true;
                            bool isExists = IsSPOCEXISTS(viewModel.SelectedSPOCID.ToInt());
                            if (isExists)
                            {
                                ModelState.AddModelError("SelectedSPOCID", "Selected User is Already SPOC to Another Location. Please Select Another User for SPOC");
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("SelectedSPOCID", "Please select the SPOC for the Location");
                    }
                }

                if (ModelState.IsValid)
                {
                    viewModel.ProjectID = SessionMgr.ProjectID.ToInt();
                    viewModel.PartnerID = SessionMgr.PartnerID.ToInt();
                    viewModel.ContactID = SessionMgr.LoginUserDetails.ContactId;
                    //viewModel.ManageContactsDetails.RandomPassword = Utility.GenerateRandomPassword(out password);

                    foreach (var contact in viewModel.ManageContactsList)
                    {
                        contact.NewEncPassword = Utility.GenerateRandomPassword(out password);
                        contact.NewPassword = password;
                    }
                    if (viewModel.LocationID != 0)
                        viewModel.LocationJobRoleDetailsList = dbA.GetLocationJobRoleList(viewModel.LocationID, viewModel.ProjectID, SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                    var result = dbA.SaveLocation(viewModel);
                    if (result.Columns.Contains("Successfull"))
                    {
                        status = Convert.ToString(result.Rows[0]["Successfull"]);
                        if (status.Trim() == "AddedSuccessfully")
                        {
                            var newLocationId = Convert.ToInt32(result.Rows[0]["LocationID"]);
                            string manageContactID = string.Empty;

                            foreach (var item in viewModel.ManageContactsList)
                            {
                                manageContactID += item.ManageContactID + ",";
                            }
                            if (!string.IsNullOrEmpty(manageContactID))
                            {
                                manageContactID = manageContactID.Substring(0, manageContactID.Length - 1);
                                var userDetails = dbA.GetUserDetails(manageContactID);
                                foreach (var item in userDetails)
                                {
                                    string pwd = Encryption.DecryptPassword(item.Password);

                                    bool emailStatus = Utility.SendEmailsToUsers(item.Fullname, item.EMail, item.Username, pwd);

                                    if (emailStatus)
                                        dbA.InsertEmailSendingStatus(item.UserId, item.EMail, 1);

                                    else
                                        dbA.InsertEmailSendingStatus(item.UserId, item.EMail, 0);
                                }
                            }

                            //if (isNewLocation)
                            //{
                            //    var usersForLocation = dbA.GetUsersForLocation(newLocationId);
                            //    var spocResult = viewModel.ManageContactsList.Where(x => x.IsSpoc == true);
                            //    //int spocContact = viewModel.ManageContactsList.Where(x => x.ManageContactID == viewModel.SelectedSPOCID).ToInt();
                            //    int spocContact = spocResult.FirstOrDefault(x => x.IsSpoc == true).ManageContactID;
                            //    foreach (DataRow row in usersForLocation.Rows)
                            //    {
                            //        if (Convert.ToInt32(row["ContactID"]) == spocContact)
                            //        {
                            //            if (viewModel.ManageContactsList.Any(x => (x.ManageContactID == Convert.ToInt32(row["ContactID"]) && x.IsSpoc == true)))
                            //            {
                            //                var passwordObj = viewModel.ManageContactsList.Where(x => x.IsSpoc == true && x.ManageContactID == Convert.ToInt32(row["ContactID"])).FirstOrDefault();
                            //                ManageContacts vm = new DbAction().GetContactByContact(passwordObj.ManageContactID);
                            //                Utility.SendEmailsToUsers(viewModel.LocationName, vm.Email, $"{row["Username"]}", passwordObj.NewPassword);
                            //            }
                            //        }
                            //    }
                            //}

                            //setting session elements back to blank
                            SessionMgr.ManageContacts = new List<ManageContacts>();
                            TempData["Status"] = "AddedSuccessfully";
                            status = "AddedSuccessfully";
                            TempData["TrainingType"] = SessionMgr.TrainingType;
                            TempDataDictionary temp = new TempDataDictionary { { "TrainingType", SessionMgr.TrainingType } };
                            projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId));
                            locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.UserId));
                        }
                    }
                    else
                    {
                        status = "Failure";
                        infoMessage = "Unable to save Location, Please try after sometime.";
                    }
                }
            }
            catch (Exception ex)
            {
                status = "Failure";
                infoMessage = "Some error has occured please try again later";
                Logger.LogException(ex);
            }
            infoMessage = string.Join("</br> ", ModelState.Values
                                    .SelectMany(x => x.Errors)
                                    .Select(x => x.ErrorMessage));
            //return RedirectToAction("TargetAllocation", "Projects", new { @TrainingTypeId = SessionMgr.TrainingTypeID, @projectid = SessionMgr.ProjectID});
            return Json(new { Status = status, RedirectUri = redirectUrl, InfoMessage = infoMessage, locationJobRoleResult = locationJobRolePartial, projectJobRolePartail = projectJobRolePartail });
        }
        private bool IsSPOCEXISTS(int manageContactID)
        {
            var result = dbA.CheckSPOCExists(manageContactID);
            if (result == 0)
                return false;
            else
                return true;
        }


        #endregion

    }
}