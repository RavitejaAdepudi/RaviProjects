﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Data;
using System.Web.Security;
using Newtonsoft.Json;
using PMU.Infrastructure;
using PMU.Models;
using PMU.Repository;

namespace PMU.Controllers
{
    // GET: Login
    public class LoginController : Controller
    {
        DbAction _dbA = new DbAction();

        [HttpGet]
        public ActionResult Login()
        {
            LoginViewModel ULoginModel = new LoginViewModel();
            return View(ULoginModel);

        }
        [HttpPost]
        public ActionResult Login(LoginViewModel loginobj)
        {
            Logger.LogMessage("Entered Login[Post] action in Login Controller" + loginobj);
            try
            {
                if (ModelState.IsValid)
                {
                    string result = "";
                    string uName = (loginobj.UserName);
                    string password = string.Empty;
                    Encryption encrypt = new Encryption();
                    var user = new UserModel();

                    password = Encryption.EncryptPassword(loginobj.Password);
                    Session["CCode"] = uName;

                    Logger.LogMessage("Login Post method after encryption :" + password);
                    if (string.IsNullOrEmpty(password))
                    {
                        loginobj.ErrorMessage = "Encryption failed.";
                        return View(loginobj);
                    }
                    else
                    {
                      
                        //------Checking last login date and password change date----//
                        DataTable dt = _dbA.CheckLastLoginDate(uName);
                        DataColumnCollection dtcolumns = dt.Columns;
                        if (dtcolumns.Contains("ContactID"))
                        {
                            user.ContactId = Convert.ToInt32(dt.Rows[0]["ContactID"]);
                        }
                        string lastlogin = dt.Rows[0]["Column1"].ToString();
                        if (lastlogin == "True-login")
                        {
                            loginobj.EncryError = "logincheck";
                            string loginaftrfourtyfive = lastlogin;
                            //Session["45daylogin"] = loginaftrfourtyfive;
                            return View(loginobj);
                        }
                        else if (lastlogin == "True-pass") // user didn't change password since 45 days.
                        {
                            loginobj.ErrorMessage = "Result";
                            string lastloginchangepwd = lastlogin;
                            //Session["45daypwdchange"] = lastloginchangepwd;
                            return View(loginobj);
                        }
                        //------ END--Checking last login date and password change date----//

                        var now = DateTime.UtcNow.ToLocalTime();
                        DataTable reader = _dbA.CheckUserIdPassword(uName, password);
                        if (reader.Rows.Count > 0 && reader.Rows[0][0].ToStr()!= "Not Exists")
                        {
                            //int nId = reader.Rows[0].IsNull("nID") ? 0 : Convert.ToInt32(reader.Rows[0]["nID"]);

                            user.Username = (string)reader.Rows[0]["Username"];
                            user.UserId = (int)reader.Rows[0]["UserID"];
                            user.CentreId = reader.Rows[0].IsNull("TCID") ? 0 : Convert.ToInt32(reader.Rows[0]["TCID"]);
                            user.PartnerId = reader.Rows[0].IsNull("PartnerID") ? 0 : (int)(reader.Rows[0]["PartnerID"]);
                            user.ProjectId = reader.Rows[0].IsNull("ProjectID") ? 0 : (long)(reader.Rows[0]["ProjectID"]);
                            user.IsCentre = !Convert.ToBoolean(reader.Rows[0]["IsLocation"]);
                            user.IsLocation = reader.Rows[0].IsNull("IsLocation") ? false : Convert.ToBoolean(reader.Rows[0]["IsLocation"]);
                            user.SessionId = System.Web.HttpContext.Current.Session.SessionID;
                            user.EMail = reader.Rows[0].IsNull("Email") ? "" : Convert.ToString(reader.Rows[0]["Email"]);
                            user.Fullname = (string)reader.Rows[0]["Fullname"];
                            user.ContactId = reader.Rows[0].IsNull("nID") ? 0 : Convert.ToInt32(reader.Rows[0]["nID"]);
                            user.TrainingType = Convert.ToInt32(reader.Rows[0]["TrainingType"]);

                            //Remember Me
                            user.RememberMe = loginobj.RememberMe;
                            Session["UserModel"] = user;

                            Logger.LogMessage("Login Post method if count is > 0:" + user.ContactId + user.CentreId + user.EMail + user.SessionId);
                            ModelState.Clear();

                            //checking already login or not
                            DataTable dtble = _dbA.CheckLoginRecord(user.CentreId, user.ContactId, user.SessionId, user.UserId, 1);
                            if (dtble.Rows.Count > 0)
                            {
                                for (int i = 0; i < dtble.Rows.Count; i++)
                                {
                                    result = dtble.Rows[i][0].ToString();
                                    if (result == "Active Session already exists")
                                    {
                                        loginobj.Confirmation = "Active";
                                        Logger.LogApplicationData("Login", "Login[Post]", uName, "Another login already exists ");
                                        return View(loginobj);
                                    }
                                }
                            }
                            else
                            {
                                //Checking first time login or not
                                DataTable dtable = _dbA.CheckLoginDate(user.ContactId, user.UserId);
                                string firstLogin = dtable.Rows[0]["Column1"].ToString();
                                if (firstLogin == "True")
                                {
                                    //insert login record into tbl_Login
                                    DataTable dttbl = _dbA.InsertLoginRecord(user.CentreId, user.ContactId, user.EMail, user.SessionId, user.UserId, null, 1);
                                }
                                else
                                {
                                    //inserting login record into tbl_Login
                                    DataTable dttble = _dbA.InsertLoginRecord(user.CentreId, user.ContactId, user.EMail, user.SessionId, user.UserId, null, 1);
                                }
                                string landingPage = reader.Columns.Contains("TPValidationStatus") ? Convert.ToString(reader.Rows[0]["TPValidationStatus"]) : "";
                                if (landingPage == "TC Validation Details")
                                {
                                    user.UserRoles = _dbA.GetUserRoles(user.Username);
                                    user.Permissions = _dbA.GetUserPermissions(user.Username);
                                    user.LandingPage = landingPage;
                                    Session["UserModel"] = user;

                                    //start of User Belongs to 
                                    Session["IsDisplayCeremonyTab"] = false;
                                    char[] specialChars = "-".ToCharArray();
                                    int indexOf = uName.IndexOfAny(specialChars);

                                    if (indexOf != -1)
                                    {
                                        string[] userBelongsTo = uName.Split(new string[] {"-"}, StringSplitOptions.None);
                                        Session["IsDisplayCeremonyTab"] = (userBelongsTo[0].ToUpper() == "RPL" )? true : false;
                                    }
                                    //End of User Belongs to 

                                    // Set the cookie value.
                                    var encryptedCookie = BasicCipher.Encrypt(JsonConvert.SerializeObject(user), ConfigurationManager.AppSettings["EncryptionKey"]);
                                    return RedirectToAction("Projects", "Projects");
                                }
                                else
                                {
                                    RedirectToAction("Logout");
                                }
                            }
                        }
                        else
                        {
                            result = "Mail ID is not registered";
                            loginobj.MessageAlert = "NotRegistered";
                            Logger.LogApplicationData("Login", "Login", uName + password, "Mail ID is not registered");
                            ModelState.AddModelError("UserName", "Username/Password entered is incorrect");
                            return View(loginobj);
                        }
                    }
                }
            }//logger if block closing.
            catch (Exception w)
            {
                Logger.LogMessage("Login post catch block" + w.Message);
                Logger.LogException(w);
                loginobj.MessageAlert = "NotRegistered";
                return View(loginobj);
            }
            return View(loginobj);
        }

        

        [HttpPost]
        public ActionResult Logout()
        {
            var user = new UserModel();
            HttpCookie authCookie = Request.Cookies["pmu.nsdcindia.org"];
            if (Session["UserModel"] == null)
            {
                if (authCookie != null)
                {
                    var decryptedObject = BasicCipher.Decrypt(authCookie.Value,
                        ConfigurationManager.AppSettings["EncryptionKey"]);

                    user = JsonConvert.DeserializeObject<UserModel>(decryptedObject);
                    Logger.LogApplicationData("Login", "SessionLogout", decryptedObject, "Cookie decrypted Successfully");
                }
            }
            else
            {
                user = (UserModel)Session["UserModel"];
            }
            if (user.UserId != 0)
            {
                var dt = _dbA.InsertSessionLogoutRecord(user.ContactId, user.CentreId, user.SessionId, user.UserId);
                if (authCookie != null)
                {
                    authCookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(authCookie);
                }
                Logger.LogApplicationData("Login", "SessionLogout", $"{user.UserId}", "SessionLogout Successfully");
            }
            Session.Clear();
            Session.Abandon();
            ViewBag.Message = "Session Expired. Please Login again.";
            return RedirectToAction("Login", "Login");
        }
        [HttpGet]
        public ActionResult SessionLogout()
        {
            //use global variables to store values.
            HttpCookie authCookie = Request.Cookies["pmu.nsdcindia.org"];
            if (authCookie != null)
            {
                var decryptedObject = BasicCipher.Decrypt(authCookie.Value, ConfigurationManager.AppSettings["EncryptionKey"]);
                var user = JsonConvert.DeserializeObject<UserModel>(decryptedObject);
                Logger.LogApplicationData("Login", "SessionLogout", decryptedObject, "Cookie decrypted Successfully");
                DataTable dt = _dbA.InsertSessionLogoutRecord(user.ContactId, user.CentreId, user.SessionId, user.UserId);
                Logger.LogApplicationData("Login", "SessionLogout", $"{user.UserId}", "SessionLogout Successfully");
                Session.Clear();
                Session.Abandon();
                ViewBag.Message = "Session Expired. Please Login again.";
                return RedirectToAction("Login", "Login");
            }
            else
            {
                return RedirectToAction("Login", "Login");
            }
        }
        [HttpGet]
        public ActionResult ForceLogout()
        {
            var user = new UserModel();
            HttpCookie authCookie = Request.Cookies["pmu.nsdcindia.org"];
            if (Session["UserModel"] == null)
            {
                if (authCookie != null)
                {
                    var decryptedObject = BasicCipher.Decrypt(authCookie.Value,
                        ConfigurationManager.AppSettings["EncryptionKey"]);

                    user = JsonConvert.DeserializeObject<UserModel>(decryptedObject);
                    Logger.LogApplicationData("Login", "SessionLogout", decryptedObject, "Cookie decrypted Successfully");
                }
            }
            else
            {
                user = (UserModel)Session["UserModel"];
            }

            if (user.UserId != 0)
            {
                var dt = _dbA.InsertForceLogoutRecord(user.ContactId, user.CentreId, user.SessionId, user.UserId);
                if (authCookie != null && !user.RememberMe)
                {
                    authCookie.Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies.Add(authCookie);
                }
                Logger.LogApplicationData("Login", "SessionLogout", $"{user.UserId}", "ForceLogout Successfully");
            }


            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Login", "Login");
        }

        [HttpGet]
        public ActionResult NotNormalLogout()
        {
            //var contactId = Convert.ToInt32(Session["ContactID"]);
            //var tcid = Convert.ToInt32(Session["TCId"]);
            //string sessionId = Convert.ToString(Session["sessionid"]);
            //string email = Convert.ToString(Session["Email"]);
            var user = (UserModel)Session["UserModel"];
            DataTable dt = _dbA.InsertNotNormalLogout(user.ContactId, user.CentreId, user.SessionId, user.UserId);
            Logger.LogApplicationData("Login", "NotNormalLogout", user.CentreId + user.SessionId, "NotNormalLogout Successfully");
            Session.Clear();
            Session.Abandon();
            ViewBag.myVar = "Please login again";
            return RedirectToAction("Login", "Login");
        }
    }
}