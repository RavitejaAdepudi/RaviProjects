﻿using PMU.Infrastructure;
using PMU.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PMU.Controllers
{
    public class LogoVerificationController : Controller
    {
        DbAction dbA = new DbAction();
        // GET: LogoVerification
        [HttpGet]
        public ActionResult LogoVerification(string logo)
        {
            LogoVerification objLogoVerification = new LogoVerification();
            var base64EncodedBytes = Convert.FromBase64String(logo);
            string decodedString = Encoding.UTF8.GetString(base64EncodedBytes);
            objLogoVerification.UserId = Convert.ToInt32(decodedString.Split('+')[1]);
            objLogoVerification.AssetId = Convert.ToInt32(decodedString.Split('+')[0]);
            objLogoVerification.CurrentStatus = dbA.GetCurrentStatus(Convert.ToInt32(objLogoVerification.AssetId));
            ViewBag.CurrentStatus = objLogoVerification.CurrentStatus;
            ViewBag.DisplayStatus = decodedString.Split('+')[2];
            return View(objLogoVerification);
        }
        public JsonResult ApproveLogo(string assetId, string userId)
        {
            int isSuccess = 0;
            string reason = "";
            int isApprove = 1;
            isSuccess = dbA.ApproveOrRejectLogo(Convert.ToInt32(assetId), reason, Convert.ToInt32(userId), isApprove);
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public JsonResult RejectLogo(string assetId, string reason, string userId)
        {
            int isSuccess = 0;
            int isApprove = 0;
            isSuccess = dbA.ApproveOrRejectLogo(Convert.ToInt32(assetId), reason, Convert.ToInt32(userId), isApprove);
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LogoPreview(string logo)
        {
            LogoVerification objLogoVerification = new LogoVerification();
            var base64EncodedBytes = Convert.FromBase64String(logo);
            string decodedString = Encoding.UTF8.GetString(base64EncodedBytes);
            objLogoVerification.AssetId = Convert.ToInt32(decodedString);
            MultiLogoList objDualMultiLogo = new MultiLogoList();
            objDualMultiLogo = dbA.LoadAssetById(objLogoVerification.AssetId);
           
            objLogoVerification.LogoFileImage = GetLogoImage(objDualMultiLogo.AlternateFileName, ConfigurationManager.AppSettings["LogoStorageFilePath"]);
            ViewBag.LogoImage = "data:image/png;base64,"+ objLogoVerification.LogoFileImage;
            return View();
        }

        public string GetLogoImage(string fileName, string path)
        {
            string strImage = "";
            try
            {
                if (Directory.Exists(path))
                {
                    string name = string.Empty;
                    var files = Directory.EnumerateFiles(path, fileName + "*.*", SearchOption.AllDirectories);

                    foreach (var item in files)
                    {
                        name = item;
                    }
                    if (name != "")
                    {
                        FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        br.Close();
                        fs.Close();
                        strImage = Convert.ToBase64String(bytes);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return strImage;
        }
    }
}