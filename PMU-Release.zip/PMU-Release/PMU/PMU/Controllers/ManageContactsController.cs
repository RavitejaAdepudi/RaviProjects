﻿using PMU.Infrastructure;
using PMU.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace PMU.Controllers
{
    [SessionExpire]
    public class ManageContactsController : Controller
    {
        private readonly string _url = "http://c20web1.saas.talismaonline.com/NSDC_Aadharcheck/MatchAadharService.asmx/MatchAadhar?AadharNumber=";
        private DbAction dbAction = new DbAction();

        [HttpGet]
        public ActionResult AddContacts()
        {
            ManageContactsViewModel viewmodel = new ManageContactsViewModel();
            Session["OTP"] = null;
            viewmodel.AadhaarVerificationStatus = "Not Provided";
            viewmodel.MobileOTPVerificationStatus = "Not Provided";
            viewmodel.CreatedBy = SessionMgr.LoginUserDetails.UserId;
            dbAction.GetAllDdlList(viewmodel);
            return View(viewmodel);
        }

        [HttpPost]
        public JsonResult AddContacts(ManageContactsViewModel viewModel)
        {
            ManageContactsOutPut _ManageContactsOutPut = new ManageContactsOutPut();
            var status = "";
            var redirectUrl = "";
            var infoMessage = "";
            if (viewModel.Type == "I")
            {
                var records = dbAction.RemoteSeverValidationTrainingPartner(viewModel.EmailAddress, "Email address", "Manage Contact");
                if (records != null && records.Rows.Count > 0)
                {
                    var msg = "This EmailID (" + records.Rows[0][2] + ") is already used by " + records.Rows[0][1] + "-" + records.Rows[0][3];
                    ModelState.AddModelError(viewModel.EmailAddress, msg);
                }
            }

            if (ModelState.IsValid)
            {
                //viewModel.ContactID = viewModel.ContactID;
                viewModel.PartnerID = viewModel.PartnerID;
                //viewModel.CentreID = viewModel.CentreID;

                viewModel.ContactID = SessionMgr.LoginUserDetails.ContactId;
                //viewModel.PartnerID = SessionMgr.LoginUserDetails.PartnerId;
                viewModel.CentreID = SessionMgr.LoginUserDetails.CentreId;

                viewModel.CreatedBy = SessionMgr.LoginUserDetails.UserId;
                string password = "";
                if (viewModel.Type == "I")
                {
                    var stringChars = new char[13];
                    var uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    var lowercase = "abcdefghijklmnopqrstuvwxyz";
                    var alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                    var random = new Random();
                    string caps = (Convert.ToString(uppercase[random.Next(uppercase.Length)]));
                    string smalls = (Convert.ToString(lowercase[random.Next(lowercase.Length)]));
                    string result = caps + smalls;
                    for (int i = 3; i < 6; i++)
                    {
                        result = result + Convert.ToString(alphanumeric[random.Next(alphanumeric.Length)]);
                    }
                    result = result + "@" + DateTime.Now.Year.ToString();
                    password = result;

                    Encryption encrypt = new Encryption();
                    string encyptedpassword = Encryption.EncryptPassword(password);
                    viewModel.RandomPassword = encyptedpassword;
                }
                DataTable dt = new DataTable();
                dt = dbAction.CreateContacts(viewModel);
                if (dt.Columns.Contains("Column1"))
                {
                    string success = Convert.ToString(dt.Rows[0]["Column1"].ToString());
                    if (success == "AddedSuccessfully")
                    {
                        //Commented by Vasudev
                        //SendEmailsToPlacementOfficer(viewModel.ContactName, viewModel.EmailAddress, dt.Rows[0]["UserName"].ToString(), password);
                        _ManageContactsOutPut.IsSuccess = "Success";
                        _ManageContactsOutPut.UserName = dt.Rows[0]["UserName"].ToString();
                        _ManageContactsOutPut.Password = password;
                    }
                    else if (success == "UpdateSuccessfully")
                    {
                        _ManageContactsOutPut.IsSuccess = "Update";
                    }
                }
            }
            else
            {
                status = "Failure";
                infoMessage = string.Join("</br> ", ModelState.Values
                                        .SelectMany(x => x.Errors)
                                        .Select(x => x.ErrorMessage));
                return Json(new { Status = status, RedirectUri = redirectUrl, InfoMessage = infoMessage });
            }
            dbAction.GetAllDdlList(viewModel);
            return Json(_ManageContactsOutPut, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAadharCheck(string aadharNumber, string contactName, string gender)
        {
            var text = "Failure";
            try
            {
                var viewModel = new ManageContacts();
                var subSectorList = new List<DropDownDDL>();
                string ss = string.Empty;
                ss = aadharNumber + "&PIData=name=" + contactName + "||gender=" + gender;
                Logger.LogMessage("GetAadharCheck PIData:" + ss);
                string sss = _url + ss;
                var request = (HttpWebRequest)WebRequest.Create(sss);
                XmlDocument xmlDoc = new XmlDocument();

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
                        xmlDoc.LoadXml(reader.ReadToEnd());
                        text = xmlDoc.InnerText;
                    }
                }
                Logger.LogMessage("GetAadharCheck PIData:" + text);
                return Json(text, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json(text, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetMobileOtp(string mobileNo, string msgBody)
        {
            try
            {
                Logger.LogMessage("GetMobileOTP MobileNo,MsgBody:" + mobileNo + "," + msgBody);
                DataTable dt = new DataTable();
                string gStrSmsurl;

                gStrSmsurl = "http://alerts.sinfini.com/api/web2sms.php?workingkey=Ae51d4e35c281d49b295cff14fa4686cc&sender=NSDCSC&to=~@@Moblie~@@Number&message=~@@Message~@@";

                int iStartPosition;
                int iEndPosition;
                int iLength;
                string username = "username=";
                string password = "password=";
                int iUname = username.Length;
                int iPwd = password.Length;

                iStartPosition = gStrSmsurl.IndexOf("username=") + iUname;
                iEndPosition = gStrSmsurl.IndexOf("&", iStartPosition);
                iLength = iEndPosition - iStartPosition;
                string gUrlUserName = gStrSmsurl.Substring(iStartPosition, iLength);

                iStartPosition = gStrSmsurl.IndexOf("password=") + iPwd;
                iEndPosition = gStrSmsurl.IndexOf("&", iStartPosition);
                iLength = iEndPosition - iStartPosition;
                string gUrlPassword = gStrSmsurl.Substring(iStartPosition, iLength);

                string strMobileNumbers = mobileNo;
                string strUrlwithMessage = gStrSmsurl.Replace("~@@Moblie~@@Number", strMobileNumbers);

                string smsBody = string.Empty;
                if (!string.IsNullOrEmpty(msgBody))
                    smsBody = msgBody;
                else
                {
                    string lStrOtpNo;
                    //double lDblOTPNo;
                    Random random = new Random();
                    int randomNumber = random.Next(0, 9999);
                    nextcheck:
                    if (randomNumber.ToString().Length != 4)
                    {
                        randomNumber = random.Next(0, 9999);
                        goto nextcheck;
                    }
                    lStrOtpNo = "";
                    Session["OTP"] = null;
                    Session["OTP"] = randomNumber;

                    string strTpName = "NSDC";
                    lStrOtpNo = randomNumber.ToString();

                    smsBody = lStrOtpNo + " - is your OTP for " + strTpName;
                    Logger.LogMessage("GetMobileOTP OTP,SmsBody:" + Session["OTP"] + "," + smsBody);
                }
                int lIntSmsLen = smsBody.Length;
                string result = "Failure";
                strUrlwithMessage = strUrlwithMessage.Replace("~@@Message~@@", smsBody);
                var request = (HttpWebRequest)WebRequest.Create(strUrlwithMessage);
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        result = "Success";
                    }
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Logger.LogMessage("GetMobileOTP" + " FAIL : " + ex);
                return Json("Failure", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult EnterOtpCheck(string enterOtp)
        {
            bool isEnterOtpValid = false;

            if (Convert.ToInt32(Session["OTP"]) == Convert.ToInt32(enterOtp))
            {
                isEnterOtpValid = true;
                Session["OTP"] = null;
                Logger.LogMessage("EnterOTPCheck OTPValid:" + isEnterOtpValid);
            }
            return Json(isEnterOtpValid, JsonRequestBehavior.AllowGet);
        }

        public JsonResult OtpClear()
        {
            bool isOtpClear = false;

            if (Session["OTP"] != null)
            {
                isOtpClear = true;
                Session["OTP"] = null;
                Logger.LogMessage("OTPClear OTPValid:" + isOtpClear);
            }
            return Json(isOtpClear, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetAllContactsList(int userID, int? manageContactID)
        {
            // get Start (paging start index) and length (page size for paging)
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();

            //Get Sort columns value
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();

            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start != null ? Convert.ToInt32(start) : 0;
            int totalRecords = 0;

            var list = new List<ViewManageContacts>();

            DataTable dt = new DataTable();
            var model = new ViewManageContacts();
            dt = dbAction.GetAllContactList(userID, manageContactID);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ViewManageContacts obj = new ViewManageContacts()
                    {
                        ContactName = dr["Fullname"].ToString(),
                        ManageContactID = Convert.ToInt32(dr["ManageContactID"]),
                        EmailAddress = dr["Email"].ToString(),
                        MobileNumber = dr["MobileNumber"].ToString(),
                        AadhaarNumber = dr["AadhaarNumber"].ToString(),

                    };
                    list.Add(obj);
                }
            }

            var v = (from a in list select a);


            totalRecords = v.Count();
            var data = v.ToList();
            if (pageSize != -1)
                data = v.Skip(skip).Take(pageSize).ToList();

            return Json(new { draw = draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = data }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public PartialViewResult GetContactDetailsEdit(int userID, int? manageContactID)
        {

            ManageContactsViewModel viewmodel = new ManageContactsViewModel();
            DataTable dt = dbAction.GetAllContactList(userID, manageContactID);
            if (dt.Rows.Count > 0)
            {
                dbAction.GetAllDdlList(viewmodel);
                foreach (DataRow dr in dt.Rows)
                {
                    viewmodel.ContactName = dr["Fullname"].ToString();
                    viewmodel.ManageContactID = Convert.ToInt32(dr["ManageContactID"]);
                    viewmodel.EmailAddress = dr["Email"].ToString();
                    viewmodel.MobileNumber = dr["MobileNumber"].ToString();
                    viewmodel.AadhaarNumber = dr["AadhaarNumber"].ToString();
                    viewmodel.Gender = dr["Gender"].ToString();
                    viewmodel.Designation = dr["Designation"].ToString();
                    viewmodel.AadhaarVerificationStatus = dr["Aadhaar Verification Status"].ToString();
                    viewmodel.MobileOTPVerificationStatus = dr["Mobile OTP Verification Status"].ToString();
                    viewmodel.StdCode = dr["STDCode"].ToString();
                    viewmodel.LandlineNumber = dr["LandlineNo"].ToString();

                }

            }

            return PartialView("_EditManageContact", viewmodel);
        }

        [HttpGet]
        public JsonResult GetEmailMobileValidation(string controlValue, string controlType, string CalledBy)
        {
            var records = dbAction.RemoteSeverValidationTrainingPartner(controlValue, controlType, CalledBy);
            return Json(records, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult BacktoProject()
        {
            Session["IsBackRequest"] = "true";
            return RedirectToAction("Projects", "Profile");
        }

        private static void SendEmailsToPlacementOfficer(string name, string emailID, string loginid, string userPassword)
        {
            DbAction dba = new DbAction();
            Email mail = new Email();
            string body = string.Empty;

            try
            {
                EmailContent emailContent = new EmailContent();
                emailContent.Firstname = name;
                emailContent.EmailTo = emailID;
                emailContent.EmailCC = emailID;
                emailContent.loginID = loginid;
                emailContent.EmailBCC = ConfigurationManager.AppSettings["EmailBCC"].ToString().Split(',');
                emailContent.Subject = ConfigurationManager.AppSettings["ManageUserLoginDetails"].ToString();
                emailContent.Url = ConfigurationManager.AppSettings["WebsiteUrlSPIA"].ToString();
                emailContent.Randpassword = userPassword;
                emailContent.ContentId = "PMU";
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                emailContent.ContentPath = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/EmailContent/EmailContent.txt");

                Email.SendMailMailMessage(emailContent);

                //mail.SendMail(mm);
                //var result = dba.SendRequestAsync(emailContent);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
        }
    }
}
