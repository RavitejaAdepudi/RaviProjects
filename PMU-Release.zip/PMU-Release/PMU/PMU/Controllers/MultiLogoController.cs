﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMU.Models;
using System.Configuration;
using System.IO;
using System.Globalization;
using System.Data;
using System.Threading.Tasks;
using PMU.Infrastructure;

namespace PMU.Controllers
{
    [SessionExpire]
    public class MultiLogoController : Controller
    {
        // GET: MultiLogo
        DbAction dbA = new DbAction();

       

        public ActionResult AddNewLogoRequest()
        {
            DualMultiLogo objDualMultiLogo = new DualMultiLogo();
            objDualMultiLogo.LogoTypeList = dbA.GetDDLLogoType();
            return View(objDualMultiLogo);

        }

        public JsonResult DeleteLogo(string assetId)
        {
            int isSuccess = 0;
            int userId = ((UserModel)Session["UserModel"]).UserId;
            isSuccess = dbA.DeleteLogo(Convert.ToInt32(assetId),userId);
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public JsonResult RemoveAsset()
        {
            int isSuccess = 0;
            int userId = ((UserModel)Session["UserModel"]).UserId;
            HttpPostedFileBase file = Request.Files["fileUpload"];
            string extension = Path.GetExtension(file.FileName);
            string path = ConfigurationManager.AppSettings["LogoTempFilePath"];
            path = System.Web.HttpContext.Current.Server.MapPath(path);
            string[] files = System.IO.Directory.GetFiles(path, userId + ".*");
            if (files.Length > 0)
            {
                foreach (string f in files)
                {
                    path += "/" + userId + extension;
                    System.IO.File.Delete(f);
                    isSuccess = 1;
                }
            }
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }
        public JsonResult PreviewLogo(string assetId, string alternateFileName)
        {
            string imageString = "";
            bool isServerPath = false;
            if ((Convert.ToInt32(assetId) == 0) && (alternateFileName == ""))
            {
                isServerPath = true;
                int userId = ((UserModel)Session["UserModel"]).UserId;
                imageString = GetLogoImage(userId + ".*", ConfigurationManager.AppSettings["LogoTempFilePath"], isServerPath);
            }
            else if((Convert.ToInt32(assetId) != 0) && (alternateFileName == ""))
            {
                isServerPath = true;
                int userId = ((UserModel)Session["UserModel"]).UserId;
                imageString = GetLogoImage(userId + ".*", ConfigurationManager.AppSettings["LogoTempFilePath"], isServerPath);
            }
            else if ((Convert.ToInt32(assetId) != 0) && (alternateFileName != ""))
            {
                imageString = GetLogoImage(alternateFileName, ConfigurationManager.AppSettings["LogoStorageFilePath"], isServerPath);
            }
            return Json(imageString, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LoadAssetById(string assetId)
        {
            MultiLogoList objDualMultiLogo = new MultiLogoList();
            objDualMultiLogo = dbA.LoadAssetById(Convert.ToInt32(assetId));
            var logoTypeStr = objDualMultiLogo.LogoType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp";
            objDualMultiLogo.LogoFilePath = Url.Action("DownloadLogo", "MultiLogo", new { filePath = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], logoTypeStr) + objDualMultiLogo.AlternateFileName, fileName = objDualMultiLogo.OriginalFileName });
            return Json(objDualMultiLogo, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveLogo()
        {
            int isSuccess = 0;
            int userId = ((UserModel)Session["UserModel"]).UserId;
            HttpPostedFileBase file = Request.Files["fileUpload"];
            string path = ConfigurationManager.AppSettings["LogoTempFilePath"];
            string getFileName = Path.GetFileName(file.FileName);
            string extension = Path.GetExtension(file.FileName);
            path = System.Web.HttpContext.Current.Server.MapPath(path);

            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);

            string[] files = System.IO.Directory.GetFiles(path, userId + ".*");
            if (files.Length > 0)
            {
                foreach (string f in files)
                {
                    path += "/" + userId + extension;
                    System.IO.File.Delete(f);
                    file.SaveAs(path);
                }
            }
            else
            {
                path += "/" + userId + extension;
                file.SaveAs(path);
            }
            isSuccess = 1;
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SubmitLogoForVerification()
        {
            string assetId = Request.Form["assetId"];
            string logoTypeId = Request.Form["logoTypeId"];
            string assetName = Request.Form["assetName"];
            string logoType = Request.Form["logoTypeVal"];
            var logoTypeStr = logoType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp";

            HttpPostedFileBase file= Request.Files["fileUpload"];
            int isSuccess = 0;
            int userId = ((UserModel)Session["UserModel"]).UserId;
            DualMultiLogo objDualMultiLogo = new DualMultiLogo();
            objDualMultiLogo.AssetId = Convert.ToInt32(assetId);
            objDualMultiLogo.LogoTypeId = Convert.ToInt32(logoTypeId);
            objDualMultiLogo.AssetName = assetName;
            objDualMultiLogo.CreatedBy = userId;
            objDualMultiLogo.TrainingType= ((UserModel)Session["UserModel"]).TrainingType;
            objDualMultiLogo.LogoTypeName = logoTypeStr;

            if ((objDualMultiLogo.AssetId != 0 && Request.Files.Count > 0)||(objDualMultiLogo.AssetId==0))
            {
                string getOriginalFileName = Path.GetFileNameWithoutExtension(file.FileName);
                string extension = Path.GetExtension(file.FileName);
                string getNewFileName = GetAlternateFileName(getOriginalFileName);

                string path = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], logoTypeStr);
                
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                var filename = $"{ logoTypeStr + "_" + DateTime.Now.Ticks}";
                path += "/" + filename + extension;
                file.SaveAs(path);
                int width = Convert.ToInt32(ConfigurationManager.AppSettings["ImageOptimizeWidth"]);
                int height = Convert.ToInt32(ConfigurationManager.AppSettings["ImageOptimiseHeight"]);

                objDualMultiLogo.OriginalFileName = getOriginalFileName + extension;
                objDualMultiLogo.AlternateFileName = filename + extension;
            }
            isSuccess = dbA.SubmitLogoForVerification(objDualMultiLogo);
          
                return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public string GetAlternateFileName(string fileName)
        {
            string alternateFileName = "";
            if (fileName != "")
            {
                string timestamp = DateTime.Now.ToString("hh.mm.ss.ffffff");
                alternateFileName = fileName.ToUpper() + "_" + timestamp;
            }
            return alternateFileName;
        }

        [HttpPost]
        public ActionResult LoadAllLogos(string searchByLogoType)
        {
            // get Start (paging start index) and length (page size for paging)
            var draw = Request.Form.GetValues("draw").FirstOrDefault();
            var start = Request.Form.GetValues("start").FirstOrDefault();
            var length = Request.Form.GetValues("length").FirstOrDefault();
            //var search = Request.Form.GetValues("search[value]").FirstOrDefault();
            //Get Sort columns value
            var sortColumn = Request.Form.GetValues("columns[" + Request.Form.GetValues("order[0][column]").FirstOrDefault() + "][name]").FirstOrDefault();
            var sortColumnDir = Request.Form.GetValues("order[0][dir]").FirstOrDefault();

            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start != null ? Convert.ToInt32(start) : 0;
            int totalRecords = 0;
            int trainingType = ((UserModel)Session["UserModel"]).TrainingType;
            try {
                DataTable dt = new DataTable();
                DualMultiLogo objDualMultiLogo = new DualMultiLogo();

                dt = dbA.GetAllLogos(skip, pageSize, sortColumn, sortColumnDir, searchByLogoType, trainingType);
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        MultiLogoList objModel = new MultiLogoList();
                        objModel.SerialNumber = dr["SerialNumber"] == DBNull.Value ? 0 : Convert.ToInt32(dr["SerialNumber"]);
                        objModel.LogoTypeId = dr["LogoTypeId"] == DBNull.Value ? 0 : Convert.ToInt32(dr["LogoTypeId"]);
                        objModel.LogoType = dr["LogoType"] == DBNull.Value ? string.Empty : Convert.ToString(dr["LogoType"]);
                        objModel.AssetId = dr["AssetId"] == DBNull.Value ? 0 : Convert.ToInt32(dr["AssetId"]);
                        objModel.AssetName = dr["AssetName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AssetName"]);
                         objModel.OriginalFileName= dr["OriginalFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["OriginalFileName"]);
                        objModel.AlternateFileName = dr["AlternateFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AlternateFileName"]);
                        objModel.Status = dr["Status"] == DBNull.Value ? string.Empty : Convert.ToString(dr["Status"]);
                        objModel.CreatedOn = dr["CreatedOn"] == DBNull.Value ? null : Convert.ToDateTime(dr["CreatedOn"]).ToString("dd-MMM-yyyy");
                        objModel.ApprovedBy = dr["ApprovedBy"] == DBNull.Value ? string.Empty : Convert.ToString(dr["ApprovedBy"]);
                        objModel.Reason = dr["ReasonForRejection"] == DBNull.Value ? string.Empty : Convert.ToString(dr["ReasonForRejection"]);
                        objModel.ApprovedOn = dr["ApprovedOrRejectedDate"] == DBNull.Value ? null : Convert.ToDateTime(dr["ApprovedOrRejectedDate"]).ToString("dd-MMM-yyyy");
                        objModel.LogoFileImage = GetLogoImage(objModel.AlternateFileName, ConfigurationManager.AppSettings["LogoStorageFilePath"],false);

                        var logoTypeStr = objModel.LogoType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp";
                        objModel.LogoFilePath = Url.Action("DownloadLogo", "MultiLogo", new { filePath = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], logoTypeStr) + objModel.AlternateFileName ,fileName= objModel.OriginalFileName});
                       
                        totalRecords = dr["TotalRecords"] == DBNull.Value ? 0 : Convert.ToInt32(dr["TotalRecords"]);
                        objDualMultiLogo.MultiLogoList.Add(objModel);
                    }
                }

                var v = (from a in objDualMultiLogo.MultiLogoList select a);

                // totalRecords = v.Count();
                var data = v.ToList();
                //if (pageSize != -1)
                //    data = v.Skip(skip).Take(pageSize).ToList();
                var jsonResult = Json(new { draw = draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = data }, JsonRequestBehavior.AllowGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;
            }
            catch (Exception ex)
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }
           
        }

        public string GetLogoImage(string fileName,string path,bool isServerPath)
        {
            string strImage = "";
            try
            {
                //string path = ConfigurationManager.AppSettings["LogoFilePath"];

               // path += "/" + fileName;
               if(isServerPath)
                path = System.Web.HttpContext.Current.Server.MapPath(path);
                if (Directory.Exists(path))
                {
                    string name = string.Empty;
                    var files = Directory.EnumerateFiles(path, fileName + "*.*", SearchOption.AllDirectories);

                    foreach (var item in files)
                    {
                        name = item;
                    }
                    if (name != "")
                    {
                        FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        br.Close();
                        fs.Close();
                        strImage = Convert.ToBase64String(bytes);
                    }
                }              
            }
            catch (Exception ex)
            {

            }
            return strImage;
        }

        [HttpGet]
        public ActionResult DownloadLogo(string filePath,string fileName)
        {
            string path = filePath;
            string downloadFileName = Path.GetFileName(path);
            return File(path, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
    }
}