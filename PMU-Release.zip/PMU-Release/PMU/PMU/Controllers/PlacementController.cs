﻿using PMU.Infrastructure;
using PMU.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web.Mvc;

namespace PMU.Controllers
{
    public class PlacementController : Controller
    {
        // GET: Placement
        DbAction dbA = new DbAction();

        #region TraingCenterDetails
        public ActionResult PlacementTCDetails()
        {
            Placements viewModel = new Placements();
            viewModel.TriningTypeDDl = dbA.GetCommonDropdownLookup(PropertyLookup.GetTrainingTypes, TabLookup.CandidateDetails);
            viewModel.VerificationStatusDDl = dbA.GetCommonDropdownLookup(PropertyLookup.VerficationStatus);
            viewModel.TrainingLocationList = dbA.GetTraingcentersforVerification(null, null);
            return View(viewModel);
        }
        public ActionResult GetPlacementTrainingCerters(string tringTypeID,string verificationStatusID)
        {
            IList<TrainingLocations> list = new List<TrainingLocations>();
            list = dbA.GetTraingcentersforVerification(tringTypeID, verificationStatusID);
            return PartialView("_TCDetailsList", list);
        }

        #endregion

        #region BatchDetails
        public ActionResult PlacementBatchDetails(string LocationID)
        {
            BatchDetails viewModel = new BatchDetails();
            viewModel.TriningTypeDDl = dbA.GetCommonDropdownLookup(PropertyLookup.GetTrainingTypes, TabLookup.CandidateDetails);
            viewModel.VerificationStatusDDl = dbA.GetCommonDropdownLookup(PropertyLookup.VerficationStatus);
            viewModel.BatchDetailsList = dbA.GetBatchDetailsList(LocationID, null,null,null,null);
            return View(viewModel);
        }
        public ActionResult GetPlacementBatchDetails(string locationID, string fromDate,string todate,string traingTypeID, string statusID)
        {
            IList<BatchDetails> list = new List<BatchDetails>();
            if (Request.QueryString["LocationID"].ToStr()!=null)
            {
                try
                {
                    list = dbA.GetBatchDetailsList(locationID, traingTypeID, statusID,fromDate, todate );
                }
                catch (Exception ex)
                {
                    Logger.LogException(ex);
                }
                
            }
            else
            {
                RedirectToAction("PlacementTCDetails");
            }
            return PartialView("_BatchDetailsList", list);
        }
        #endregion

        #region CandidateDetails
        public ActionResult PlacementCandidateDetails(string batchID,string locationID)
        {
            CandidateEmploymentViewModel viewmodel = new CandidateEmploymentViewModel();
            CandidateEmploymentModel candidateEmploymentModel = new CandidateEmploymentModel();
            //viewmodel.CandidateDeatilList = BatchtoCandiadteDetails(SessionMgr.BatchID.ToInt());//View CandidateList
            //viewmodel.CandidateEmployment = BindCandEmploymentDetail(batchID);//BindCanidate Employment
            // viewmodel.EmployerDetailsModel = BindEmployerDropdowns();//Bind Employer Details
            viewmodel.CandEnrolment = new CandEnrolment();
            viewmodel.CandidateEligibleforPostPlacement= dbA.GetEligiblePlacementDetails(batchID, locationID,null);
            viewmodel.CandidateEmployment = candidateEmploymentModel;
            try
            {
                viewmodel.CandidateEmployment.CandidatesList = dbA.GetCandidateDropdownList(batchID.ToInt(), locationID.ToInt());//Candidates Dropdown
                viewmodel.CandidateDeatilList = dbA.BatchtoCandiadteDetails(batchID.ToInt(), locationID.ToInt());//View CandidateList
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
           
            return View(viewmodel);
        }
        [HttpPost]
        public ActionResult GetCandidateDetailsByID(string batchID, string candID,string locationID)
        {
            Session["CandID"] = candID;
            CandidateEmploymentViewModel viewmodel = new CandidateEmploymentViewModel();
            CandidateEmploymentModel candidateEmploymentModel = new CandidateEmploymentModel();
            try
            {
                if (!string.IsNullOrEmpty(candID))
                {
                    viewmodel.CandEnrolment = dbA.GetCandidateEnrollment(candID.ToInt());
                    viewmodel.CandidateEmploymentModelList = dbA.GetCandidateDetails(candID.ToInt());
                    viewmodel.CandEnrolment = new CandEnrolment();
                    viewmodel.CandidateEligibleforPostPlacement = dbA.GetEligiblePlacementDetails(batchID, locationID, candID);
                }
                else
                {
                    viewmodel.CandEnrolment = new CandEnrolment();
                    viewmodel.CandidateEmploymentModelList = new List<CandidateEmploymentModel>();
                    viewmodel.CandEnrolment = new CandEnrolment();
                }
                ViewBag.CandidateId = candID;
                viewmodel.CandidateEmployment = BindCandEmploymentDetails(batchID.ToInt(),locationID.ToInt());
                viewmodel.CandidateEmployment.CandidatesList = dbA.GetCandidateDropdownList(batchID.ToInt(), locationID.ToInt());//Candidates Dropdown
                viewmodel.CandidateDeatilList = dbA.BatchtoCandiadteDetails(batchID.ToInt(), locationID.ToInt());//View CandidateList
                viewmodel.PartialCandidateEmploymentModelList = ControllerContext.RenderPartialToString("_PlacementDetailsList", viewmodel.CandidateEmploymentModelList);
                viewmodel.PartialPostPlacementEligible = ControllerContext.RenderPartialToString("_EligiblePostPlacementList", viewmodel.CandidateEligibleforPostPlacement);
                viewmodel.CandidateEmployment.TotalDaysOfEmployment = GetTotalNoOfDays(viewmodel.CandidateEmploymentModelList).ToString();
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                //return Json(StatusMessages.Error, JsonRequestBehavior.AllowGet);
            }
            return Json(viewmodel,JsonRequestBehavior.AllowGet);
        }

        private int GetTotalNoOfDays(IList<CandidateEmploymentModel> objCandidateEmploymentList)
        {
            int cnt = objCandidateEmploymentList.Count;
            DateTime? todate;
            DateTime? fromdate;
            int? employmentDays = 0;
            int dayDiff = 0;

            if (cnt > 0)
            {
                List<CandidateEmploymentModel> candEmpList = new List<CandidateEmploymentModel>(objCandidateEmploymentList);
                if ((candEmpList.Exists(x => x.EmployerTypeDesc == "Wage Employment") || candEmpList.Exists(x => x.EmployerTypeDesc == "Self Employed")))
                {
                    foreach (CandidateEmploymentModel obj in objCandidateEmploymentList)
                    {
                        fromdate = string.IsNullOrEmpty(obj.FromDate) ? (DateTime?)null : DateTime.ParseExact(obj.FromDate, "dd-MMM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        todate = string.IsNullOrEmpty(obj.ToDate) ? (DateTime?)null : DateTime.ParseExact(obj.ToDate, "dd-MMM-yyyy", System.Globalization.CultureInfo.InvariantCulture);

                        if (fromdate == null || todate == null)
                            continue;

                        employmentDays += DaysDifference(todate, fromdate);
                    }
                }
            }
            dayDiff = employmentDays ?? default(int);
            return dayDiff;
        }
        private int? DaysDifference(DateTime? toDate, DateTime? fromdate)
        {
            int? days;

            if (toDate == null || fromdate == null)
                return 0;

            days = toDate.HasValue && fromdate.HasValue ? (int?)((toDate - fromdate).GetValueOrDefault().TotalDays) + 1 : null;

            return days;
        }
        private CandidateEmploymentModel BindCandEmploymentDetail(string batchID,string candidateID,string locationID)
        {
            CandidateEmploymentViewModel viewModel = new CandidateEmploymentViewModel();
            CandidateEmploymentModel candidateEmploymentModel = new CandidateEmploymentModel();
            try
            {
                if (!string.IsNullOrEmpty(candidateID))
                {
                    viewModel.CandEnrolment = dbA.GetCandidateEnrollment(candidateID.ToInt());
                    viewModel.CandidateEmploymentModelList = dbA.GetCandidateDetails(candidateID.ToInt());
                }
                else
                {
                    viewModel.CandEnrolment = new CandEnrolment();
                    viewModel.CandidateEmploymentModelList = new List<CandidateEmploymentModel>();
                }
                viewModel.PartialCandidateEmploymentModelList = ControllerContext.RenderPartialToString("_PlacementDetailsList", viewModel.CandidateEmploymentModelList);
               // ViewBag.CandidateId = SessionMgr.CandidateID;
                ViewBag.CandidateId = candidateID;
                viewModel.CandidateEmployment = BindCandEmploymentDetails(batchID.ToInt(), locationID.ToInt());
                //viewModel.EmployerDetailsModel = BindEmployerDropdowns();
                //ViewBag.BatchID = SessionMgr.BatchID;
                //viewModel.candEmpCount = viewmodel.CandidateEmploymentModelList.Count();
                //viewModel.IsEligiblePlacement = IsEligibleToPlacement(viewmodel.CandidateEmploymentModelList);
               // viewModel.CandidateEmployment.TotalDaysOfEmployment = GetTotalNoOfDays(viewmodel.CandidateEmploymentModelList).ToString();
            }
            catch (Exception)
            {
                throw;
            }
            return candidateEmploymentModel;
        }
        private CandidateEmploymentModel BindCandEmploymentDetails(int batchID,int locationID)
        {
            CandidateEmploymentModel candidateEmploymentModel = new CandidateEmploymentModel();
            try
            {
                candidateEmploymentModel.CandidatesList = dbA.GetCandidateDropdownList(batchID.ToInt(),locationID.ToInt());
                //candidateEmploymentModel.EmploymentTypeList = dbA.GetCommonDropdownLookup(Lookup.EmployerType);
                //candidateEmploymentModel.WageTypeOfDocumentProofList = dbA.GetCommonDropdownLookup(Lookup.WageEmploymentProof);
                //candidateEmploymentModel.SelfTypeOfDocumentProofList = dbA.GetCommonDropdownLookup(Lookup.SelfEmploymentProof);
                //candidateEmploymentModel.EmployerStateList = dbA.GetState();
                //var employerDistrictList = new List<DropDownDDL>();
                //candidateEmploymentModel.EmployerDistrictList = employerDistrictList;

                int totDaysOfEmp;
                candidateEmploymentModel.TotalDaysOfEmployment = int.TryParse(candidateEmploymentModel.TotalDaysOfEmployment, out totDaysOfEmp) ? totDaysOfEmp.ToString() : "0";
            }
            catch (Exception)
            {
                throw;
            }
            return candidateEmploymentModel;
        }
        public ActionResult CandidateDocumentVerfication(string CandEmpID)
        {
            CandidateEmploymentViewModel viewModel = new CandidateEmploymentViewModel();
            CandidateEmploymentModel candidateEmploymentModel = new CandidateEmploymentModel();
            try
            {
                viewModel.CandidateEmployment = dbA.GetCandidateEmploymentDetails(CandEmpID);
                viewModel.CandidateEmployment.VerificationReasonDdl = dbA.GetCommonDropdownLookup(PropertyLookup.ReasonVerificationStatus);
                viewModel.CandidateDocumentList = dbA.GetDocumentsDetails(CandEmpID);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
           
            return View(viewModel);
        }

        [HttpPost]
        public ActionResult SubmitCandidateVerification(string EmploymentDetailID,string ReasonID, string OtherDesc)
        {
            try
            {
                int result = dbA.SaveDocumentVerification(EmploymentDetailID, ReasonID, OtherDesc);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                return Json(new { status = "Failure" }, JsonRequestBehavior.AllowGet);
            }
            return Json(new {status = "Success" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DownloadCandidateDocuments(string fileName)
        {
            //string downloadFileName = Path.GetFileName(fileName);
           string virtualPath= Path.Combine(ConfigurationManager.AppSettings["PlacementCandidateFileLocation"], fileName);
            return File(virtualPath, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
        #endregion

    }
}