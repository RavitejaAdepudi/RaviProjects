﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.IO;
using PMU.Infrastructure;
using PMU.Repository;
using PMU.Models;
using System;
using System.Linq;
using Microsoft.Reporting.WebForms;
using System.Data;
using System.Configuration;

namespace PMU.Controllers
{
    [SessionExpire]
    public partial class ProjectsController : Controller
    {
        DbAction dbA = new DbAction();
        public DataAccess _dbA = new DataAccess();

        #region Projects

        [HttpGet]
        public ActionResult Projects()
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            _viewModel = BindSearchDropDowns(_viewModel);
            _viewModel.TrainingTypeID = 0;
            List<ProjectsModel> projectList = new List<ProjectsModel>();
            _viewModel.ProjectDetailsList = projectList;
            List<TrainingPartner> trainingPartnerList = new List<TrainingPartner>();
            _viewModel.TrainingPartnerList = trainingPartnerList;
            TrainingPartner trainingPartner = new TrainingPartner();
            _viewModel.TrainingPartnerDetails = trainingPartner;
            _viewModel.SectorTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.SectorList);
            //_viewModel.JobroleList = dbA.GetCommonDropdownLookup(PropertyLookup.JobRoleList);
            _viewModel.JobroleList = new List<DropDownDDL>();
            //_viewModel.ProjectTypeList = dbA.getProjectList(null, null, null, null, null);
            SessionMgr.ProjectID = null;
            SessionMgr.TrainingTypeID = null;
            SessionMgr.TrainingType = null;
            SessionMgr.PartnerID = null;
            SessionMgr.TrainingPartner = null;
            return View(_viewModel);
        }
        public ProjectViewModel BindSearchDropDowns(ProjectViewModel viewModel)
        {
            IList<DropDownDDL> projecList = new List<DropDownDDL>();
            viewModel.ProjectTypeList = projecList;
            viewModel.TrainingTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetTrainingTypes, TabLookup.CandidateDetails);
            viewModel.ProjectTypeList = projecList;
            //if (viewModel.TrainingType == "RPL")
            //{
            //    viewModel.ProjectTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.ProjectType, TabLookup.RPLProjectType);
            //}
            //else
            //{
            //    viewModel.ProjectTypeList = dbA.GetCommonDropdownLookup(PropertyLookup.GetProjectType, TabLookup.ProjectDetails);
            //}
            return viewModel;
        }


        public ActionResult GetProjectTypeByTrainingType(string trainingType)
        {
            IList<DropDownDDL> projectTypeddl = new List<DropDownDDL>();
            try
            {
                projectTypeddl = dbA.GetProjectTypeByTrainingType(trainingType);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            return Json(projectTypeddl, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Projects(ProjectViewModel _viewModel)
        {
            SessionMgr.ProjectJobRole = null;
            SessionMgr.TrainingType = _viewModel.TrainingType;
            SessionMgr.TrainingTypeID = _viewModel.TrainingTypeID;
            SessionMgr.PartnerID = _viewModel.TrainingPartnerID;
            SessionMgr.TrainingPartner = _viewModel.TrainingPartner;
            return RedirectToAction("CreateProject");
        }

        //Bind Table Project Details
        public ActionResult GetProjectList(string trainingTypeID, string partnerID, string projectTypeID, string sectorID, string jobRoleID, string trainingTypeName)
        {
            IList<ProjectsModel> projecttypelist = new List<ProjectsModel>();
            if (partnerID == "0")
                partnerID = null;
            projecttypelist = dbA.getProjectList(trainingTypeID, partnerID, projectTypeID, sectorID, jobRoleID);
            ViewBag.TrainingType = trainingTypeName;
            if (trainingTypeName != "RPL")
            {
                ViewBag.className = "protab_cont scrollTable ";
            }
            else
            {
                ViewBag.className = "listpage_conts scrollTable rpl_wid";
            }
            return PartialView("_ViewProjectDetails", projecttypelist);
        }

        //Bind Project Details Partial View
        public ActionResult ProjectsGetProjectDetails(string projectID, string trainingTypeID)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            _viewModel = dbA.getProjectDetails(trainingTypeID.ToInt(), projectID.ToInt());

            _viewModel.CustomTemplateType.CustomFileSelectedCorporate.Select(a =>
                {
                    a.FileSource = Url.Action("DownloadLogo", "MultiLogo", new { filePath = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], a.IndustryType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp") + a.FileName });
                    return a;
                }).ToList();

            _viewModel.CustomTemplateType.CustomFileSelectedGovt.Select(a => 
                 {
                     a.FileSource = Url.Action("DownloadLogo", "MultiLogo", new { filePath = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], a.IndustryType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp") + a.FileName  });
                     return a;
                 }).ToList();

            SessionMgr.ProjectJobRole = _viewModel.ProjectJobRoleList;
            var fileName = Path.GetFileName(_viewModel.FileName);
            _viewModel.CustomTemplateLogoURL = Path.Combine(Server.MapPath(_viewModel.CustomTemplateLogoURL), fileName);
            SessionMgr.TrainingType = _viewModel.TrainingType;

            _viewModel = BindDropDowns(_viewModel);
            _viewModel.ProjectJobRoleDetails = ProjectJobRole();
            _viewModel.TrainingPartnerDetails = TrainingTypeDetails();
            var requestedAction = Request.UrlReferrer.LocalPath;
            if (requestedAction != "/Projects/CreateProject")
                TempData["Status"] = string.Empty;
            else
            {
                TempData.Keep("Status");
            }
            Logger.LogMessage(requestedAction.ToString());

            return PartialView("_ViewProject", _viewModel);
        }

        public ActionResult DownloadCustomLogo(string fileName)
        {
            string downloadFileName = Path.GetFileName(fileName);
            return File(fileName, System.Net.Mime.MediaTypeNames.Application.Octet, Path.GetFileName(downloadFileName));
        }
        //Bind TrainingPartner Details Partial View
        //public ActionResult ProjectsGetPartnerDetails()
        //{
        //    ProjectsModel _viewModel = new ProjectsModel();
        //    return PartialView("_ViewTrainingPrtner", _viewModel);
        //}

        //Bind Partner Details From Partial View
        //public ActionResult ProjectsGetPartnerNameDetails(string partnername)
        //{
        //    ProjectViewModel _viewModel = new ProjectViewModel();

        //    _viewModel = dbA.getPartnerList(partnername);
        //    return PartialView("_ViewTrainingPrtner", _viewModel);
        //}

        public JsonResult GetJobRole(string JobRoleId)
        {
            int jobRoleID = Convert.ToInt32(JobRoleId);

            if (SessionMgr.ProjectJobRole == null)
                return null;

            var jobRole = SessionMgr.ProjectJobRole;

            return Json(jobRole.First(m => m.JobroleID == jobRoleID), JsonRequestBehavior.AllowGet);
        }

        public bool RemoveJobRoleStatus(string ProjectId, string JobRoleId)
        {
            bool result = dbA.GetJobRoleDelete(ProjectId.ToInt(), JobRoleId.ToInt());
            return result;
        }



        public PartialViewResult RemoveJobRole(string JobRoleId)
        {
            //    string result = dbA.GetJobRoleDelete(ProjectId.ToInt(), JobRoleId.ToInt());

            IList<ProjectJobRole> locationJobRoleList = new List<ProjectJobRole>();
            try
            {
                locationJobRoleList = SessionMgr.ProjectJobRole;
                var item = locationJobRoleList.FirstOrDefault(x => x.JobroleID == JobRoleId.ToInt());
                locationJobRoleList.Remove(item);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }
            SessionMgr.ProjectJobRole = locationJobRoleList;
            TempData["TrainingType"] = SessionMgr.TrainingType;
            return PartialView("_JobRoleTarget", locationJobRoleList);
        }

        public string DownloadProjectDetails(string ProjectID,
            string ProjectName, string TrainingTypeId)
        {
            try
            {
                Logger.LogMessage("Entered DownloadProjectDetails Method");

                DataTable projectDetails = dbA.GetProjectDetailsForDownload(TrainingTypeId.ToInt(),
                       ProjectID.ToInt());

                Logger.LogMessage("Got GetProjectDetailsForDownload Details");

                DataTable jobRoleDetails = dbA.GetProjectJobRoleDetailsForDownload(SessionMgr.LoginUserDetails.CentreId,
                     SessionMgr.LoginUserDetails.ContactId, TrainingTypeId.ToInt(),
                     ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId);

                Logger.LogMessage("Got DownloadProjectDetails Details");

                string FileName = ProjectID + '_' + ProjectName;
                string extension;
                string encoding;
                string mimeType;
                string[] streams;
                Warning[] warnings;
                LocalReport report = new LocalReport();
                report.ReportPath = Server.MapPath("~/Reports/ProjectDetails.rdlc");
                ReportDataSource reportSource = new ReportDataSource();
                reportSource.Name = "DataSet1";
                reportSource.Value = projectDetails;
                report.DataSources.Add(reportSource);

                ReportDataSource reportSource1 = new ReportDataSource();
                reportSource1.Name = "DataSet2";
                reportSource1.Value = jobRoleDetails;
                report.DataSources.Add(reportSource1);

                Logger.LogMessage("Entered Bytes Allocation");

                Byte[] mybytes = report.Render("PDF", null,
                                out extension, out encoding,
                                out mimeType, out streams, out warnings);

                Logger.LogMessage("Leave from Bytes Allocation");

                Response.ClearHeaders();
                Response.ClearContent();
                Response.Buffer = true;
                Response.Clear();
                Response.ContentType = "application/pdf";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + FileName + ".pdf");
                Response.BinaryWrite(mybytes);
                Response.Flush();
                Response.Close();
                Response.End();
                Logger.LogMessage("Leave from DownloadProjectDetails Method");
                return null;
            }

            catch (Exception ex)
            {
                Logger.LogMessage(ex.Message);
                return null;
            }
        }

        public ActionResult PrintProjectDetails(string ProjectID,
            string ProjectName, string TrainingTypeId)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            _viewModel = dbA.getProjectDetails(TrainingTypeId.ToInt(),
                 ProjectID.ToInt());
            SessionMgr.ProjectJobRole = _viewModel.ProjectJobRoleList;
            var fileName = Path.GetFileName(_viewModel.FileName);
            _viewModel.CustomTemplateLogoURL = Path.Combine(Server.MapPath(_viewModel.CustomTemplateLogoURL), fileName);
            SessionMgr.TrainingType = _viewModel.TrainingType;

            _viewModel = BindDropDowns(_viewModel);
            _viewModel.ProjectJobRoleDetails = ProjectJobRole();
            _viewModel.TrainingPartnerDetails = TrainingTypeDetails();

            return View("PrintProjectDetails", _viewModel);

        }

        public JsonResult CheckJobRoleLocation(string projectId,
            string jobroleId, string jobRoleTarget)
        {
            DataTable status = dbA.CheckJobRoleInLocation(projectId.ToInt(),
                jobroleId.ToInt(), jobRoleTarget.ToInt());

            Dictionary<string, string> result = new Dictionary<string, string>();
            result.Add(status.Columns[0].ColumnName,
                Convert.ToString(status.Rows[0][status.Columns[0].ColumnName]));
            result.Add(status.Columns[1].ColumnName,
              Convert.ToString(status.Rows[0][status.Columns[1].ColumnName]));

            System.Web.Script.Serialization.JavaScriptSerializer serial = new System.Web.Script.Serialization.JavaScriptSerializer();

            return Json(serial.Serialize(result), JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Template Custom for certificate 

        public JsonResult GetCustomTemplateOptions()
        {
            List<CustomTemplateType> customTemplateVal = new List<CustomTemplateType>();
            customTemplateVal = dbA.GetCertificateTemplateTypeLookup();
            return Json(customTemplateVal, JsonRequestBehavior.AllowGet);
        }

        private static String RenderRazorViewToString(ControllerContext controllerContext, string viewName, Object model)
        {
            controllerContext.Controller.ViewData.Model = model;
            using (var sw = new StringWriter())
            {
                var viewResult = ViewEngines.Engines.FindPartialView(controllerContext, viewName);
                var viewContext = new ViewContext(controllerContext, viewResult.View, controllerContext.Controller.ViewData, controllerContext.Controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);
                viewResult.ViewEngine.ReleaseView(controllerContext, viewResult.View);
                return sw.GetStringBuilder().ToString();
            }
        }

        [HttpPost]
        public ActionResult GetCustomTemplateSelectionRender(ProjectViewModel model, CustomTemplateType customLogoObj)
        {

            var partialView = string.Empty;

            for (int i = 1; i <= customLogoObj.GovtLogoCount; i++)
            {
                model.CustomTemplateType.CustomFileSelectedGovt.Add(new CustomFileDetail()
                {
                    FileNumber = i,
                });
            }
            for (int i = 1; i <= customLogoObj.CorporateLogoCount; i++)
            {
                model.CustomTemplateType.CustomFileSelectedCorporate.Add(new CustomFileDetail()
                {
                    FileNumber = i,
                });
            }
            model.CustomTemplateType.CorporateLogoCount = customLogoObj.CorporateLogoCount;
            model.CustomTemplateType.CustomType = customLogoObj.CustomType;
            model.CustomTemplateType.Id = customLogoObj.Id;
            model.CustomTemplateType.TriningType = customLogoObj.TriningType;
            model.CustomTemplateType.GovtLogoCount = customLogoObj.GovtLogoCount;
            model.CustomTemplateType.Position = customLogoObj.Position;

            return PartialView("_customLogoSelection", model);
        }

        [HttpPost]
        public ActionResult GetCustomTemplateSelectionRenderNew(ProjectViewModel model, CustomTemplateType customLogoObj)
        {
            model.CustomTemplateType = customLogoObj;
            return PartialView("_customLogoSelection", model);
        }
        [HttpPost]
        public ActionResult GetCustomTemplateSelectionRenderEmpty(ProjectViewModel model)
        {
            model.CustomTemplateType = new CustomTemplateType();
            return PartialView("_customLogoSelection", model);
        }

        [HttpPost]
        public ActionResult GetCustomTemplateLogoSearch(string logoType, string filterText, string controllToAssign)
        {

            var partialView = string.Empty;
            DataTable dt = new DataTable();
            DualMultiLogo objDualMultiLogo = new DualMultiLogo();
            objDualMultiLogo.LogoSelected = logoType;
            objDualMultiLogo.LogoNumber = Convert.ToInt32(controllToAssign);
            string searchText = filterText == "null" ? string.Empty : filterText;
            try
            {
                dt = dbA.GetAllLogosByType(logoType, searchText);
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        MultiLogoList objModel = new MultiLogoList();
                        objModel.SerialNumber = Convert.ToInt32(controllToAssign);
                        objModel.LogoTypeId = dr["LogoTypeId"] == DBNull.Value ? 0 : Convert.ToInt32(dr["LogoTypeId"]);
                        objModel.LogoType = dr["LogoType"] == DBNull.Value ? string.Empty : Convert.ToString(dr["LogoType"]);
                        objModel.AssetId = dr["AssetId"] == DBNull.Value ? 0 : Convert.ToInt32(dr["AssetId"]);
                        objModel.AssetName = dr["AssetName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AssetName"]);
                        objModel.AlternateFileName = dr["AlternateFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AlternateFileName"]);
                        objModel.Status = dr["Status"] == DBNull.Value ? string.Empty : Convert.ToString(dr["Status"]);
                        objModel.CreatedOn = dr["CreatedOn"] == DBNull.Value ? null : Convert.ToDateTime(dr["CreatedOn"]).ToString("dd-MMM-yyyy");
                        objModel.ApprovedBy = dr["ApprovedBy"] == DBNull.Value ? string.Empty : Convert.ToString(dr["ApprovedBy"]);
                        objModel.ApprovedOn = dr["ApprovedOrRejectedDate"] == DBNull.Value ? null : Convert.ToDateTime(dr["ApprovedOrRejectedDate"]).ToString("dd-MMM-yyyy");
                        objModel.LogoFileImage = GetLogoImage(objModel.AlternateFileName);
                        var logoTypeStr = objModel.LogoType == nameof(CustomLogoFor.Government) ? "Govt" : "Corp";
                        objModel.LogoFilePath = Url.Action("DownloadLogo", "MultiLogo", new { filePath = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], logoTypeStr) + objModel.AlternateFileName });
                        objModel.OriginalFileName = dr["OriginalFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["OriginalFileName"]);
                        objDualMultiLogo.MultiLogoList.Add(objModel);
                    }
                }
            }
            catch (Exception ex)
            {


            }

            var view = (!string.IsNullOrEmpty(filterText)) || (filterText == "null") ? "_customLogoSearchTable" : "_customLogoSearch";

            return PartialView(view, objDualMultiLogo);
        }

        public string GetLogoImage(string fileName)
        {
            string strImage = "";
            try
            {
                string path = ConfigurationManager.AppSettings["LogoFilePath"];

                // path += "/" + fileName;
                path = System.Web.HttpContext.Current.Server.MapPath(path);
                if (Directory.Exists(path))
                {
                    string name = string.Empty;
                    var files = Directory.EnumerateFiles(path, fileName + "*.*", SearchOption.AllDirectories);

                    foreach (var item in files)
                    {
                        name = item;
                    }
                    if (name != "")
                    {
                        FileStream fs = new FileStream(name, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        br.Close();
                        fs.Close();
                        strImage = Convert.ToBase64String(bytes);
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return strImage;
        }

        #endregion
    }
}