﻿using PMU.Models;
using System.Collections.Generic;
using System.Web.Mvc;
using PMU.Infrastructure;
using System.Linq;
using System;
using System.Data;
using System.Configuration;

namespace PMU.Controllers
{
    public partial class ProjectsController : Controller
    {
        #region Targetallocation

        [HttpGet]
        public ActionResult TargetAllocation(int TrainingTypeId, int projectid)
        {
            PMUTargetAllocation _viewModel = new PMUTargetAllocation();
            int CID = SessionMgr.LoginUserDetails.ContactId.ToInt();
            int TCID = SessionMgr.LoginUserDetails.CentreId.ToInt();
            try
            {
                _viewModel = dbA.getTargetPartnerJobRoleLocationList(CID, TCID, TrainingTypeId, projectid, SessionMgr.PartnerID.ToInt());//Project JobRole                
                _viewModel.ProjectJobRoleList = dbA.GetProjectJobRoleDetails(CID, TCID, TrainingTypeId, _viewModel.ProjectID, SessionMgr.PartnerID.ToInt());
                _viewModel.ProjectJobRoleList.First(a => a.isTargetAllocation == false).isTargetAllocation = true;
                SessionMgr.ProjectID = projectid;
                SessionMgr.TrainingTypeID = TrainingTypeId;
                SessionMgr.TrainingType = _viewModel.TrainingType;
                SessionMgr.PartnerID = _viewModel.TrainingPartnerID;
                SessionMgr.TrainingPartner = _viewModel.TrainingPartner;
                TempData["TrainingType"] = _viewModel.TrainingType;
                _viewModel.LocationTargetNameList = dbA.GetLocationJobRoleDetails(CID, TCID, TrainingTypeId, projectid, SessionMgr.TrainingType, SessionMgr.PartnerID.ToInt());//Location JobRole               
                                                                                                                                                                               //_viewModel.TrainingLocationsDetails = BindLocationDetails();
                _viewModel.TrainingLocationsDetails = dbA.BindLocationDetails();
                //Manage contacts popup
                ManageContactsViewModel viewmodel = new ManageContactsViewModel();
                Session["OTP"] = null;
                viewmodel.AadhaarVerificationStatus = "Not Provided";
                viewmodel.MobileOTPVerificationStatus = "Not Provided";
                viewmodel.CreatedBy = SessionMgr.LoginUserDetails.UserId;
                dbA.GetAllDdlList(viewmodel);
                _viewModel.TrainingLocationsDetails.ManageContactsDetails = viewmodel;
                ViewBag.LocationTitle = "Add Location";
                ViewBag.IsEdit = "false";
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            //_viewModel = dbA.getTargetPartnerJobRoleLocationList(SessionMgr.LoginUserDetails.ContactId.ToString(), SessionMgr.LoginUserDetails.CentreId.ToString(), TrainingTypeId, projectid);
            return View(_viewModel);
        }

        // GET: TargetAllocation
        public ActionResult TargetGetJobRoledetails(int partnerid, int projectid, int locationid)
        {
            IList<ProjectJobRole> listProjectJobRole = new List<ProjectJobRole>();
            listProjectJobRole = dbA.getTargetJobRoleDetails(locationid, partnerid, projectid);
            return PartialView("_ViewJobRoleTarget", listProjectJobRole);
        }

        #endregion

        #region Remove Location

        public ActionResult RemoveProjectLocation(int projectID, int locationID)
        {
            string result = string.Empty;
            string status = string.Empty;
            string projectJobRolePartail = string.Empty;
            string locationJobRolePartial = string.Empty;
            bool isDataBaseDelete = false;
            try
            {
                DataTable dtResult = dbA.RemoveProjectLocation(projectID.ToInt(), SessionMgr.TrainingTypeID.ToInt(), locationID.ToInt(), SessionMgr.LoginUserDetails.UserId);

                if (dtResult != null)
                {
                    if (dtResult.Columns.Contains("ErrorMessage"))
                    {
                        result = Convert.ToString(dtResult.Rows[0]["ErrorMessage"]).Trim();
                    }
                    else if (dtResult.Rows.Count > 0)
                    {
                        foreach (DataRow userInfo in dtResult.Rows)
                        {
                            SendEmailsToProjectLocationUsers(userInfo);
                        }

                        result = "Selected location has been Deleted Successfully";
                    }
                }
                else
                {
                    result = "Some error has occured, Please try again later";
                }

                projectJobRolePartail = ControllerContext.RenderPartialToString("_JobRoleTarget", dbA.GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.UserId));
                locationJobRolePartial = ControllerContext.RenderPartialToString("_LocationJobRoleTarget", dbA.GetLocationJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, SessionMgr.TrainingTypeID.ToInt(), SessionMgr.ProjectID.ToInt(), SessionMgr.TrainingType, SessionMgr.LoginUserDetails.UserId));
                isDataBaseDelete = true;
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
            }

            return Json(new { status = result, isDataBaseDelete = isDataBaseDelete, locationJobRolePartial = locationJobRolePartial, projectJobRolePartail = projectJobRolePartail }, JsonRequestBehavior.AllowGet);
        }

        public void SendEmailsToProjectLocationUsers(DataRow userInfo)
        {
            string body = string.Empty;

            int userID = Convert.ToInt32(userInfo["UserID"]);
            string userFullName = userInfo["Fullname"].ToString();
            string userEmail = userInfo["UserEmail"].ToString();
            int locationID = Convert.ToInt32(userInfo["LocationID"]);
            string locationName = userInfo["LocationName"].ToString();
            int projectID = Convert.ToInt32(userInfo["ProjectID"]);
            string projectName = userInfo["ProjectName"].ToString();
            int SPIAID = Convert.ToInt32(userInfo["SPIAID"]);
            string SPIAName = userInfo["SPIAName"].ToString();
            string SPOCEmail = userInfo["SPOCEmail"].ToString();

            try
            {
                EmailContent emailContent = new EmailContent();
                emailContent.Firstname = userFullName;
                emailContent.EmailTo = userEmail;
                emailContent.EmailCC = SPOCEmail;
                emailContent.EmailBCC = new string[] { ConfigurationManager.AppSettings["EmailBCC"].ToString() };
                emailContent.Subject = ConfigurationManager.AppSettings["EmailSubjectRemoveProjectLocation"].ToString();
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                emailContent.ContentPath = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/EmailContent/DeleteProjectLocationEmailContent.txt");

                body = System.IO.File.ReadAllText(emailContent.ContentPath);
                body = body.Replace("@LocationID", locationID.ToString());
                body = body.Replace("@LocationName", locationName);
                body = body.Replace("@SPIAID", SPIAID.ToString());
                body = body.Replace("@SPIAName", SPIAName);
                body = body.Replace("@ProjectID", projectID.ToString());
                body = body.Replace("@ProjectName", projectName);

                emailContent.MailContent = body;

                Email.SendMailToDeletedProjectLocationUsers(emailContent);
                dbA.CreateEmailSendingStatus(userID, userEmail, 1);
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                dbA.CreateEmailSendingStatus(userID, userEmail, 0);
            }
        }
        #endregion
    }
}