﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
//using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using System.Security.Cryptography;
using System.IO;
using System.Runtime.InteropServices;
//using System.ServiceModel.Activation;
using System.Configuration;
using System.Net;
using PMU.Models;

namespace PMU
{
    public class Encryption
    {
        #region Encryption & Decryption Password

        [DllImport("SHELL32.DLL", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true,
                     CallingConvention = CallingConvention.StdCall)]
        public static extern bool SHGetSpecialFolderPathW(int hWnd, StringBuilder sysDirBuffer, int nFolder, bool fCreate);

#if(DEBUG)
        [DllImport("TLECU.dll", CharSet = CharSet.Ansi)]
#else
            [DllImport("TLECU.dll", CharSet= CharSet.Ansi)]
#endif
        public static extern bool DecryptWCHAR2(
            [MarshalAs(UnmanagedType.LPWStr)]string inString,
            // [MarshalAs(UnmanagedType.LPWStr)]ref StringBuilder outString,
            ref System.IntPtr outString,
            ref int pnActualSize,
            [MarshalAs(UnmanagedType.I4)]int nMaxInOutBufferSize,
            [MarshalAs(UnmanagedType.LPStr)]string strSalt,
            [MarshalAs(UnmanagedType.Bool)]bool bCRC,
            [MarshalAs(UnmanagedType.Bool)]bool bASCII,
            [MarshalAs(UnmanagedType.Bool)]bool bMacKeySet,
            [MarshalAs(UnmanagedType.I4)] out int memAddr);
#if(DEBUG)
        [DllImport("TLECU.dll", CharSet = CharSet.Ansi)]
#else
			[DllImport("TLECU.dll", CharSet= CharSet.Ansi)]
#endif
        public static extern bool EncryptWCHAR2(
            [MarshalAs(UnmanagedType.LPWStr)]string inString,
            //[MarshalAs(UnmanagedType.LPWStr)]ref StringBuilder outString,
            ref System.IntPtr outString,
            ref int pnActualSize,
            [MarshalAs(UnmanagedType.I4)]int nMaxInOutBufferSize,
            [MarshalAs(UnmanagedType.LPStr)]string strSalt,
            [MarshalAs(UnmanagedType.Bool)]bool bCRC,
            [MarshalAs(UnmanagedType.Bool)]bool bASCII,
            [MarshalAs(UnmanagedType.Bool)]bool bMacKeySet,
            [MarshalAs(UnmanagedType.I4)] out int memAddr);

        // public static extern void FreeMemForWCHAR([MarshalAs(UnmanagedType.I4)]int memAddr);
        public static string DecryptPassword(string inPassword)
        {
            string strValue = "";
            string strDecrypted = "";
            int memAddress = 0;
            int len = inPassword.Length;


            System.IntPtr IntPtrPswd = System.IntPtr.Zero;


            bool res = false;
            try
            {
                res = DecryptWCHAR2(inPassword, ref IntPtrPswd, ref len, 500, "Limasat", true, true, true, out memAddress);

                strDecrypted = Marshal.PtrToStringAuto(IntPtrPswd);

                Logger.LogApplicationData("Login", "Login[Post]", inPassword, "Encryption Method");
            }
            catch (Exception ex)
            {
                res = false;
            }
            if (res)
            {
                strValue = strDecrypted;
                Logger.LogApplicationData("Login", "Login[Post]", strValue, "Decryption Method");
                //if (memAddress > 0)
                //  FreeMemForWCHAR(memAddress);
            }
            return strValue;
        }

        public static string EncryptPassword(string inPassword)
        {
            Logger.LogMessage("Start of EncryptPassword method:" + inPassword);
            string strValue = "";
            string strEncrypted = "";
            int memAddress = 0;
            int len = inPassword.Length;

            System.IntPtr IntPtrPswd = System.IntPtr.Zero;

            bool res = false;
            try
            {
                res = EncryptWCHAR2(inPassword, ref IntPtrPswd, ref len, 500, "Limasat", true, true, true, out memAddress);//contact

                // res = EncryptWCHAR2(inPassword, ref IntPtrPswd, ref len, 500, "Amalist", true, true, true, out memAddress);//user
                Logger.LogMessage("Try block Result:" + res);
                strEncrypted = Marshal.PtrToStringAuto(IntPtrPswd);
                Logger.LogMessage("Encrypted Password:" + strEncrypted + " " + IntPtrPswd);
            }
            catch (Exception ex)
            {
                //res = false;
                Logger.LogMessage("Encrypt Catch Block" + ex.Message);
                throw ex;
            }
            if (res)
            {
                Logger.LogMessage("Inside if block of Encrypt method:" + res);
                strValue = strEncrypted;
                //strValue = null;
                Logger.LogMessage("Inside if block of Encrypt password method:" + strValue + " " + strEncrypted);
                // if (memAddress > 0)
                //   FreeMemForWCHAR(memAddress);
            }
            Logger.LogMessage("Inside if block of Sending the encrypted password " + strValue + " " + strEncrypted);
            return strValue;
        }
    }
}

#endregion

