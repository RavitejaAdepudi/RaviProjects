﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Remoting.Messaging;
using System.Web;

namespace PMU.Infrastructure
{
    public class Email
    {
        //public void SendMail(MailMessage message)
        //{
        //    AsyncMethodCaller caller = new AsyncMethodCaller(SendMailInSeperateThread);
        //    AsyncCallback callbackHandler = new AsyncCallback(AsyncCallback).ToStr();
        //    caller.BeginInvoke(message, callbackHandler, null);
        //}

        private delegate void AsyncMethodCaller(MailMessage message);

        private void SendMailInSeperateThread(MailMessage message)
        {
            try
            {
                SmtpClient client = new SmtpClient();
                client.Timeout = 20000;
                client.Send(message);
                client.Dispose();
                message.Dispose();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        private void AsyncCallback(IAsyncResult ar)
        {
            try
            {
                AsyncResult result = (AsyncResult)ar;
                AsyncMethodCaller caller = (AsyncMethodCaller)result.AsyncDelegate;
                caller.EndInvoke(ar);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }


        public static void SendMailMailMessage(EmailContent objEmailContent)
        {
            MailMessage mailMsg = null;
            string mailcontent = string.Empty;

            try
            {
                mailMsg = new MailMessage(objEmailContent.EmailFrom, objEmailContent.EmailTo);
                mailcontent = File.ReadAllText(objEmailContent.ContentPath);

                mailcontent = mailcontent.Replace("@USERNAME", objEmailContent.loginID);
                mailcontent = mailcontent.Replace("@PASSWORD", objEmailContent.Randpassword);
                mailcontent = mailcontent.Replace("@URL", objEmailContent.Url);
                mailcontent = mailcontent.Replace("@CONTENTID", objEmailContent.ContentId);

                mailMsg.Body = mailcontent;
                mailMsg.IsBodyHtml = true;
                mailMsg.From = new MailAddress(objEmailContent.EmailFrom);
                mailMsg.Subject = objEmailContent.Subject;
                foreach (string item in objEmailContent.EmailBCC)
                {
                    MailAddress bcc = new MailAddress(item);
                    mailMsg.Bcc.Add(bcc);
                }
                SmtpClient smtp = new SmtpClient();
                smtp.Host = objEmailContent.SMTPHost;
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential(objEmailContent.EmailFrom, objEmailContent.EmailSentPassword);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = objEmailContent.SMTPPort.ToInt();
                smtp.Send(mailMsg);

            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void SendMailMailMessageAsCeremonyRejected(EmailContent objEmailContent)
        {
            MailMessage mailMsg = null;
            string mailcontent = string.Empty;

            try
            {
                mailMsg = new MailMessage(objEmailContent.EmailFrom, objEmailContent.EmailTo);

                mailMsg.Body = objEmailContent.MailContent;
                mailMsg.From = new MailAddress(objEmailContent.EmailFrom);
                mailMsg.Subject = objEmailContent.Subject;

                SmtpClient smtp = new SmtpClient();
                smtp.Host = objEmailContent.SMTPHost;
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential(objEmailContent.EmailFrom, objEmailContent.EmailSentPassword);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = objEmailContent.SMTPPort.ToInt();
                smtp.Send(mailMsg);

            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void SendMailToDeletedProjectLocationUsers(EmailContent emailContent)
        {
            MailMessage mailMsg = null;
            string mailcontent = string.Empty;

            try
            {
                mailMsg = new MailMessage(emailContent.EmailFrom, emailContent.EmailTo);


                mailMsg.From = new MailAddress(emailContent.EmailFrom);
                mailMsg.To.Add(emailContent.EmailCC);

                string nsdcPMUemail = SessionMgr.LoginUserDetails.EMail;
                mailMsg.CC.Add(nsdcPMUemail);

                foreach (string itemBCC in emailContent.EmailBCC)
                {
                    MailAddress bcc = new MailAddress(itemBCC);
                    mailMsg.Bcc.Add(bcc);
                }

                mailMsg.Subject = emailContent.Subject;
                mailMsg.Body = emailContent.MailContent;
                mailMsg.IsBodyHtml = true;

                using (SmtpClient smtp = new SmtpClient())
                {
                    smtp.Host = emailContent.SMTPHost;
                    smtp.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential(emailContent.EmailFrom, emailContent.EmailSentPassword);
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = emailContent.SMTPPort.ToInt();
                    smtp.Send(mailMsg);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}