﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Routing;
using PMU.Models;

namespace PMU.Infrastructure
{
    public class RoleUrlHelper : UrlHelper
    {
        public override string Action(string actionName)
        {
            return base.Action(actionName, new RouteValueDictionary());
        }

        //public override string Action(string actionName, string controllerName)
        //{
        //    if (RequestContext.HttpContext.Session == null) return "";
        //    var user = (UserModel)RequestContext.HttpContext.Session["UserModel"];
        //    var requiredPermission = String.Format("{0}-{1}", controllerName, actionName);
        //    var requestingUser = new UserContext(user.Username, user.UserRoles, user.Permissions);
        //    //Check if the requesting user has the permission to run the controller's action
        //    if (!requestingUser.HasPermission(requiredPermission) & !requestingUser.IsSysAdmin)
        //    {
        //        return "";
        //    }
        //    return base.Action(actionName, controllerName, new RouteValueDictionary());
        //}
    }
}
