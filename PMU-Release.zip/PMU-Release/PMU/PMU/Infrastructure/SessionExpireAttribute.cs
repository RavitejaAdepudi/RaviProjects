﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PMU.Models;
using PMU.Repository;

namespace PMU.Infrastructure
{
    public class SessionExpireAttribute : ActionFilterAttribute
    {
        DbAction _dbAction = new DbAction();
        DateTime _now = DateTime.Now;

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var userDetails = SessionMgr.LoginUserDetails;
            HttpContext ctx = System.Web.HttpContext.Current;
            if (ctx.Request.ContentType == "json")
            {
                //if (System.Web.HttpContext.Current.Session["ContactID"] == null || System.Web.HttpContext.Current.Session["TCID"] == null)
                if (userDetails.ContactId.ToStr() == null || userDetails.CentreId.ToStr() == null)
                {
                    var response = ctx.Response;
                    response.StatusCode = 401;

                    response.StatusDescription = "json session out";
                }
            }
            else
            {
                DateTime currentdate = DateTime.Now;
                //var contactId = Convert.ToInt32(System.Web.HttpContext.Current.Session["ContactID"]);
                //var tcid = Convert.ToInt32(System.Web.HttpContext.Current.Session["TCID"]);
                //var sessionId = Convert.ToString(System.Web.HttpContext.Current.Session["sessionid"]);
                //var user = (UserModel)System.Web.HttpContext.Current.Session["UserModel"];

                //if (System.Web.HttpContext.Current.Session["ContactID"] == null ||System.Web.HttpContext.Current.Session["TCID"] == null)
                if (SessionMgr.LoginUserDetails == null || SessionMgr.LoginUserDetails.ContactId == 0 || SessionMgr.LoginUserDetails.CentreId == 0)
                {
                    filterContext.Result = new RedirectResult("~/Login/SessionLogout");
                    return;
                }
                else
                {
                    //TODO: 1. check if flag is 1 then perform session abandon and redired to login page
                    //TODO: 2. if flag is 0, do nothing

                    //#if DEBUG
                    //Do not check login dupilication
                    //#else
                    DataTable dtble = _dbAction.CheckLoginRecord(userDetails.CentreId, userDetails.ContactId, userDetails.SessionId, userDetails.UserId, 0);

                    if (dtble != null && dtble.Rows.Count > 0 && (!Convert.ToBoolean(dtble.Rows[0]["IsActive"]) || !String.Equals($"{dtble.Rows[0]["SessionID"]}", userDetails.SessionId, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        //System.Web.HttpContext.Current.Session.Clear();
                        filterContext.Result = new RedirectResult("~/Login/ForceLogout");
                    }
                    //#endif
                    return;
                }
            }

        }
    }
}