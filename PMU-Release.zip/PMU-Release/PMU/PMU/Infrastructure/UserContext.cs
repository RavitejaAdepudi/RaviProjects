﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMU.Repository;

namespace PMU.Infrastructure
{
    public class UserContext
    {
        public int UserId { get; set; }
        public bool IsSysAdmin { get; set; }
        public string Username { get; set; }
        private List<UserRole> _roles = new List<UserRole>();

        public UserContext(string username, List<UserRole> userRoles, List<RolePermission> permissions)
        {
            Username = username;
            IsSysAdmin = false;
            GetDatabaseUserRolesPermissions(userRoles, permissions);
        }

        private void GetDatabaseUserRolesPermissions(List<UserRole> userRoles, List<RolePermission> permissions)
        {
            _roles = userRoles;
            foreach (var role in _roles)
            {
                role.Permissions = permissions.FindAll(x => x.RoleId == role.RoleId);
            }

            var isRoleSysAdmin = userRoles.Any(x => x.IsSysAdmin);
            IsSysAdmin = isRoleSysAdmin;

            //using (RBAC_Model _data = new RBAC_Model())
            //{
            //    USER _user = _data.USERS.Where(u => u.Username == this.Username).FirstOrDefault();
            //    if (_user != null)
            //    {
            //        this.User_Id = _user.User_Id;
            //        foreach (ROLE _role in _user.ROLES)
            //        {
            //            UserRole _userRole = new UserRole { Role_Id = _role.Role_Id, RoleName = _role.RoleName };
            //            foreach (PERMISSION _permission in _role.PERMISSIONS)
            //            {
            //                _userRole.Permissions.Add(new RolePermission { Permission_Id = _permission.Permission_Id, PermissionRoute = _permission.PermissionRoute });
            //            }
            //            this.Roles.Add(_userRole);

            //            if (!this.IsSysAdmin)
            //                this.IsSysAdmin = _role.IsSysAdmin;
            //        }
            //    }
            //}
        }

        public bool HasPermission(string requiredPermission)
        {
            bool bFound = false;
            foreach (UserRole role in _roles)
            {
                bFound = (role.Permissions.Where(p => p.PermissionRoute.ToLower() == requiredPermission.ToLower()).ToList().Count > 0);
                if (bFound)
                    break;
            }
            return bFound;
        }

        public bool HasRole(string role)
        {
            return (_roles.Where(p => p.RoleName == role).ToList().Count > 0);
        }

        public bool HasRoles(string roles)
        {
            bool bFound = false;
            string[] _roles = roles.ToLower().Split(';');
            foreach (UserRole role in this._roles)
            {
                try
                {
                    bFound = _roles.Contains(role.RoleName.ToLower());
                    if (bFound)
                        return bFound;
                }
                catch (Exception)
                {
                }
            }
            return bFound;
        }
    }
    public class UserRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsSysAdmin { get; set; }

        public List<RolePermission> Permissions = new List<RolePermission>();
    }
    public class RolePermission
    {
        public int RoleId { get; set; }
        public int PermissionId { get; set; }
        public string PermissionRoute { get; set; }
    }
}
