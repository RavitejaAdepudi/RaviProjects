﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using PMU.Models;
using System.IO;
using System.Configuration;

namespace PMU.Infrastructure
{
    public class Utility
    {
        public static string ConvertStringToHex(String input, System.Text.Encoding encoding)
        {
            Byte[] stringBytes = encoding.GetBytes(input);
            StringBuilder sbBytes = new StringBuilder(stringBytes.Length * 2);
            foreach (byte b in stringBytes)
            {
                sbBytes.AppendFormat("{0:X2}", b);
            }
            return sbBytes.ToString();
        }

        public static bool IsAccessAllowed(string actionName, string controllerName)
        {
            var contextSession = HttpContext.Current.Session;
            if (contextSession["UserModel"] == null) return false;
            var user = (UserModel)contextSession["UserModel"];
            var requiredPermission = $"{controllerName}-{actionName}";
            var requestingUser = new UserContext(user.Username, user.UserRoles, user.Permissions);
            //Check if the requesting user has the permission to run the controller's action
            if (!requestingUser.HasPermission(requiredPermission) & !requestingUser.IsSysAdmin)
            {
                return false;
            }
            return true;
        }

        public enum LogoutCode
        {
            Normal = 1,
            SessionTimeOut = 2,
            ForceLogout = 3,
            NotNormal = 4

        }

        public static string SendShortMessage(string mobileNo, string msgBody)
        {
            if (!string.IsNullOrEmpty(mobileNo))
            {


                var gStrSmsurl =
                    "http://alerts.sinfini.com/api/web2sms.php?workingkey=Ae51d4e35c281d49b295cff14fa4686cc&sender=NSDCSC&to=~@@Moblie~@@Number&message=~@@Message~@@";
                string username = "username=";
                string password = "password=";
                int iUname = username.Length;
                int iPwd = password.Length;

                var iStartPosition = gStrSmsurl.IndexOf("username=", StringComparison.Ordinal) + iUname;
                var iEndPosition = gStrSmsurl.IndexOf("&", iStartPosition, StringComparison.Ordinal);
                var iLength = iEndPosition - iStartPosition;
                string gUrlUserName = gStrSmsurl.Substring(iStartPosition, iLength);

                iStartPosition = gStrSmsurl.IndexOf("password=", StringComparison.Ordinal) + iPwd;
                iEndPosition = gStrSmsurl.IndexOf("&", iStartPosition, StringComparison.Ordinal);
                iLength = iEndPosition - iStartPosition;
                string gUrlPassword = gStrSmsurl.Substring(iStartPosition, iLength);

                string strUrlwithMessage = gStrSmsurl.Replace("~@@Moblie~@@Number", mobileNo);
                strUrlwithMessage = strUrlwithMessage.Replace("~@@Message~@@", msgBody);
                string result = "Failure";
                var request = (HttpWebRequest)WebRequest.Create(strUrlwithMessage);
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    // Code here 
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        result = "Success";
                    }
                }
                return result;
            }
            else
            {
                return "No mobile number";
            }
        }


        public static bool IsValidSqlDateTime(DateTime? dateTime)
        {
            if (dateTime == null) return true;

            DateTime minValue = DateTime.Parse(System.Data.SqlTypes.SqlDateTime.MinValue.ToString());
            DateTime maxValue = DateTime.Parse(System.Data.SqlTypes.SqlDateTime.MaxValue.ToString());

            if (minValue > dateTime.Value || maxValue < dateTime.Value)
                return false;

            return true;
        }

        #region Directory Path Building

        public static string BuildAssetPath(string rootPath, string subDirectory)
        {
            var fullPath = System.IO.Path.GetFullPath($"{rootPath.TrimEnd('\\')}{System.IO.Path.DirectorySeparatorChar}{subDirectory.TrimStart('\\').TrimEnd('\\')}{System.IO.Path.DirectorySeparatorChar}");
            try
            {
                if (!Directory.Exists(fullPath))
                {
                    Directory.CreateDirectory(fullPath);
                }
            }
            catch (Exception e)
            {
            }

            return fullPath;
        }

        #endregion

        #region Generate Random Password
        public static string GenerateRandomPassword(out string password)
        {
            password = string.Empty;

            var stringChars = new char[13];
            var uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var lowercase = "abcdefghijklmnopqrstuvwxyz";
            var alphanumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var random = new Random();
            string caps = (Convert.ToString(uppercase[random.Next(uppercase.Length)]));
            string smalls = (Convert.ToString(lowercase[random.Next(lowercase.Length)]));
            string result = caps + smalls;
            for (int i = 3; i < 6; i++)
            {
                result = result + Convert.ToString(alphanumeric[random.Next(alphanumeric.Length)]);
            }
            result = result + "@" + DateTime.Now.Year.ToString();
            password = result;

            Encryption encrypt = new Encryption();
            string encyptedpassword = Encryption.EncryptPassword(password);

            return encyptedpassword;
        }
        #endregion

        public static bool SendEmailsToUsers(string name, string emailID, string loginid, string userPassword)
        {
            string body = string.Empty;
            try
            {
                EmailContent emailContent = new EmailContent();
                emailContent.Firstname = name;
                emailContent.EmailTo = emailID;
                emailContent.EmailCC = emailID;
                emailContent.EmailBCC = ConfigurationManager.AppSettings["EmailBCC"].ToString().Split(',');
                emailContent.loginID = loginid;
                emailContent.Url = ConfigurationManager.AppSettings["WebsiteUrlSPIA"].ToString();
                emailContent.Randpassword = userPassword;
                emailContent.ContentId = "SPIA";
                emailContent.Subject = ConfigurationManager.AppSettings["SubjectLocationSpoc"].ToString();
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                emailContent.ContentPath = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/EmailContent/EmailContent.txt");
                Email.SendMailMailMessage(emailContent);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogException(ex);
                return false;
            }
        }
    }
}
