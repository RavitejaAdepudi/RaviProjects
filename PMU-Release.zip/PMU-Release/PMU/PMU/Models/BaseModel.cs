﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace PMU
{
    public class BaseModel
    {
        public int IPAddress { get; set; }
        public int CreatedDate { get; set; }
        public int UpdatedDate { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
    }
}