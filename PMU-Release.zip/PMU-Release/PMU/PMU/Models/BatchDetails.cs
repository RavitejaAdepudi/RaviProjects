﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace PMU
{
    public class BatchDetails
    {
        //[Required(ErrorMessage = "Enter Location name.")]
        public int TrainingTypeID { get; set; }
        public string TrainingTypeName { get; set; }
        public int VerificationStatusID { get; set; }
        public string VerificationStatusName { get; set; }
        public string LocationName { get; set; }
        public string BatchName { get; set; }
        public int BatchID { get; set; }
        public int LocationID { get; set; }
        public string PreferredAssessmentDate { get; set; }
        public string AssessmentStartDate { get; set; }
        public string AssessmentEndDate { get; set; }
        public int TotalCountCandidates { get; set; }
        public int TotalCertifiedCandidates { get; set; }
        public string VerificatinStatus { get; set; }
        public int CummulativeTCPlacementPercentage { get; set; }
        public int CummulativeTranchePlacementPercentage { get; set; }
        public IList<DropDownDDL> TriningTypeDDl { get; set; }
        public IList<DropDownDDL> VerificationStatusDDl { get; set; }
        public IList<TrainingLocations> TrainingLocationList { get; set; }
        public IList<BatchDetails> BatchDetailsList { get; set; }
    }
}