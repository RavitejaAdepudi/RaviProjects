﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU.Models
{
    public class BatchDetailsViewModel
    {
        public string BatchName { get; set; }
        public string BatchNameDDL { get; set; }
        public string CenterId { get; set; }
        public string PartnerID { get; set; }
        public string SectorID { get; set; }

        public string BatchStartDate { get; set; }
        public string BatchEndDate { get; set; }
        public string PreferedAssessmentDate { get; set; }
        public string Remarks { get; set; }
        public string CandID { get; set; }
        public string CentreCandID { get; set; }
        public string CandidateName { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string MobileNumber { get; set; }
        public string Dateofregistration { get; set; }
        public IList<DisabledDropDownDDL> batchlist { get; set; }
        public List<CandidateList> CandidateInfoList { get; set; }
        public List<BatchList> BatchInfoList { get; set; }
    }
    public class CandidateList
    {
        public string BatchName { get; set; }
        public string BatchStartDate { get; set; }
        public string BatchEndDate { get; set; }
        public string CandID { get; set; }
        public string CandidateName { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string MobileNumber { get; set; }
        public string Dateofregistration { get; set; }
        public string CentreCandID { get; set; }
        public string Remarks { get; set; }
        public string Result { get; set; }
        public string BatchID { get; set; }
        public string CID { get; set; }
        public string PdfDownloadUri { get; set; }
        public int CountDownloadTime { get; set; }
        public string DateofBirth { get; set; }
    }
    public class BatchList
    {
        public string BatchID { get; set; }
        public string tCId { get; set; }
        public string BatchName { get; set; }
        public string JobRoleId { get; set; }

        public string TrainingType { get; set; }
        public string CentreName { get; set; }

        public string SectorID { get; set; }
        public string BatchStartDate { get; set; }
        public string BatchEndDate { get; set; }
        public string PreferedAssessmentDate { get; set; }
        public int SmartCentreBatchID { get; set; }
        public string ZipDownloadUri { get; set; }
        public int CandidateCount { get; set; }
        public int RowNumber { get; set; }
        public string FileName { get; set; }
        public int CountDownloadTime { get; set; }
        public string  DocumentVerificationClosed { get; set; }
        public string DocumentVerificationValue { get; set; }


        

    }
}