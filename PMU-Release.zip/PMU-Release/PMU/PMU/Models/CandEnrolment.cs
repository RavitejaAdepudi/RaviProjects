﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class CandEnrolment
    {
        public int? CandID { get; set; }
        public string CentreID { get; set; }
        public string BatchID { get; set; }
        public string CandidateName { get; set; }
        public string Gender { get; set; }
        public string DateofBirth { get; set; }
        public string EligibleforPostPlacementSupport { get; set; }
        public string BatchAssessmentDate { get; set; }
        public string CertifiedDate { get; set; }
        public int? EmploymentTypeId { get; set; }
        public string  PlacementStatus { get; set; }
        //public EmployerDetailsModel EmployerDetails { get; set; }
    }
}