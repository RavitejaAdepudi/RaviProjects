﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace PMU
{
    public class CandidateEmploymentModel
    {
        public int? EmploymentDetailID { get; set; }

        [DisplayName("Candidate")]
        [Required]
        public int CandidateID { get; set; }

        [DisplayName("From Date")]
        [Required]
        public string FromDate { get; set; }

        [DisplayName("To Date")]
        // [Required]
        public string ToDate { get; set; }

        public string Designation { get; set; }
        public string EmployerTypeDesc { get; set; }
        public string NatureOfEmployment { get; set; }
        public int? EmployerID { get; set; }
        public int? EmployerLocationID { get; set; }
        public string CandidateDesignation { get; set; }
        public int? StateID { get; set; }
        public string StateName { get; set; }
        public int? DistrictID { get; set; }
        public string DistrictName { get; set; }

        [RegularExpression("^[0-9]*$")]
        //[StringLength(5, ErrorMessage = "Self monthly income must be between {2} and {1} characters long.", MinimumLength = 4)]
        [Range(1000, 99999)]
        public int? SelfMonthlyIncome { get; set; }

        [RegularExpression("^[0-9]*$")]
        // [StringLength(5, ErrorMessage = "Wage monthly income must be between {2} and {1} characters long.", MinimumLength = 4)]
        [Range(1000, 99999)]
        public int? WageMonthlyIncome { get; set; }

        public int? SelfDocumentProofID { get; set; }
        public string SelfDocumentProofName { get; set; }

        public int? WageDocumentProofID { get; set; }
        public string WageDocumentProofName { get; set; }

        //public string DocumentUrl { get; set; }
        //public string ImageName { get; set; }

        [DisplayName("Type of Employer")]
        [Required]
        public int? EmploymentTypeId { get; set; }
        public string ImageUrl { get; set; }

        [DisplayName("Total Days of Employment")]
        [Required]
        public string TotalDaysOfEmployment { get; set; }

        //[DisplayName("Proof Document")]
        //[Required]
        //public HttpPostedFileBase ProofDocument { get; set; }

        //[DisplayName("Proof Document")]
        //[Required]
        //public HttpPostedFileBase SelfProofDocument { get; set; }
        //[DisplayName("Proof Document")]
        //[Required]
        //public HttpPostedFileBase WageProofDocument { get; set; }

        public int ReasonID { get; set; }
        public string ReasonDesc{ get; set; }
        public string OtherDesc { get; set; }

        public string PMUVerificationStatusID { get; set; }
        public string PMUVerificationStatus { get; set; }
        public IList<DropDownDDL> EmployerStateList { get; set; }
        public IList<DropDownDDL> EmployerDistrictList { get; set; }
        public string OrgarnizationName { get; set; }
        public IList<DropDownDDL> EmploymentTypeList { get; set; }
        public IList<DropDownDDL> WageTypeOfDocumentProofList { get; set; }
        public IList<DropDownDDL> SelfTypeOfDocumentProofList { get; set; }

        public IList<DropDownDDL> CandidatesList { get; set; }
        public IList<DropDownDDL> VerificationReasonDdl { get; set; }
    }
}