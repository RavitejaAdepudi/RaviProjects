﻿using System.Collections.Generic;

namespace PMU
{
    public class CandidateEmploymentViewModel
    {
        public string PartialCandidateEmploymentModelList { get; set; }

        public string PartialPostPlacementEligible { get; set; }
        //public EmployerDetailsModel EmployerDetailsModel { get; set; }
        public CandEnrolment CandEnrolment { get; set; }
        public CandidateEmploymentModel CandidateEmployment { get; set; }
        public IList<CandEnrolment> CandidateDeatilList { get; set; }
        public IList<CandidateEmploymentModel> CandidateEmploymentModelList { get; set; }

        // public IList<CandidateEmploymentAssesment> CandidateEmploymentAssesmentList { get; set; }
        public IList<PostPlacement> CandidateEligibleforPostPlacement { get; set; }
        
        public IList<DocumentDetails> CandidateDocumentList { get; set; }

        public int candEmpCount { get; set; }

        //public string PMUVerificationStatus { get; set; }

        public bool IsEligiblePlacement { get; set; }
    }
}