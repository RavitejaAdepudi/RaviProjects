﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using PMU.Infrastructure;

namespace PMU.Models
{
    public class CandidateEnrollmentViewModel
    {
        List<BatchAssetPartialModel1> _ImageList;
        BatchAssetPartialModel1 _UploadImage;
        CeremonyModel _CeremonyModel;

        public string BatchId { get; set; }
        public string Scheme { get; set; }
        public string Sector { get; set; }
        public string SubSector { get; set; }
        public string JobRole { get; set; }
        public bool HasBridgeCourse { get; set; }
        public decimal BridgeCourseHours { get; set; }
        public string JobRoleDurationInHours { get; set; }
        public string TrainingType { get; set; }
        public string ProjectType { get; set; }
        public string Batch_size { get; set; }
        //public string Maxsize { get; set; }
        public string BatchStartDate { get; set; }
        public string BatchEndDate { get; set; }
        public string PreferedAssessmentDate { get; set; }
        public string Trainer { get; set; }
        public string Approvalstatus { get; set; }
        public int EnrolledSoFar { get; set; }
        public string EnrolmentRemaining { get; set; }
        public string EnrolmentClosureDate { get; set; }

        public List<RegisteredCandidate> RegisteredCandidatesList { get; set; }
        public List<RegisteredCandidate> EnrolledCandidatesList { get; set; }
        public string BatchName { get; set; }
        public string TargetAvailable { get; set; }

        //[StringLength(255,ErrorMessage ="You can enter only 255 characters")]
        public string Description { get; set; }

        public int VerificationStatus { get; set; }
        public HttpPostedFileBase BatchPhotos { get; set; }
        public List<BatchAssetPartialModel1> ImageList
        {
            get
            {
                if (_ImageList == null)
                    _ImageList = new List<BatchAssetPartialModel1>();
                return _ImageList;
            }
            set
            {
                _ImageList = value;
            }
        }

        public BatchAssetPartialModel1 UploadImage
        {
            get
            {
                if (_UploadImage == null)
                    _UploadImage = new BatchAssetPartialModel1();
                return _UploadImage;
            }
            set
            {
                _UploadImage = value;
            }
        }
        public string ImageName { get; set; }
        public int ImageCount { get; set; }

        public int CeremonyStatus { get; set; }

        public CeremonyModel CeremonyModel
        {
            get
            {
                if (_CeremonyModel == null)
                    _CeremonyModel = new CeremonyModel();
                return _CeremonyModel;
            }
            set
            {
                _CeremonyModel = value;
            }
        }

        public int? ReasonForRejection { get; set; }
        public string RejectionDescription { get; set; }
        public string Remarks { get; set; }
        public string CeremonyText { get; set; }
        public string ReasonText { get; set; }

    }

    public class CeremonyModel
    {
        public string BatchId { get; set; }
        public IList<DropDownDDL> RejectionReasonList { get; set; }
        public int RejectionReason { get; set; }
        public string CeremonyStatusDescription { get; set; }
        public string CeremonyAppRejDescription { get; set; }
        public int CeremonyStatusID { get; set; }

    }

    public class BatchAssetPartialModel1
    {
        public virtual string image { get; set; }
        public string ImageName { get; set; }
        public string Description { get; set; }
        public int VerificationStatus { get; set; }
        public string Verfication { get; set; }
        public int VerifiedBy { get; set; }
        public int TCUserID { get; set; }

        public string TimeString { get; set; }

        public DateTime? Date { get; set; }
        public string GuestOfHonor { get; set; }
        public int GuestOfHonorType { get; set; }

        public IList<DropDownDDL> GuestOfHonorTypeList { get; set; }
    }

    public enum VerificationStatus
    {
        Pending = 1,
        Verified = 2,
        Denied = 3
    }

    public enum CeremonyStatus
    {

        //UAT Values 
        //All = 1239,
        //UploadPending = 1240,
        //SentToNSDCPMU = 1241,
        //VerifiedbyNSDCPMU = 1242,
        //RejectedbyNSDCPMU = 1298

        //Production Values 
        All = 1279,
        UploadPending = 1280,
        SentToNSDCPMU = 1281,
        VerifiedbyNSDCPMU = 1282,
        RejectedbyNSDCPMU = 1424

    }
}