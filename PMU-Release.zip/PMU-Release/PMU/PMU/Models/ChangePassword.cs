﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PMU
{
    public class ChangePassword
    {
        [Required]
        [DataType(DataType.Password)]
        //[StringLength(25), MinLength(8)]  //@"(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^a-zA-Z0-9_@.-]).{8,}$"
        //[RegularExpression(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$", ErrorMessage = "Password field should contain Minimum 8 Characters with at least one Lowercase, one Uppercase and one Number.")]
        [Display(Name = "Old Password")]
        public string OldPassword { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(25), MinLength(8)]  //^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$
        [RegularExpression(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$", ErrorMessage = "Password field should contain Minimum 8 Characters with at least one Lowercase, one Uppercase and one Number.")]
        [Display(Name = "New Password")]
        public string NewPassword { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(25), MinLength(8)]
        ///[RegularExpression(@"^ (?=.*\d)(?=.*[a - z])(?=.*[A - Z])[0 - 9a - zA - Z]{ 8,}$", ErrorMessage = "Password field should contain Minimum 8 Characters with atleast one Lowercase, one Uppercase and one Number.")]
        [Compare("NewPassword", ErrorMessage = "The password and confirmation password do not match.")]
        [Display(Name = "Confirm Password")]
        public string ConfirmPassword { get; set; }

        public string CandidateID { get; set; }
        public string NotRequestforChange { get; set; }
        public string PasswordNotChanged { get; set; }
        public string MessageAlert { get; set; }

        public string ErrorMessage { get; set; }
        public string Confirmation { get; set; }
    }
}