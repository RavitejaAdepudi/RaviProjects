﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU.Models
{
    public class DisabledDropDownDDL
    {
        public virtual int? nIndex { get; set; }
        public virtual string tDisplayName { get; set; }
    }
}