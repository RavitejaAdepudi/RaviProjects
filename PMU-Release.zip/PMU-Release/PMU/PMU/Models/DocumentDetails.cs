﻿

namespace PMU
{
    public class DocumentDetails
    {
        public int CandidateEmploymentAssetsID { get; set; }
        public int CandidateEmploymentID { get; set; }
        public string ValidFrom { get; set; }
        public string ValidTo { get; set; }
        public string TypeofDocument { get; set; }
        public string DocumentFiled { get; set; }
        public string DocumentLocation { get; set; }
        public string DateUploaded { get; set; }
    }
}