﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class DropDownDDL
    {
        public virtual int? nIndex { get; set; }
        public virtual string tDisplayName { get; set; }
        public virtual string tDisplayCode { get; set; }
        public virtual string nAltIndex { get; set; }
        public virtual string ValidationCode { get; set; }
        public virtual string ValidationMessage { get; set; }
        public virtual string nAltIndex2 { get; set; }
    }
}