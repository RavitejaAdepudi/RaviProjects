﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU.Models
{
    public class DualMultiLogo
    {
        public DualMultiLogo()
        {
            LogoTypeList = new List<LogoType>();
            MultiLogoList = new List<MultiLogoList>();
            EmailList = new List<Dictionary<int,string>>();
        }

        public string ButtonAction { get; set; }
        public int AssetId { get; set; }
        public string AssetName { get; set; }
        public string AssetCategory { get; set; }
        public int LogoTypeId { get; set; }

        public string LogoTypeName { get; set; }

        public int ApproverId { get; set; }
        public int ApprovalStatus { get; set; }
        public string OriginalFileName { get; set; }
        public string AlternateFileName { get; set; }
        public string CreatedOn { get; set; }

        public int CreatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public string IpAddress { get; set; }

        public string BrowserType { get; set; }
        public int TrainingType { get; set; }

        public string TrainingTypeName { get; set; }
        public List<LogoType> LogoTypeList { get; set; }
        public List<MultiLogoList> MultiLogoList { get; set; }

        public int SchemeId { get; set; }

        public string LogoSelected { get; set; }
        public int LogoNumber { get; set; }

        public List<Dictionary<int,string>> EmailList { get; set; }

    }

    public class MultiLogoList
    {
        public int SerialNumber { get; set; }
        public int AssetId { get; set; }
        public string AssetName { get; set; }

        public int LogoTypeId { get; set; }
        public string LogoType { get; set; }
        public string Status { get; set; }
        public string OriginalFileName { get; set; }
        public string AlternateFileName { get; set; }

        public string LogoFileImage { get; set; }
        public string LogoFilePath { get; set; }
        public string CreatedOn { get; set; }

        public string ApprovedBy { get; set; }
        public string ApprovedOn { get; set; }

        public string Reason { get; set; }

    }

    public class LogoType
    {
        public int LogoTypeId { get; set; }
        public string LogoTypeName { get; set; }


    }

    public class LogoVerification
    {
        public int UserId { get; set;}
        public int AssetId { get; set; }

        public string DisplayStatus { get; set; }
        public string CurrentStatus { get; set; }

        public string LogoFileImage { get; set; }
        public string AlternateFileName { get; set; }

    }
}