﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class EmailContent
    {
        public string Firstname { get; set; }
        public string IsAadharorCandiadteID { get; set; }
        public string LoginFlag { get; set; }
        public string Randpassword { get; set; }
        public string UserID { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string[] EmailBCC { get; set; }
        public string loginID { get; set; }
        public string EmailFrom { get; set; }
        public string MailContent { get; set; }
        public string Subject { get; set; }
        public string ContentId { get; set; }
        public string Url { get; set; }
        public string RecentlinkID { get; set; }
        public string MobileNo { get; set; }
        public string EmailSentPassword { get; set; }
        public string SMTPHost { get; set; }
        public string SMTPPort { get; internal set; }
        public string OldEmail { get; internal set; }
        public string AttachmentPath { get; set; }
        public string ContentPath { get; set; }
    }
}