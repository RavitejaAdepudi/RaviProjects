﻿using System;
using System.ComponentModel.DataAnnotations;
namespace PMU
{
    public class ForgotPassword
    {
        [Required]
        [Display(Name = "Contact Code")]
        public string ContactCode { get; set; }
        //public string MailID { get; set; }

        public string Password { get; set; }
        public string MessageAlert { get; set; }
        public string EmailID { get; set; }
        public string ErrorMessage { get; set; }
        public string Confirmation { get; set; }
    }
}