﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PMU
{
    public class ForgotPasswordReset
    {
        [Required]
        [DataType(DataType.Password)]
        [StringLength(25), MinLength(8)]
        [RegularExpression(@"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z$&+,:;=?@#|'<>.^*()%!-]{8,}$", ErrorMessage = "Password field should contain Minimum 8 Characters with at least one Lowercase, one Uppercase and one Number.")]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(25), MinLength(8)]
        [Compare("Password", ErrorMessage = "")] //The new password and confirm password do not match.
        [Display(Name = "Confirm Password")]
        public string ConfirmPassword { get; set; }
        public string MessageAlert { get; set; }
        public string CandidateID { get; set; }
        public string NotRequestforChange { get; set; }
        public string PasswordNotChanged { get; set; }

        public string ErrorMessage { get; set; }
        public string Confirmation { get; set; }
    }
}