﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Configuration;

namespace PMU.Models
{
    public class Logger
    {
        public static string LoggingLocation { get; set; }

        public static string LogFileNamePrefix { get; set; }

        public static string LogAllMessages { get; set; }

        public static string EnableTrace { get; set; }

        public static string LogInformation { get; set; }
        public static string ArgumentName { get; set; }
        private static bool TraceEnabled
        {
            get
            {
                bool bRetval = false;
                EnableTrace = "true";
                string sConfigValue = EnableTrace;

                bool.TryParse(sConfigValue, out bRetval);
                return bRetval;
            }
        }

        private static bool IsVerboseLoggingEnabled
        {
            get
            {
                bool bRetval = false;
                LogAllMessages = "true";
                string sConfigValue = LogAllMessages;

                bool.TryParse(sConfigValue, out bRetval);
                return bRetval;
            }
        }

        /// <summary>
        /// Logs a message, if the verbose logging is enabled (in config file).
        /// </summary>
        /// <param name="message">The message to be logged.</param>
        public static void LogMessage(string message)
        {

            if (IsVerboseLoggingEnabled && TraceEnabled)
            {
                WriteToLog(message);
            }
        }

        /// <summary>
        /// Writes the given message to the log file.
        /// </summary>
        /// <param name="message">The message to be written.</param>
        private static void WriteToLog(string message)
        {
            TextWriter tw = null;
            try
            {
                if (LoggingLocation == string.Empty || LoggingLocation == null)
                {
                    //LoggingLocation = "D:\\Workspace\\SmartCentre\\Logger\\";
                    LoggingLocation = ConfigurationManager.AppSettings["LoggingLocation"];
                }
                if (LogFileNamePrefix == string.Empty || LogFileNamePrefix == null)
                {
                    LogFileNamePrefix = "testname";
                }

                string sFileName = LoggingLocation + LogFileNamePrefix + DateTime.Now.ToString("yyyyMMdd") + ".txt";

                string sDirectoryPath = Path.GetDirectoryName(sFileName);

                if (!Directory.Exists(sDirectoryPath))
                {
                    Directory.CreateDirectory(sDirectoryPath);
                }
                tw = new StreamWriter(sFileName, true);

                tw.WriteLine("\n" + DateTime.Now + " : " + message + "\n");
            }
            catch
            {
                //eating away the exception intentionally.
            }
            finally
            {
                if (tw != null)
                {
                    tw.Flush();

                    tw.Close();
                }
            }
        }
        /// <summary>
        /// Logs the exception (message,stack trace,inner exception) in local service log file.
        /// </summary>
        /// <param name="ex">The exception to be logged.</param>
        public static void LogException(Exception ex)
        {
            if (ex != null && TraceEnabled)
            {
                WriteToLog("Exception message:" + ex.Message);

                WriteToLog("------------------------");

                WriteToLog("Exception stack trace:" + ex.StackTrace);

                WriteToLog("------------------------");

                if (ex.InnerException != null)
                {
                    WriteToLog("Inner exception message:" + ex.InnerException.Message);

                    WriteToLog("------------------------");

                    WriteToLog("Inner exception stack trace:" + ex.InnerException.StackTrace);
                }
            }
        }
        public static void LogApplicationData(string ControllerName, string ActionName, string ArgumentName, string ArgumentValue)
        {
            if (IsVerboseLoggingEnabled && TraceEnabled)
            {
                string m = string.Format("Controller Name:{0}\tAction Name:{1}\tReason:{2}\tValue:{3}\n", ControllerName, ActionName, ArgumentName, ArgumentValue);
                WriteToLog(m);
            }
        }

    }
}


