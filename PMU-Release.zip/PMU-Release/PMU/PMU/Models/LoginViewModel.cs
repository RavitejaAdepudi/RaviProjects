using System.ComponentModel.DataAnnotations;

namespace PMU.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Please Enter Contact Code", AllowEmptyStrings = false)] //^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]{2,4}$
        //[DataType(DataType.EmailAddress)]
        //[RegularExpression(@"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}.", ErrorMessage = "Entered Email format is invalid.")]
        //[EmailAddress (ErrorMessage="Invalid format")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Please Enter password", AllowEmptyStrings = false)]
        [DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        public bool RememberMe { get; set; }

        public string Licence { get; set; }

        public string MessageAlert { get; set; }

        public string ErrorMessage { get; set; }
        public string Confirmation { get; set; }
        public string EncryError { get; set; }
    }
}