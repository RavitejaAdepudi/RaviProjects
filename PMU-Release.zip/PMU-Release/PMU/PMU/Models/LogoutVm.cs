﻿namespace PMU.Models
{
    public class LogoutVm
    {
        public string UserName { get; set; }
    }
}