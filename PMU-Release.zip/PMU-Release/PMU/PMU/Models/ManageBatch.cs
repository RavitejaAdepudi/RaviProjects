﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMU
{
    public class ManageBatch
    {
        public int? BatchID { get; set; }
        public int SmartCentreBatchID { get; set; }
        public string BatchStartDate { get; set; }
        public string BatchEndDate { get; set; }
        public string PreferedAssessmentDate { get; set; }
        public string Jobrole { get; set; }
        public string TrainerName { get; set; }
        public string EnrolmentClosureDate { get; set; }
        public int TotalCandidatesinBatch { get; set; }
        public string BatchApprovalStatus { get; set; }
        public int Remaining { get; set; }
        public string RemarksforSSC { get; set; }
        public string BatchName { get; set; }
        public string AssetVerificationStatus { get; set; }
    }
}