﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMU.Model
{
    public class ManageBatchViewModel //: BaseModel
    {
        public ManageBatchViewModel()
        {
        }
     
        public int JobRoleDurationInHrs { get; set; }
        public int MinBatchsize { get; set; }
        public int maxbatchsize { get; set; }
        public string JobRoleCode { get; set; }
        public int Batch_size { get; set; }
        public int Target { get; set; }
        public int Target_Accomplished { get; set; }
        public int Balance { get; set; }

        public int EligibleBatch { get; set; }


        public int? CentreID { get; set; }
        public string PartnerName { get; set; }
        public string CentreName { get; set; }
        public string CentreType { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public int ConstituencyID { get; set; }
        public string CentreContact { get; set; }
        public string CentreSPOCDesignation { get; set; }
        public string CentreSPOCAadhaar { get; set; }
        public string CentreEmail { get; set; }
        public string CentreSPOCMobNo { get; set; }
        public string BankAccountNo { get; set; }
        public string Bank { get; set; }
        public string IFSC { get; set; }
        public string Branch { get; set; }


        //[Required(ErrorMessage = "Please select Scheme Name")]
        [Range(1, Int32.MaxValue, ErrorMessage = "Please select Scheme Name.")]
        public string Scheme { get; set; }
        
        //public string Sector { get; set; }
        [Required(ErrorMessage = "Please select Sector Name")]
        public string SectorId { get; set; }
        public IList<DropDownDDL> SectorList { get; set; }

        // [Required(ErrorMessage = "Please select Sub Sector")]
        public string SubSectorId { get; set; }
        public IList<DropDownDDL> SubSectorList { get; set; }

        [Required(ErrorMessage = "Please select Job Roles")]
        public string JobRole { get; set; }
        public string JobRoleName { get; set; }
        public IList<DropDownDDL> JobRoleList { get; set; }

        public List<ManageBatch> ManageBatchList { get; set; }
        public string DropDownID { get; set; }
        public IList<DropDownDDL> BatchStatusAprList { get; set; }
        public string ConstituencyName { get; set; }


        // public IList<DropDownDDL> JobRoleList { get; set; }

    }

    //Training Partner 
    public class TrainingPartner
    {
        public int ID { get; set; }
        public string Name { get; set; }
       
    }

  
    //Assessed Batch to list on the table 
    public class AssessedBatch
    {
        private TrainingPartner _trainingPartner;
        private ManageBatch _manageBatch;

        public TrainingPartner TrainingPartner
        {
            get {
                if (_trainingPartner == null)
                    _trainingPartner = new TrainingPartner();
                return _trainingPartner;
            }
            set { _trainingPartner = value; }
        }

        public ManageBatch ManageBatch
        {
            get {
                if (_manageBatch == null)
                    _manageBatch = new ManageBatch();
                return _manageBatch;
            }
            set
            {
                _manageBatch = value;
            }
        }

        public int LocationID { get; set; }
        public string LocationName { get; set; }
        public int PassedCount { get; set; }
        public int FailedCount { get; set; }
        public int NotAppearedCount { get; set; }
    }

    // Display Assessed Batches overall Data
    public class DispalyAssessedBatch
    {
        #region Private Members 

        private List<ManageBatch> _BatchList;
        private List<TrainingPartner> _TrainingPartnerList;
        private List<AssessedBatch> _AssessedBatchList;

        #endregion

        #region public Members 
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string CeremonyStatus { get; set; }

        public string TrainingPartnerName { get; set; }
        public string BatchName { get; set; }
        public string IsBack { get; set; }

        public IList<DropDownDDL> CeremonyStatusList { get; set; }
        public List<ManageBatch> BatchList
        {
            get
            {
                if (_BatchList == null)
                    _BatchList = new List<ManageBatch>();
                return _BatchList;
            }
            set
            {
                _BatchList = value;
            }
        }
        public List<TrainingPartner> TrainingPartnerList
        {
            get {
                if (_TrainingPartnerList == null)
                    _TrainingPartnerList = new List<TrainingPartner>();
                return _TrainingPartnerList;
            }
            set
            {
                _TrainingPartnerList = value;
            }
        }
        public List<AssessedBatch> AssessedBatchList
        {
            get {
                if (_AssessedBatchList == null)
                    _AssessedBatchList = new List<AssessedBatch>();
                return _AssessedBatchList;
            }
            set {
                _AssessedBatchList = value;
            }
        }

        #endregion

    }
}