﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class ManageContacts
    {
        public int ManageContactID { get; set; }
        public int PartnerID { get; set; }

        public int LocationID { get; set; }

        public int UserID { get; set; }

        public string ContactName { get; set; }

        public string Email { get; set; }

        public int GenderID { get; set; }

        public string Gender { get; set; }

        public int DesignationID { get; set; }

        public string Designation { get; set; }

        public string AadhaarNumber { get; set; }

        public int AadhaarVerificationStatusID { get; set; }

        public string AadhaarVerificationStatus { get; set; }

        public string MobileNumber { get; set; }

        public string MobileOTP { get; set; }

        public string MobileOTPVerificationStatus { get; set; }

        public string STDCode { get; set; }

        public string LandlineNo { get; set; }

        public int CreatedBy { get; set; }

        public string CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public string UpdatedDate { get; set; }

        public int ProjectID { get; set; }

        public char Status { get; set; }

        public int UniqueID { get; set; }

        public int SelectedSPOCID { get; set; }

        public bool IsSpoc { get; set; }

        public string NewPassword { get; set; }
        public string NewEncPassword { get; set; }

    }
}