﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace PMU
{
    public class ManageContactsViewModel
    {
        [Required(ErrorMessage = "Enter Candidate Name.")]
        public string ContactName { get; set; }

        [Range(1, Int32.MaxValue, ErrorMessage = "Please select Gender.")]
        public string Gender { get; set; }

        public IList<DropDownDDL> GenderList { get; set; }

        [DisplayName("Aadhaar Number")]
        [Required]
        public string AadhaarNumber { get; set; }

        public string AadhaarVerificationStatus { get; set; }

        [Required(ErrorMessage = "Enter Mobile Number.")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Enter 10 digit Mobile Number.")]
        public string MobileNumber { get; set; }

        public string Designation { get; set; }

        public string MobileNumberExistsinSystem { get; set; }

        public string MobileNumberExistsinStatus { get; set; }

        //[StringLength(4, MinimumLength = 4, ErrorMessage = "OTP must be length of 4")]
        public string EnterOTP { get; set; }

        public string MobileOTPVerificationStatus { get; set; }

        //[StringLength(5, MinimumLength = 3, ErrorMessage = "Landline Number must be length of 11")]
        public string StdCode { get; set; }

        //[StringLength(8, MinimumLength = 6, ErrorMessage = "Landline Number must be length of 11")]
        public string LandlineNumber { get; set; }

        [Required(ErrorMessage = "Enter Email Address.")]
        [DataType(DataType.EmailAddress)]
        [StringLength(255)]
        [RegularExpression(@"^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]{2,4}$", ErrorMessage = "Enter valid Email Address.")]
        public string EmailAddress { get; set; }

        public int CreatedBy { get; set; }

        public int? Updatedby { get; set; }

        public bool IsLocation { get; set; }

        public string RandomPassword { get; set; }

        public int? ManageContactID { get; set; }

        public string Type { get; set; }

        public int ContactID { get; set; }

        public int PartnerID { get; set; }

        public int CentreID { get; set; }

        public IList<ManageContacts> ManageContactsList { get; set; }
    }
}