﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMU
{
    public class PMUTargetAllocation
    {
        public string TrainingPartner { get; set; }
        public string ProjectName { get; set; }
        public int TrainingPartnerID { get; set; }

        public string TrainingType { get; set; }

        public int ProjectID { get; set; }

        public string TargetName { get; set; }

        public IList<ProjectJobRole> ProjectJobRoleList { get; set; }

        public IList<ProjectJobRole> SelectedJobRoleTarget { get; set; }

        public IList<TrainingLocations> LocationTargetNameList { get; set; }

        //Add Location Partial View
        public int AllocatedTarget { get; set; }

        public string LocationName { get; set; }

        public string LocationResponse { get; set; }

        public string ModelResponse { get; set; }

        //JobRoleDetails Popup
        public string JobRoleCode { get; set; }

        public int TargetAllocated { get; set; }

        //Manage Job Role Details
        public string ManageJobRoleSectorName { get; set; }

        public IList<DropDownDDL> ManageJobRoleList { get; set; }

        public int ManageJobroleTarget { get; set; }

        //Hidden Fields To capture Job Role Details
        public int PartnerID { get; set; }

        public int JobRoleID { get; set; }

        public int LocationID { get; set; }

        public int TrainingTypeID { get; set; }

        public int JobRoleAffilID { get; set; }

        public int OldJobRoleID { get; set; }

        public int PreviousTarget { get; set; }

        public TrainingLocations TrainingLocationsDetails { get; set; }
    }

    //Job Role Details
    public class SectorTargetDropDownVM
    {
        public int SectorID { get; set; }

        public string SectorName { get; set; }

        public int JobRoleID { get; set; }

        public string JobRoleName { get; set; }

        public int Target { get; set; }

        public int PartnerID { get; set; }

        public int RemainingTarget { get; set; }

        public int TrainingType { get; set; }

        public int CentreID { get; set; }

        public int JobRoleAffiliationID { get; set; }

        public string IsBridgeCourse { get; set; }

        public int BridgeCourseDuration { get; set; }
    }

    //Location Target details
    public class LocationTargetDropDownVM
    {
        public string IsSelected { get; set; }

        public string LocationName { get; set; }

        public string JobRoleCode { get; set; }

        public int Balance { get; set; }

        public int Target { get; set; }

        public int SectorID { get; set; }

        public int JobRoleID { get; set; }

        public int PartnerID { get; set; }

        public int RemainingTarget { get; set; }

        public int TrainingType { get; set; }

        public int CentreID { get; set; }

        public int JobRoleAffiliationID { get; set; }
    }


}
