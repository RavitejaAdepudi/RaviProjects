﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class Placements
    {
        public int TrainingTypeID { get; set; }
        public string TrainingTypeName { get; set; }
        public int VerificationStatusID { get; set; }
        public string VerificationStatusName { get; set; }
        public IList<DropDownDDL> TriningTypeDDl { get; set; }
        public IList<DropDownDDL> VerificationStatusDDl { get; set; }
        public IList<TrainingLocations> TrainingLocationList { get; set; }
        public IList<BatchDetails> BatchDetailsList { get; set; }
    }
}