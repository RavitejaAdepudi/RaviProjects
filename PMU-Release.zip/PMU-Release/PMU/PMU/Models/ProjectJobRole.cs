﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
namespace PMU
{
    public class ProjectJobRole
    {
        public string Sector { get; set; }
        public string SubSector { get; set; }
        public decimal? JobRoleTarget { get; set; }
        public bool HasBridgeCourse { get; set; }
        public int BridgeCourseDuration { get; set; }
        public int SectorID { get; set; }
        public int SubSectorID { get; set; }
        public IList<DropDownDDL> SectorList { get; set; }
        public IList<DropDownDDL> SubSectorTypeList { get; set; }
        public string selectedJobRoleText { get; set; }
        public string[] JobRole { get; set; }
        public string SectorType { get; set; }
        public int SectorTypeId { get; set; }

        public string hidJobRoleId { get; set; }

        // public string SectorId { get; set; }

        public string JobroleCode { get; set; }
        public int JobroleID { get; set; }
        public IList<DropDownDDL> ProjectJobroleList { get; set; }
        public IList<DropDownDDL> SectorTypeList { get; set; }

        public decimal RemainingTarget { get; set; }
        public string TrainingType { get; set; }

        public decimal? BridgeCourseDiscount { get; set; }

        public bool isJobRoleDelete { get; set; }

        public bool isTargetAllocation { get; set; }
    }
}