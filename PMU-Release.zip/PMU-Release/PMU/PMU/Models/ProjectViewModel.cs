﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
namespace PMU
{
    public class ProjectViewModel
    {
        public string Sector { get; set; }
        public string JobroleCode { get; set; }
        public string TrainingPartner { get; set; }
        public int TrainingPartnerID { get; set; }
        public IList<DropDownDDL> TrainingPartnerTypeList { get; set; }
        public string AccountID { get; set; }
        public string SDMSCode { get; set; }

        [Required(ErrorMessage = "Please select a Training Type")]
        public int TrainingTypeID { get; set; }

        [DisplayName("Training Type")]
        [Required]
        public string TrainingType { get; set; }
        public IList<DropDownDDL> TrainingTypeList { get; set; }
        public int? ProjectID { get; set; }
        [DisplayName("Project Name")]
        [Required]
        public string ProjectName { get; set; }
        public string ProjectCode { get; set; }
        public string CRMProjectID { get; set; }
        public string ProjectType { get; set; }
        [Required(ErrorMessage = "Please select a Project Type")]
        public int ProjectTypeID { get; set; }
        public IList<DropDownDDL> ProjectTypeList { get; set; }
        public string Disbursement { get; set; }
        [DisplayName("Placement Disbursement")]
        [Required]
        public int PlacementDisbursementID { get; set; }
        public IList<DropDownDDL> PlacementApplicableDisbursmentList { get; set; }

        [Required(ErrorMessage = "Please select a Disbursement Mode")]
        public int DisbursementModeID { get; set; }
        public int ProjectJobRoleTarget { get; set; }
        public int LocalityID { get; set; }
        public string DisbursementMode { get; set; }
        public IList<DropDownDDL> DisbursementModeTypeList { get; set; }
        public string CertificateTemplate { get; set; }

        //[Required(ErrorMessage = "Please select a Certificate Template")]
        public string CertificateTemplateTypeID { get; set; }
        public string CustomTemplateLogoURL { get; set; }
        public string FileName { get; set; }
        public IList<DropDownDDL> CertificateTemplateTypeList { get; set; }
        public int ProjectDuration { get; set; }

        //[DisplayName("Batch Duration")]
        //[Required]
        public int? BatchDuration { get; set; }

        [DisplayName("Start Date")]
        [Required]
        public string StartDate { get; set; }
        [DisplayName("End Date")]
        [Required]
        public string EndDate { get; set; }
        public int LocationCount { get; set; }
        public int AllowedJobRoleCount { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public bool HasBridgeCourse { get; set; }
        public bool? IsPlacementApplicable { get; set; }
        public string[] LocationJobRole { get; set; }
        public string LocationJobroleCode { get; set; }
        public string LocationJobroleID { get; set; }
        public IList<DropDownDDL> LocationJobroleList { get; set; }
        public string LocationName { get; set; }
        public int LocationID { get; set; }

        public HttpPostedFileBase CustomTemplateLogo { get; set; }
        [DisplayName("PIA Fee")]
        [Required]
        public decimal PIAFee { get; set; }
        public string ProjectErrorMsg { get; set; }
        public int BridgeCourseHours { get; set; }
        public IList<DropDownDDL> LocationNameList { get; set; }
        public string xmlProjecJobRoleDoc { get; set; }
        public string xmlLocatinJobRoleDoc { get; set; }
        //public IList<Location> LocationList { get; set; }
        public IList<ProjectJobRole> ProjectJobRoleList { get; set; }
        public IList<int> SelectedLocationJobRoleList { get; set; }
        public IList<int> SelectedProjectJobRoleList { get; set; }
        public ProjectJobRole ProjectJobRoleDetails { get; set; }
        public TrainingPartner TrainingPartnerDetails { get; set; }
        public IList<TrainingPartner> TrainingPartnerList { get; set; }
        public IList<ProjectsModel> ProjectDetailsList { get; set; }
        public string ProjectJobRoleDetailsErromsg { get; set; }
        public IList<DropDownDDL> SectorTypeList { get; set; }
        public IList<DropDownDDL> JobroleList { get; set; }

        public bool IsBatchBackDateEnable { get; set; }
        public string BatchBackDate { get; set; }

        public string BatchBackDateErrorMsg { get; set; }

        public int? CustomCertificateTemplateId { get; set; }
        public string CustomCertificateTemplate { get; set; }

        private IList<DropDownDDL> _customTemplateList;
        private CustomTemplateType _customTemplateType;

        public CustomTemplateType CustomTemplateType
        {
            get { return _customTemplateType ?? (_customTemplateType = new CustomTemplateType()); }
            set { _customTemplateType = value; }
        }
        public IList<DropDownDDL> CustomTemplateList
        {
            get { return _customTemplateList ?? (_customTemplateList = new List<DropDownDDL>()); }
            set { _customTemplateList = value; }
        }

    }

    public class Location
    {
        public int LocationID { get; set; }
        public string LocationName { get; set; }
        public int JobRoleID { get; set; }
        public string LocationXML { get; set; }
        public int SectorID { get; set; }
        public string SelectedJobRolesNames { get; set; }
        public IList<int> SelectedJobRoleList { get; set; }
    }

    public class CustomTemplateType
    {
        public int Id { get; set; }
        public int TriningType { get; set; }
        public string CustomType { get; set; }
        public int GovtLogoCount { get; set; }
        public int CorporateLogoCount { get; set; }
        public string Position { get; set; }

        public int LeftPosition
        {
            get
            {
                if (!string.IsNullOrEmpty(Position))
                    return Convert.ToInt32(this.Position.Split('-')[0]);
                return default(int);
            }
        }
        public int RightPosition
        {
            get
            {
                if (!string.IsNullOrEmpty(Position))
                    return Convert.ToInt32(this.Position.Split('-')[1]);
                return default(int);
            }
        }

        private List<CustomFileDetail> _customFileSelectedGovt;
        public List<CustomFileDetail> CustomFileSelectedGovt
        {
            get { return _customFileSelectedGovt ?? (_customFileSelectedGovt = new List<CustomFileDetail>()); }
            set { _customFileSelectedGovt = value; }
        }

        private List<CustomFileDetail> _customFileSelectedCorporate;
        public List<CustomFileDetail> CustomFileSelectedCorporate
        {
            get { return _customFileSelectedCorporate ?? (_customFileSelectedCorporate = new List<CustomFileDetail>()); }
            set { _customFileSelectedCorporate = value; }
        }
    }

    public class CustomFileDetail
    {
        public int AssetId { get; set; }
        public int FileNumber { get; set; }
        public string FileName { get; set; }
        public CustomLogoFor LogoFor { get; set; }
        public string FileSource { get; set; }
        public string Position { get; set; }
        public string IndustryType { get; set; }
    }

    public enum CustomLogoFor
    {
        None =0,
        Government = 1,
        Corporation = 2
    }
}