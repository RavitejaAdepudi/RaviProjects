﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMU
{
    public class ProjectsModel
    {
        [Required(ErrorMessage = "Please select Training Type")]
        [Range(1, 1000000, ErrorMessage = "Please select Training Type")]
        //public string TrainingTypeId { get; set; }
        public IList<DropDownDDL> TrainingTypeList { get; set; }

        public string ProjecTypeId { get; set; }
        public string TrainingType { get; set; }
        public int TrainingTypeID { get; set; }

        public string TrainingPartner { get; set; }

        public int TrainingPartnerID { get; set; }

        public string ProjectErrorMsg { get; set; }        //To Show Validation ErRor From DB

        public int SerialNo { get; set; }
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }

        public string Sector { get; set; }
        public string JobRole { get; set; }
        public string SectorDisplayName { get; set; }
        public string JobRoleDisplayName { get; set; }
        public string ProjectType { get; set; }
        public string TrainingTypeName { get; set; }
        public string ManageTarget { get; set; }
        public string SubmittedToPMU { get; set; }
    }
}
