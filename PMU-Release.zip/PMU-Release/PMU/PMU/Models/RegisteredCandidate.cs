﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU.Models
{
    public class RegisteredCandidate
    {
        public int BatchId { get; set; }
        public string CandidateId { get; set; }
        public string CandidateName { get; set; }
        public string Gender { get; set; }
        public string RegistrationDate { get; set; }
        public string AadharVerificationStatus { get; set; }
        public string AlternateIdVerificationStatus { get; set; }
        public string MobileNoExists { get; set; }
        public string MobileOTPStatus { get; set; }
        public string EligibleForDisbursement { get; set; }
        public string EligibleForEnrollment { get; set; }
        public int Enrollementcount { get; set; }
        public int Remaining { get; set; }
        public int count { get; set; }
        public string BatchName { get; set; }
        public string CentreCandID { get; set; }
        public int MarkPercent { get; set; }
        public string Grade { get; set; }
        public string Result { get; set; }
    }
}