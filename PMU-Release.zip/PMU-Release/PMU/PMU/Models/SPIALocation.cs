﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace PMU
{
    //public class SPIALocation
    //{
    //    [DisplayName("Training Partner / PIA Name / SPIA Name")]
    //    [Required]
    //    public string TrainingPartner { get; set; }
    //    public int TrainingPartnerID { get; set; }
    //    public IList<DropDownDDL> TrainingPartnerTypeList { get; set; }
    //    public string AccountID { get; set; }
    //    public string SDMSCode { get; set; }

    //    [Required(ErrorMessage = "Please select a Training Type")]
    //    public int TrainingTypeID { get; set; }

    //    [DisplayName("Training Type")]
    //    [Required]
    //    public string TrainingType { get; set; }
    //    public IList<DropDownDDL> TrainingTypeList { get; set; }
    //    public int ? ProjectID { get; set; }
    //    public int PartnerID { get; set; }
    //    public string CRMProjectID { get; set; }
    //    public string ProjectType { get; set; }

    //    [Required(ErrorMessage = "Please select a Project Type")]
    //    public int ProjectTypeID { get; set; }
    //    public IList<DropDownDDL> ProjectTypeList { get; set; }
    //    [DisplayName("Project Name")]
    //    [Required]
    //    public string ProjectName { get; set; }
    //    public string ProjectCode { get; set; }
    //    public string Disbursement { get; set; }
    //    [DisplayName("Placement Disbursement")]
    //    [Required]
    //    public int PlacementDisbursementID { get; set; }
    //    public IList<DropDownDDL> PlacementApplicableDisbursmentList { get; set; }

    //    [Required(ErrorMessage = "Please select a Disbursement Mode")]
    //    public int DisbursementModeID { get; set; }
    //    public int ProjectJobRoleTarget { get; set; }
    //    public int LocalityID { get; set; }
    //    public string DisbursementMode { get; set; }
    //    public IList<DropDownDDL> DisbursementModeTypeList { get; set; }
    //    public string CertificateTemplate { get; set; }

    //    [Required(ErrorMessage = "Please select a Certificate Template")]
    //    public string CertificateTemplateTypeID { get; set; }
    //    public string CustomTemplateLogoURL { get; set; }
    //    public string FileName { get; set; }
    //    public IList<DropDownDDL> CertificateTemplateTypeList { get; set; }
    //    public int ProjectDuration { get; set; }

    //    public int BatchDuration { get; set; }

    //    [DisplayName("Start Date")]
    //    [Required]
    //    public string StartDate { get; set; }
    //    [DisplayName("End Date")]
    //    [Required]
    //    public string EndDate { get; set; }
    //    public int LocationCount { get; set; }
    //    public int AllowedJobRoleCount { get; set; }
    //    public bool IsActive { get; set; }
    //    public bool IsDeleted { get; set; }
    //    public bool HasBridgeCourse { get; set; }
    //    public bool ?IsPlacementApplicable { get; set; }
    //    public string[] LocationJobRole { get; set; }
    //    public string LocationJobroleCode { get; set; }
    //    public string LocationJobroleID { get; set; }
    //    public IList<DropDownDDL> LocationJobroleList { get; set; }
    //    public string LocationName { get; set; }
    //    public int LocationID { get; set; }

    //    [DisplayName("Attach Logo for Custom Template")]
    //    [Required]
    //    public HttpPostedFileBase CustomTemplateLogo { get; set; }
    //    [DisplayName("PIA Fee")]
    //    [Required]
    //    public decimal PIAFee { get; set; }
    //    public IList<DropDownDDL> LocationNameList { get; set; }
    //    public string xmlProjecJobRoleDoc { get; set; }
    //    public string xmlLocatinJobRoleDoc { get; set; }
    //    public IList<Location> LocationList { get; set; }
    //    public IList<ProjectJobRole> ProjectJobRoleList { get; set; }
    //    public IList<int> SelectedLocationJobRoleList { get; set; }
    //    public IList<int> SelectedProjectJobRoleList { get; set; }
    //    public  ProjectJobRole ProjectJobRoleDetails { get; set; }
    //    public TrainingPartner TrainingPartnerDetails { get; set; }
    //    public  IList<TrainingPartner> TrainingPartnerList { get; set; }
    //}
    //public class Location
    //{
    //    public int LocationID { get; set; }
    //    public string LocationName { get; set; }
    //    public int JobRoleID { get; set; }
    //    public string LocationXML { get; set; }
    //    public int SectorID { get; set; }
    //    public string SelectedJobRolesNames { get; set; }
    //    public IList<int> SelectedJobRoleList { get; set; }
    //}
}
