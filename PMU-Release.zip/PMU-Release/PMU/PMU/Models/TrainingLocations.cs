﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace PMU
{
    public class TrainingLocations:BaseModel
    {
        public int PartnerID { get; set; }
        public string PartnerName { get; set; }
        public int ProjectID { get; set; }
        public string ProjectType { get; set; }
        public string EmployerName { get; set; }
        public int PriorityOrder { get; set; }
        public int ContactID { get; set; }
        public string RowVersion { get; set; }

        public int PageID { get; set; }

        public int SDMSID { get; set; }

        [Required(ErrorMessage = "Enter Address Line.")]
        public string TraineeAddressLine1 { get; set; }
        public int TrainingCampOrEmployerLocationId { set; get; }
        public int TotalBatchAssessed { set; get; }
        public int TotalBatchesPendingValidation { set; get; }

        [Required(ErrorMessage = "Enter 6 digit Pincode.")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Enter 6 digit Pincode.")]
        public string PINCode { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "")]
        public string TraineeState { get; set; }
        public IList<DropDownDDL> TraineeStateList { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select District.")]
        public string TraineeDistrict { get; set; }
        public IList<DropDownDDL> TraineeDistrictList { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select Sub District.")]
        public string TraineeSubDistrict { get; set; }
        public IList<DropDownDDL> TraineeSubDistrictList { get; set; }

        //[Required(ErrorMessage = "Enter Sub District.")]
        public string TraineeSubDistrictOthers { get; set; }
        public string tTraineeSubDistrict { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select Post Office.")]
        public string PostOffice { get; set; }
        public IList<DropDownDDL> PostOfficeList { get; set; }

        // [Required(ErrorMessage = "Enter Post Office.")]
        public string PostOfficeOthers { get; set; }
        public string tPostOffice { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select Trainee/Village/TownCity.")]
        public string TraineeVillageTownCity { get; set; }
        public IList<DropDownDDL> TraineeVillageTownCityList { get; set; }

        //[Required(ErrorMessage = "Enter Trainee/Village/TownCity.")]
        public string TraineeVillageTownCityOthers { get; set; }
        public string tTraineeVillageTownCity { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select Locality.")]
        public string Locality { get; set; }
        public string CityId { get; set; }

        public IList<DropDownDDL> LocalityList { get; set; }

        //[Required(ErrorMessage = "Enter Locality.")]
        public string LocalityOthers { get; set; }
        public string tLocality { get; set; }

        //[Range(1, Int32.MaxValue, ErrorMessage = "Please select Constituency.")]
        public string Constituency { get; set; }
        public IList<DropDownDDL> ConstituencyList { get; set; }
        public string TrainingType { get; set; }
        public int TrainingTypeID { get; set; }

        public IList<DropDownDDL> TrainingTypeList { get; set; }
        public bool IsSelectorEnterAddress { get; set; }

        public string TraineeMobileNumber { get; set; }
        public string LandlineNumber { get; set; }

        public string LandlineNumberTwo { get; set; }

        [Required(ErrorMessage = "Enter STD Code")]
        [StringLength(5, MinimumLength = 3, ErrorMessage = "STD must be length of 3 to 5")]
        public string STD { set; get; }
        public string STDTwo { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        [StringLength(255)]
        [RegularExpression(@"^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]{2,4}$", ErrorMessage = "Enter valid Email Address.")]
        public string EmailAddress { get; set; }



        public string SelectAddress { get; set; }
        public string EnteredAddress { get; set; }

        [Required(ErrorMessage = "Enter Location name.")]
        public string LocationName { get; set; }
        public string BatchApprovalStatus { get; set; }
        public int JobRoleID { get; set; }
        public string JobRoleIDString { get; set; }
        public string JobRoleName { get; set; }
        public string JobRoleDisplayName { get; set; }
        public string LocationXML { get; set; }
        public int SectorID { get; set; }
        public int LocationID { get; set; }

        public string JobRoleCode { get; set; }

        public string SelectedJobRolesNames { get; set; }
        public IList<DropDownDDL> ProjectJobroleList { get; set; }
        public IList<DropDownDDL> SectorTypeList { get; set; }
        public int? JobRoleTarget { get; set; }
        public int? RemainingJobRoleTarget { get; set; }
        public IList<TrainingLocations> LocationJobRoleDetailsList { get; set; }
        public IList<DropDownDDL> LocationJobroleListDdl { get; set; }
        //public IList<DropDownDDL> LocationJobroleList { get; set; }
        public IList<int> SelectedJobRoleList { get; set; }
        public int UserID { get; set; }
        public bool IsCenter { get; set; }
        public int SelectedSPOCID { get; set; }
        public char Status { get; set; }

        public bool IsAllowAlternateID { get; set; }
        public bool IsHostelFacility
        { get; set; }
        public bool IsHostelFacilityMale { get; set; }
        public bool ISHostelFacilityFemale { get; set; }
        public bool IsHostelFacilityTransgender { get; set; }
        public ManageContactsViewModel ManageContactsDetails { get; set; }
        public IList<ManageContacts> ManageContactsList { get; set; }

        public string HostelCapacity { get; set; }
        public string ConsumedHostelCapacity { get; set; }
        public bool IsAllowBankAccount { get; set; }
    }
}