﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
namespace PMU
{
    public class TrainingPartner
    {
        public int PartnerID { get; set; }

        [DisplayName("Partner Name")]
        [Required]
        public string PartnerName { get; set; }
        public string PartnerType { get; set; }
        public int PartnerTypeID { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        [DisplayName("SPOC Name")]
        [Required]
        public string SPOCName { get; set; }
        [DisplayName("SPOC Mobile")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Mobile Number.")]
        [Required]
        public string SPOCMobile { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        [StringLength(255)]
        [RegularExpression(@"^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]{2,4}$", ErrorMessage = "Enter valid Email Address.")]
        public string SPOCEmail { get; set; }


        public int ContactID { get; set; }
        public int CentreID { get; set; }
        public int CreatedBy { get; set; }

        public string RandomPassword { get; set; }
    }
}