﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMU.Infrastructure;

namespace PMU
{
    public class UserModel
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public DateTime? LastModified { get; set; }
        public bool? Inactive { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string EMail { get; set; }
        public int CentreId { get; set; }
        public int PartnerId { get; set; }
        public long ProjectId { get; set; }
        public bool IsCentre { get; set; }
        public bool IsLocation { get; set; }
        public string SessionId { get; set; }
        public string Fullname { get; set; }
        public int ContactId { get; set; }
        public List<UserRole> UserRoles { get; set; }
        public List<RolePermission> Permissions { get; set; }
        public bool RememberMe { get; set; }
        public string LandingPage { get; set; }
        public string Password { get; set; }

        public int TrainingType { get; set; }
    }
}
