﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMU
{
    public class ViewManageContacts
    {
        public int UserID { get; set; }

        public int ManageContactID { get; set; }

        public string ContactName { get; set; }

        public string MobileNumber { get; set; }

        public string EmailAddress { get; set; }

        public string AadhaarNumber { get; set; }

        public string Gender { get; set; }

        public IList<DropDownDDL> GenderList { get; set; }

        public IList<ViewManageContacts> ViewManageContactsList { get; set; }

        public string Designation { get; set; }

        public string MobileOTPVerificationStatus { get; set; }

        public string AadhaarVerificationStatus { get; set; }

    }
}