﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web;
using PMU.Infrastructure;
using PMU.Repository;
using System.Linq;
using System.Text;

namespace PMU
{
    public partial class DbAction
    {
        DataAccess _dbA = new DataAccess();

        public string ConvertHexToString(string hexInput, Encoding encoding)
        {
            int numberChars = hexInput.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hexInput.Substring(i, 2), 16);
            }
            return encoding.GetString(bytes);
        }

        public string CentreCandIdGenerator(string generateOrSave, string centreId, string centreCandIdFromPage)
        {
            //string centreCandidateId = string.Empty;
            DataTable dt = new DataTable();
            string parms = "GenerateOrSave" + "$" + "centreId" + "$" + "centreCandIdFromPage";
            string parmValues = generateOrSave + "$" + centreId + "$" + centreCandIdFromPage;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["CentreCandIdGenerator"];
            dt = _dbA.SaveAttachemnt(spName, parms, parmValues);

            string centreCandidateId = dt.Rows[0][0].ToString();
            return centreCandidateId;
        }
        public List<DropDownDDL> GetCommonDropdownLookup(string property,string tabName=null)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            DataTable dt = new DataTable();
            dict.Add("@Property", property);
            dict.Add("@TabName", tabName);
            dict.Add("@TraingType", SessionMgr.LoginUserDetails.TrainingType);
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["GetCommonDropdownLookupPMU"];
            return DataTableToList(_dbA.GetDataTable(spName, dict), false);
        }

        public List<DropDownDDL> GetProjectLocationJobRole(int projectID, int CentreID = 0)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            DataTable dt = new DataTable();
            dict.Add("@ProjectID", projectID);
            // dict.Add("@CentreID", projectID);
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMULocationGetJobRoles"];
            return DataTableToList(_dbA.GetDataTable(spName, dict), false);
        }

        public IList<TrainingLocations> GetLocationJobRoleList(int locationID, int projectID, int CentreID, int partnerID)
        {

            Dictionary<string, object> dict = new Dictionary<string, object>();
            DataTable dt = new DataTable();
            dict.Add("@LocationID", locationID);
            dict.Add("@ProjectID", projectID);
            dict.Add("@PartnerID", partnerID);
            // dict.Add("@CentreID", projectID);
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMULocationGetJobRolesList"];
            return DataTableToLocationJobRoleList(_dbA.GetDataTable(spName, dict));
        }

        public bool IsAllowToReduceCoutRespectToCadidate(int jobRoleID, int sourceTarget)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            DataTable dt = new DataTable();
            dict.Add("@JobRoleID", jobRoleID);
            dict.Add("@SourceTarget", sourceTarget);
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMU_CheckCandidateCountTarget"];
            dt = _dbA.GetDataTable(spName, dict);
            string result = dt.Rows[0]["Result"].ToStr();
            return result == "true" ? true : false;
        }
        public int CheckSPOCExists(int manageContactID)
        {
            var parms = new Dictionary<string, object>();
            var spName = ConfigurationManager.AppSettings["SPIA_CheckSPOCExists"];
            parms.Add("@UserID", manageContactID);
            var result = _dbA.ExecuteScalar(spName, parms);
            return (result);
        }

        public IList<ManageContacts> GetManageContactList(int locationID, int projectID, int CentreID, string trainingType)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            DataTable dt = new DataTable();
            dict.Add("@LocationID", locationID);
            dict.Add("@ProjectID", projectID);
            // dict.Add("@CentreID", projectID);
            dict.Add("@TrainingType", trainingType);

            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMULocationGetManageContactsList"];
            return DataTableToManageContactsList(_dbA.GetDataTable(spName, dict));
        }

        private IList<ManageContacts> DataTableToManageContactsList(DataTable dt)
        {
            IList<ManageContacts> list = new List<ManageContacts>();
            list = (from DataRow row in dt.Rows
                    select new ManageContacts()
                    {
                        ManageContactID = row["ManageContactID"].ToInt(),
                        ContactName = row["Fullname"].ToStr(),
                        Email = row["Email"].ToStr(),
                        MobileNumber = row["MobileNumber"].ToStr(),
                        AadhaarNumber = row["AadhaarNumber"].ToStr(),
                        IsSpoc = row["IsSPOC"].ToBoolean(),
                        Status = 'I'
                    }).ToList();
            return list;
        }
        private IList<TrainingLocations> DataTableToLocationJobRoleList(DataTable dt)
        {
            IList<TrainingLocations> list = new List<TrainingLocations>();
            if (dt.Rows.Count > 0)
            {
                try
                {
                    list = (from DataRow row in dt.Rows
                            select new TrainingLocations()
                            {
                                JobRoleTarget = row["JobRoleTarget"].ToInt(),
                                RemainingJobRoleTarget = row["RemaingTarget"].ToInt(),
                                SelectedJobRolesNames = row["JobRole"].ToStr(),
                                JobRoleID = row["JobRoleID"].ToInt(),
                                JobRoleCode = row["JobRoleCode"].ToStr(),
                                Status = 'I',
                                //RowVersion= row["RowVersionCol"].ToStr(),
                                TrainingType = SessionMgr.TrainingType
                            }).ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return list;
        }

        private List<DropDownDDL> DataTableToList(DataTable table, bool includeSelect = true)
        {
            var list = new List<DropDownDDL>(table.Rows.Count);
            var ddl = new DropDownDDL();
            if (includeSelect)
            {
                ddl = new DropDownDDL()
                {
                    nIndex = -1,
                    tDisplayName = "Select"
                };
                list.Add(ddl);
            }
            foreach (DataRow row in table.Rows)
            {
                var values = row.ItemArray;
                ddl = new DropDownDDL()
                {
                    nIndex = Convert.ToInt32(values[0]),
                    tDisplayName = values[1].ToString()
                };
                list.Add(ddl);
            }
            return list;
        }
        //public int UploadAttachment(int cadidateID, DataTable dtAttachment, int objectType, string szFilename, string szDocumentType, int tabid)
        //{
        //    try
        //    {

        //        int result = 0;
        //        string status = string.Empty;
        //        Byte[] blob = null;
        //        blob = (byte[])dtAttachment.Rows[0][1];
        //        int nsize;
        //        nsize = blob.GetUpperBound(0);
        //        szFilename = szFilename.Contains("'") ? szFilename.Replace("'", "''") : szFilename;
        //        szDocumentType = szDocumentType.Contains("'") ? szDocumentType.Replace("'", "''") : szDocumentType;

        //        DataAccess dbA = new DataAccess();

        //        DataTable dt = new DataTable();

        //        //Calling the stored procedure to upload documents
        //        SqlConnection conn = GetDBConnection();
        //        SqlCommand cmd = new SqlCommand(SPName, conn);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandTimeout = 10000;
        //        //cmd.Parameters.AddWithValue("@nFlag", flag);
        //        cmd.Parameters.AddWithValue("@nObjecttype", objectType);
        //        cmd.Parameters.AddWithValue("@nObjectId", objectId);
        //        cmd.Parameters.AddWithValue("@szFileName", szFilename.Trim());
        //        SqlParameter param = null;
        //        param = new SqlParameter("@iFile", SqlDbType.VarBinary, blob.Length,
        //                    ParameterDirection.Input, false, 0, 0, null, DataRowVersion.Current, blob);
        //        cmd.Parameters.Add(param);
        //        cmd.Parameters.AddWithValue("@szDocumentType", szDocumentType);
        //        cmd.Parameters.AddWithValue("@nTabId", tabid);
        //        cmd.ExecuteNonQuery();

        //        string Parms = "FileType" + "$" + "CadidateID" + "$" + "tFileName" + "$" + "FileData" + "$" + "Size" + "$" + "tFile" + "$" + "Comment";
        //        string ParmValues = 1 + "$" + cadidateID + "$" + szFilename + "$" + viewModel.BelowPovertyLineIDNumber + "$" + viewModel.Scheme + "$" + viewModel.TrainingType + "$" + viewModel.Sector + "$" + viewModel.SubSector + "$" + viewModel.JobRole + "$" + viewModel.CandidateName;
        //        string SPName = string.Empty;
        //        SPName = ConfigurationManager.AppSettings["UploadImage"].ToString();
        //        dt = dbA.SaveAttachemnt(SPName, Parms, ParmValues);
        //        return 1;
        //    }
        //    catch (Exception ex)
        //    {
        //        return 0;
        //    }
        //}

        public int MobileOtpCheck()
        {
            return 0;
        }
        private List<DropDownDDL> DdlDataTableToList(DataTable table)
        {
            var list = new List<DropDownDDL>(table.Rows.Count);
            var ddl = new DropDownDDL()
            {
                nIndex = -1,
                tDisplayName = "Select"
            };
            list.Add(ddl);
            for (int i = 0; i < table.Rows.Count; i++)
            {
                ddl = new DropDownDDL()
                {
                    nIndex = Convert.ToInt32(table.Rows[i][2]),
                    tDisplayName = table.Rows[i][1].ToString()

                };
                list.Add(ddl);
            }
            return list;
        }

        private List<DropDownDDL> DataTableToList(DataTable table)
        {
            var list = new List<DropDownDDL>(table.Rows.Count);
            var ddl = new DropDownDDL()
            {
                nIndex = -1,
                tDisplayName = "Select"
            };
            list.Add(ddl);
            foreach (DataRow row in table.Rows)
            {
                var values = row.ItemArray;

                ddl = new DropDownDDL()
                {
                    nIndex = Convert.ToInt32(values[0]),
                    tDisplayName = values[1].ToString()
                };

                ddl.tDisplayCode = values.Length > 2 ? $"{values[2]}" : string.Empty;
                ddl.nAltIndex = values.Length > 3 ? $"{values[3]}" : string.Empty;
                ddl.nAltIndex2 = values.Length > 4 ? $"{values[4]}" : string.Empty;

                list.Add(ddl);
            }
            return list;
        }

        #region LicenceKey Activation
        /// <summary>
        /// Checking LicenceKey Activation
        /// </summary>
        public DataTable ActivateLicenceKey(string userid, string password, int licflag, string licence)
        {
            DataTable dt = new DataTable();
            string parms = "UserName" + "$" + "Pwd" + "$" + "LicStatus" + "$" + "LicenseKey";
            string parmValues = userid + "$" + password + "$" + licflag + "$" + licence;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["Login"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return dt;
        }
        #endregion

        #region Login
        /// <summary>
        /// Checking user credentials
        /// </summary>
        public DataTable CheckUserIdPassword(string userid, string password)
        {
            DataTable dt = new DataTable();
            string parms = "UserName" + "$" + "Pwd";
            string parmValues = userid + "$" + password;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["Login"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return dt;
        }
        #endregion

        #region Login -To save login record
        /// <summary>
        /// save login record
        /// </summary>
        public DataTable CheckLoginRecord(int tcid, int nId, string sessionid, int userId, int pagetype = 0)
        {
            DataTable dt = new DataTable();
            var prams = new Dictionary<string, object>();
            prams.Add("@CentreId", tcid);
            prams.Add("@ContactId", nId);
            prams.Add("@SessionId", sessionid);
            prams.Add("@PageType", pagetype);
            prams.Add("@UserId", userId);
            string spName = ConfigurationManager.AppSettings["InsertLoginRecord"];
            dt = _dbA.GetDataTable(spName, prams);
            return dt;
        }
        #endregion

        #region Login - Inserting Login record in to tbl_Login
        public DataTable InsertLoginRecord(int tcid, int nId, string email, string sessionid, int userId, string logout = null, int pagetype = 1)
        {
            DataTable dt = new DataTable();

            var prams = new Dictionary<string, object>();
            prams.Add("@CentreId", tcid);
            prams.Add("@ContactId", nId);
            prams.Add("@SessionId", sessionid);
            prams.Add("@LogoutType", logout);
            prams.Add("@PageType", pagetype);
            prams.Add("@UserId", userId);
            string spName = ConfigurationManager.AppSettings["InsertLoginRecord"];
            dt = _dbA.GetDataTable(spName, prams);
            return dt;
        }
        #endregion

        public DataTable UpdateLogoutRecord(int contactId, int centreId, string sessionid, Utility.LogoutCode logout, int userId)
        {
            DataTable dt = new DataTable();
            var prams = new Dictionary<string, object>();
            prams.Add("@CentreId", centreId);
            prams.Add("@ContactId", contactId);
            prams.Add("@SessionId", sessionid);
            prams.Add("@LogoutType", (int)logout);
            prams.Add("@UserId", userId);

            string spName = ConfigurationManager.AppSettings["InsertLoginRecord"];
            dt = _dbA.GetDataTable(spName, prams);
            return dt;
        }

        #region Logout - Inserting Logout record in to tbl_LoginHistory and updating tbl_Login
        /// <summary>
        /// Inserting Login record in to tbl_Login
        /// </summary>
        //public DataTable InsertLogoutRecord(string nID, string tcid, string sessionid, string logout = "1", int pagetype = 1)
        public DataTable InsertLogoutRecord(int contactId, int tcid, string sessionid, int userId)
        {
            DataTable dt = new DataTable();
            dt = UpdateLogoutRecord(contactId, tcid, sessionid, Utility.LogoutCode.Normal, userId);
            return dt;
        }
        #endregion

        #region Logout - Inserting Logout record in to tbl_LoginHistory and updating tbl_Login
        /// <summary>
        /// Inserting Login record in to tbl_Login
        /// </summary>
        //public DataTable InsertForceLogoutRecord(string nID, string tcid, string sessionid, string logout = "3", int pagetype = 0)
        public DataTable InsertForceLogoutRecord(int contactId, int tcid, string sessionid, int userId)
        {
            DataTable dt = new DataTable();
            dt = UpdateLogoutRecord(contactId, tcid, sessionid, Utility.LogoutCode.ForceLogout, userId);
            return dt;
        }
        #endregion


        #region Logout - Inserting Logout record in to tbl_LoginHistory and updating tbl_Login
        /// <summary>
        /// Inserting NotNormalLogin record in to tbl_Login
        /// </summary>
        public DataTable InsertNotNormalLogout(int contactId, int tcid, string sessionid, int userId)
        {
            DataTable dt = new DataTable();
            dt = UpdateLogoutRecord(contactId, tcid, sessionid, Utility.LogoutCode.NotNormal, userId);
            return dt;
        }
        #endregion

        #region Logout - Inserting Logout record in to tbl_LoginHistory and updating tbl_Login
        /// <summary>
        /// Inserting Login record in to tbl_Login
        /// </summary>
        //public DataTable InsertSessionLogoutRecord(string nID, string tcid, string sessionid, string logout = "2", int pagetype = 0)
        public DataTable InsertSessionLogoutRecord(int contactId, int tcid, string sessionid, int userId)
        {
            DataTable dt = new DataTable();
            dt = UpdateLogoutRecord(contactId, tcid, sessionid, Utility.LogoutCode.NotNormal, userId);
            return dt;
        }
        #endregion

        /// <summary>
        /// Checking whether the user is login first time  
        /// </summary>
        /// <param name="contactId"></param>
        /// <returns></returns>
        public DataTable CheckLoginDate(int contactId, int userId)
        {
            DataTable dt = new DataTable();
            var prams = new Dictionary<string, object>();
            prams.Add("@UserId", userId);
            prams.Add("@ContactId", contactId);

            string spName = ConfigurationManager.AppSettings["FirstLogin"];
            dt = _dbA.GetDataTable(spName, prams);
            return dt;
        }

        /// <summary>
        /// Checking whether the user is login after 45 days
        /// </summary>
        /// <param name="ContactID"></param>
        /// <returns></returns>
        public DataTable CheckLastLoginDate(string uName)
        {
            DataTable dt = new DataTable();
            string parms = "UserName";
            string parmValues = uName;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["LastLoginCheck"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return dt;
        }
        #region File Related
        public void Createfolder(string path)
        {
            string target = HttpContext.Current.Server.MapPath(path);
            CreateFolder(target);
        }
        public string GetPath(string path)
        {
            string target = HttpContext.Current.Server.MapPath(path);
            if (!System.IO.Directory.Exists(target))
            {
                System.IO.Directory.CreateDirectory(target);
            }
            return target;
        }
        private static void CreateFolder(string path)
        {
            if (!System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
        }
        public string UploadFilePath(HttpPostedFileBase upload, string filename, string folderPath, string tcid)
        {
            string target = HttpContext.Current.Server.MapPath(folderPath);
            //create folder uploads
            CreateFolder(target);
            //string strYR = DateTime.Now.Year.ToString();
            int lastSlash = target.LastIndexOf('/');
            target = (lastSlash > -1) ? target.Substring(0, lastSlash) : target;
            string userFolder = target + Path.DirectorySeparatorChar + tcid;
            CreateFolder(userFolder);
            //string RenameFile = uploadID + "_" + CustId + "_" + upload.FileName;
            var theFilePath = Path.Combine(userFolder, filename);
            upload.SaveAs(theFilePath);

            return theFilePath;
        }
        public IList<DropDownDDL> RemoteSeverValidationDuplicateCheck(string controlValue, string controlType)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@ControlValue", controlValue);
            parms.Add("@ControlType", controlType);
            var spName = ConfigurationManager.AppSettings["RemoteServerDuplicationCheck"];
            dt = _dbA.GetDataTable(spName, parms);
            var resultData = DataTableToList(dt);
            if (resultData.Count > 0)
            {
                resultData.RemoveAt(0);
            }
            return resultData;
        }

        public DataTable LoadDefaultTrainingPartner(string partnerId)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@PartnerID", partnerId);
            var spName = ConfigurationManager.AppSettings["LoadOnStartTrainingPartner"];
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }
        #endregion

        #region Address
        public List<DropDownDDL> AllDdlDataTableToList(DataTable table)
        {
            var list = new List<DropDownDDL>(table.Rows.Count);
            var ddl = new DropDownDDL()
            {
                nIndex = -1,
                tDisplayName = "Select"
            };
            list.Add(ddl);
            for (int i = 0; i < table.Rows.Count; i++)
            {
                ddl = new DropDownDDL();
                ddl.nIndex = Convert.ToInt32(table.Rows[i][2]);
                ddl.tDisplayName = table.Rows[i][1].ToString();
                ddl.ValidationCode = table.Columns.Contains("ValidationCode") ? $"{table.Rows[i]["ValidationCode"]}" : ""; // , 
                ddl.ValidationMessage = table.Columns.Contains("ValidationMessage") ? $"{table.Rows[i]["ValidationMessage"]}" : ""; // , 
                list.Add(ddl);
            }
            return list;
        }
        public IList<DropDownDDL> GetDistrictDetails(string PINCode, string Locality, string PostOffice, string Village, string Subdistrict, string State)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID" + "$" + "Subdistrictid" + "$" + "Stateid";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village + "$" + Subdistrict + "$" + State;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressDistrictDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetStatetDetails(string PINCode, string Locality, string PostOffice, string Village, string Subdistrict)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID" + "$" + "Subdistrictid";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village + "$" + Subdistrict;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressStateDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetSubDistrictDetails(string PINCode, string Locality, string PostOffice, string Village)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressSubDistrictDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }


        public IList<DropDownDDL> GetModifySubDistrictDetails(string PINCode, string Locality, string PostOffice, string Village)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressSubDistrictViewAndModifyDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }


        public IList<DropDownDDL> GetCityVillageTownDetails(string PINCode, string Locality, string PostOffice)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressCityVillageTownDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetModifyCityVillageTownDetails(string PINCode, string Locality, string PostOffice)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID";
            string ParmValues = PINCode + "$" + Locality + "$" + PostOffice;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressCityVillageTownViewAndModifyDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }


        public IList<DropDownDDL> GetPostOfficeDetails(string PINCode, string Locality)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID";
            string ParmValues = PINCode + "$" + Locality;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressPostOfficeDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetModifyPostOfficeDetails(string PINCode, string Locality,string CityId)
        {
            DataTable dt = new DataTable();
            string Parms = "PINCode" + "$" + "LocalityID" + "$" + "CityId";
            string ParmValues = PINCode + "$" + Locality + "$" + CityId;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["AddressPostOfficeViewAndModifyDDL"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetGuardianTypeList(string gender)
        {
            DataTable dt = new DataTable();
            string parms = "Gender";
            string parmValues = gender;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["GuardianTypeDDL"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return (AllDdlDataTableToList(dt));
        }

        public IList<DropDownDDL> GetState()
        {
            DataTable dt = new DataTable();
            string parms = string.Empty;
            string parmValues = string.Empty;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["StateDDL"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return (DataTableToList(dt, true));
        }

        public IList<DropDownDDL> GetDistrict(string stateId)
        {
            DataTable dt = new DataTable();
            string parms = "StateId";
            string parmValues = stateId;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["DistrictDDL"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return (DataTableToList(dt, true));
        }

        public IList<DropDownDDL> GetConstituency(string stateId)
        {
            DataTable dt = new DataTable();
            string parms = "StateId";
            string parmValues = stateId;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["ConstituencyDDL"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return (DataTableToList(dt, true));
        }

        public TrainingLocations GetAddressDetails(string pinCode, TrainingLocations viewModel)
        {
            DataTable dt = new DataTable();
            string parms = "PINCode";
            string parmValues = pinCode;
            string spName = string.Empty;
            string filter = string.Empty;
            spName = ConfigurationManager.AppSettings["AddressDDL"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);

            DataView dv = dt.DefaultView;
            filter = ConfigurationManager.AppSettings["PostalOfficeFilter"];
            dv.RowFilter = filter; //"Property='PostalOffice'";
            viewModel.PostOfficeList = AllDdlDataTableToList(dv.ToTable());

            filter = ConfigurationManager.AppSettings["LocalityFilter"];
            dv.RowFilter = filter; //"Property='Locality'";
            viewModel.LocalityList = AllDdlDataTableToList(dv.ToTable());

            filter = ConfigurationManager.AppSettings["StateFilter"];
            dv.RowFilter = filter; //"Property='State'";
            viewModel.TraineeStateList = AllDdlDataTableToList(dv.ToTable());

            filter = ConfigurationManager.AppSettings["DistrictFilter"];
            dv.RowFilter = filter; //"Property='District'";
            viewModel.TraineeDistrictList = AllDdlDataTableToList(dv.ToTable());

            filter = ConfigurationManager.AppSettings["SubDistrictFilter"];
            dv.RowFilter = filter; //"Property='SubDistrict'";
            viewModel.TraineeSubDistrictList = AllDdlDataTableToList(dv.ToTable());

            filter = ConfigurationManager.AppSettings["TownVillageFilter"];
            dv.RowFilter = filter; //"Property='TownVillage'";
            viewModel.TraineeVillageTownCityList = AllDdlDataTableToList(dv.ToTable());

            return viewModel;
        }
        #endregion

        #region Certificate 
        public List<CustomTemplateType> GetCertificateTemplateTypeLookup()
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("@TrainingType", SessionMgr.LoginUserDetails.TrainingType);
            string spName = ConfigurationManager.AppSettings["PMU_GetCustomLogoTemplateType"];
            DataTable dt = _dbA.GetDataTable(spName, dict);

            List<CustomTemplateType> objList = new List<CustomTemplateType>();
            objList.Add(new CustomTemplateType() { Id = -1, CustomType = "Select" });

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    CustomTemplateType obj = new CustomTemplateType()
                    {
                        CorporateLogoCount = Convert.ToInt32(row["CorporateLogoCount"].ToString()),
                        CustomType = $"{row["LogoType"]}",
                        GovtLogoCount = Convert.ToInt32(row["GovtLogoCount"].ToString()),
                        Position = $"{row["Position"]}",
                        Id = Convert.ToInt32(row["id"]),
                    };
                    objList.Add(obj);
                }
            }
            return objList;
        }

        public DataTable GetAllLogosByType (string searchByLogoType,string SearchByfileName=null)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@TrainingType", SessionMgr.LoginUserDetails.TrainingType);
            parms.Add("@SearchByfileName", SearchByfileName);
            parms.Add("@searchByLogoType", searchByLogoType);
            string SPName = ConfigurationManager.AppSettings["PMU_GetLogosByType"].ToString();
            dt = _dbA.GetDataTable(SPName, parms);
            return dt;
        }

        #endregion
    }
}
