﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI.WebControls;
using PMU.Models;

namespace PMU.Repository
{
    public class DataAccess
    {
        SqlConnection _conn;//No more using 
        SqlCommand _cmd;

        string _outErr = string.Empty;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public SqlConnection GetDbConnection()
        {
            _conn = new SqlConnection();
            string conString = ConfigurationManager.ConnectionStrings["SmartCentreDBConnection"].ConnectionString;
            _conn.ConnectionString = conString;
            try
            {
                //conn.Open();
                return _conn;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// to connect to validationDB added by Nisha-14Nov16
        /// </summary>
        /// <returns></returns>
        public SqlConnection GetValDBConnection()
        {
            SqlConnection con = new SqlConnection();
            string ValconString = ConfigurationManager.ConnectionStrings["ValidationDBConnection"].ConnectionString;
            con.ConnectionString = ValconString;
            try
            {
                //conn.Open();
                return con;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public string GetXlConnectionString(string filePath)
        {
            string conStr = "";

            string strExtn = Path.GetExtension(filePath);//get file extension
            switch (strExtn)
            {
                case ".xls": //Excel 97-03               
                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                    break;
                case ".xlsx": //Excel 07
                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                    break;
                case ".csv":
                    conStr = ConfigurationManager.ConnectionStrings["ExcelCSVConString"].ConnectionString;
                    break;
            }
            conStr = String.Format(conStr, filePath, "Yes");

            return conStr;
        }

        //If any Error...Remove relateed data from Dumping Table
        public void RmvDataFrmDumpTbl(int uploadId, int custId, string spName)
        {
            try
            {
                _conn = GetDbConnection();
                using (_cmd = _conn.CreateCommand())
                {
                    _cmd.CommandText = spName;
                    _cmd.CommandType = CommandType.StoredProcedure;
                    _cmd.CommandTimeout = 600;
                    _cmd.Parameters.AddWithValue("@nCustId", custId);
                    _cmd.Parameters.AddWithValue("@nUploadId", uploadId);
                    _conn.Open();
                    _cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                _conn.Close();
            }
        }

        //Get Datatable based on uploadfileid,CustId
        public DataTable GetUploadDataTable(string sprocNm, int uploadId, int custId)
        {
            DataTable dt = new DataTable();
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand()) //new SqlCommand(sprocNm, conn);
                {
                    cmd.CommandText = sprocNm;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 600;
                    cmd.Parameters.AddWithValue("@nCustId", custId);
                    cmd.Parameters.AddWithValue("@nUploadId", uploadId);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (SqlException)
            {
                throw;
            }

            return dt;
        }

        //Get Table by passing SP Name and Cust id
        public DataTable GetDataTable(string spName, int custid)
        {
            DataTable dt = new DataTable();

            try
            {
                _conn = GetDbConnection();
                using (SqlCommand cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 600;
                    cmd.Parameters.AddWithValue("@nCustId", custid);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }

        //Get Table by passing SP Name and Cust id
        public DataTable GetDataTable(string spName)
        {
            DataTable dt = new DataTable();
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 600;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return dt;
        }

        //Get Table by passing SP Name and String from ValidationDB
        public DataTable GetValidationDataTable(string spName, string Parms, string parmValues)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = GetValDBConnection();
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    if (!string.IsNullOrEmpty(Parms) && !string.IsNullOrEmpty(parmValues))
                    {
                        if (Parms.Contains("$"))
                        {
                            string[] parms = Parms.Split('$');
                            string[] parmvalues = parmValues.Split('$');
                            string parameter;
                            string parametervalue;
                            for (int i = 0; i < parms.Length; i++)
                            {
                                parameter = parms[i];
                                //for (int j = 0; j < parmvalues.Length; j++)
                                //{
                                //    parametervalue = parmvalues[i];
                                //    cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                //    break;
                                //}
                                for (int j = 0; j < parmvalues.Length; j++)
                                {
                                    parametervalue = parmvalues[i];
                                    if (!string.IsNullOrEmpty(parametervalue))
                                        cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                    else
                                        cmd.Parameters.AddWithValue(parameter, DBNull.Value);
                                    break;
                                }
                            }
                        }
                        else
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 1000;
                            cmd.Parameters.AddWithValue(Parms, parmValues.Trim());
                            // cmd.ExecuteNonQuery();
                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }

        //Get Table by passing SP Name and String
        public DataTable GetDataTable(string spName, string Parms, string parmValues)
        {
            DataTable dt = new DataTable();

            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    if (!string.IsNullOrEmpty(Parms) && !string.IsNullOrEmpty(parmValues))
                    {
                        if (Parms.Contains("$"))
                        {

                            string[] parms = Parms.Split('$');
                            string[] parmvalues = parmValues.Split('$');
                            string parameter;
                            string parametervalue;
                            for (int i = 0; i < parms.Length; i++)
                            {
                                parameter = parms[i];
                                //for (int j = 0; j < parmvalues.Length; j++)
                                //{
                                //    parametervalue = parmvalues[i];
                                //    cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                //    break;
                                //}
                                for (int j = 0; j < parmvalues.Length; j++)
                                {
                                    parametervalue = parmvalues[i];
                                    if (!string.IsNullOrEmpty(parametervalue))
                                        cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                    else
                                        cmd.Parameters.AddWithValue(parameter, DBNull.Value);
                                    break;
                                }
                            }
                        }
                        else
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 1000;
                            cmd.Parameters.AddWithValue(Parms, parmValues.Trim());
                            // cmd.ExecuteNonQuery();
                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }
        public DataTable GetDataTable(string spName, Dictionary<string, object> parms)
        {
            DataTable dt = new DataTable();

            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;

                    foreach (var o in parms)
                    {
                        if (o.Value != null)
                        {
                            cmd.Parameters.AddWithValue(o.Key, o.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(o.Key, DBNull.Value);
                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return dt;
        }

        public DataSet GetDataSet(string spName, Dictionary<string, object> parms)
        {
            DataSet ds = new DataSet();
          //  DataTable dt = new DataTable();

            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;

                    foreach (var o in parms)
                    {
                        if (o.Value != null)
                        {
                            cmd.Parameters.AddWithValue(o.Key, o.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(o.Key, DBNull.Value);
                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return ds;
        }
        public int InserEnrolledCandidates(string spName, string Parms, string parmValues)
        {
            int a = 0;
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    if (Parms != "0" && parmValues != "0")
                    {
                        if (Parms.Contains("$"))
                        {

                            string[] parms = Parms.Split('$');
                            string[] parmvalues = parmValues.Split('$');
                            string parameter;
                            string parametervalue;
                            for (int i = 0; i < parms.Length; i++)
                            {
                                parameter = parms[i];
                                for (int j = 0; j < parmvalues.Length; j++)
                                {
                                    parametervalue = parmvalues[i];
                                    if (!string.IsNullOrEmpty(parametervalue))
                                        cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                    else
                                        cmd.Parameters.AddWithValue(parameter, DBNull.Value);
                                    break;
                                }
                            }
                            _conn.Open();
                            a = (int)cmd.ExecuteNonQuery();
                        }
                        else
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 1000;
                            cmd.Parameters.AddWithValue(Parms, parmValues.Trim());
                            _conn.Open();
                            a = (int)cmd.ExecuteNonQuery();
                        }
                        return a;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
                a = -1;
            }
            finally
            {
                if (_conn.State == ConnectionState.Open)
                    _conn.Close();
            }
            return a;
        }
        public int ExecuteNonQuery(string spName, Dictionary<string, object> parms)
        {
            int a = 0;
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    foreach (var o in parms)
                    {
                        if (o.Value != null)
                        {
                            cmd.Parameters.AddWithValue(o.Key, o.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(o.Key, DBNull.Value);
                        }
                    }

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000;

                    _conn.Open();
                    a = (int)cmd.ExecuteNonQuery();
                    //return a;
                }
            }
            catch (Exception ex)
            {
                a = -1; throw ex;
            }
            finally
            {
                if (_conn.State == ConnectionState.Open)
                    _conn.Close();
            }
            return a;
        }


        public int ExecuteScalar(string spName, Dictionary<string, object> parms)
        {
            int a = 0;
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    foreach (var o in parms)
                    {
                        if (o.Value != null)
                        {
                            cmd.Parameters.AddWithValue(o.Key, o.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(o.Key, DBNull.Value);
                        }
                    }

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000;

                    _conn.Open();
                    return a = (int)cmd.ExecuteScalar();
                }

            }
            catch (Exception)
            {
                a = -1;
                throw;
            }
            finally
            {
                if (_conn.State == ConnectionState.Open)
                    _conn.Close();
            }
        }
        public int ExecuteNonQuery(string spName, Dictionary<string, object> parms, string outParm, out string outputValue)
        {
            int a = 0;
            string outputResultValue = "";
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    foreach (var o in parms)
                    {
                        if (o.Value != null)
                        {
                            cmd.Parameters.AddWithValue(o.Key, o.Value);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(o.Key, DBNull.Value);
                        }
                    }

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000;

                    var outputIdParam = new SqlParameter(outParm, SqlDbType.NVarChar)
                    {
                        Direction = ParameterDirection.Output,
                        Size = 150
                    };

                    cmd.Parameters.Add(outputIdParam);

                    _conn.Open();
                    a = (int)cmd.ExecuteNonQuery();

                    outputResultValue = $"{outputIdParam.Value}";
                    //return a;
                }
            }
            catch (Exception)
            {
                a = -1;
                throw;
            }
            finally
            {
                if (_conn.State == ConnectionState.Open)
                    _conn.Close();
            }

            outputValue = outputResultValue;
            return a;
        }

        public DataTable SaveAttachemnt(string spName, string Parms, string parmValues)
        {
            DataTable dt = new DataTable();
            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    if (!string.IsNullOrEmpty(Parms) && !string.IsNullOrEmpty(parmValues))
                    {
                        if (Parms.Contains("$"))
                        {
                            string[] parms = Parms.Split('$');
                            string[] parmvalues = parmValues.Split('$');
                            string parameter;
                            string parametervalue;
                            for (int i = 0; i < parms.Length; i++)
                            {
                                parameter = parms[i];
                                for (int j = 0; j < parmvalues.Length; j++)
                                {
                                    parametervalue = parmvalues[i];
                                    if (!string.IsNullOrEmpty(parametervalue) && parametervalue != "-1")
                                        cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                    else
                                        cmd.Parameters.AddWithValue(parameter, DBNull.Value);
                                    break;
                                }
                            }
                        }
                        else
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 1000;
                            cmd.Parameters.AddWithValue(Parms, parmValues.Trim());
                            // cmd.ExecuteNonQuery();
                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
        public int CreateAttachment(string cadidateId, DataTable dtAttachment, int fileType, string fileName, string comment)
        {
            try
            {
                string spName = ConfigurationManager.AppSettings["UploadImage"];
                //int result = 0;
                string status = string.Empty;
                Byte[] blob = null;
                blob = (byte[])dtAttachment.Rows[0][1];
                int nsize;
                nsize = blob.GetUpperBound(0);
                fileName = fileName.Contains("'") ? fileName.Replace("'", "''") : fileName;
                comment = comment.Contains("'") ? comment.Replace("'", "''") : comment;


                //Calling the stored procedure to upload documents
                SqlConnection conn = GetDbConnection();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    //cmd.Parameters.AddWithValue("@nFlag", flag);
                    cmd.Parameters.AddWithValue("@FileType", fileType);
                    cmd.Parameters.AddWithValue("@CadidateID", cadidateId);
                    cmd.Parameters.AddWithValue("@tFileName", fileName.Trim());
                    SqlParameter param = null;
                    param = new SqlParameter("@FileData", SqlDbType.VarBinary, blob.Length,
                        ParameterDirection.Input, false, 0, 0, null, DataRowVersion.Current, blob);
                    cmd.Parameters.Add(param);
                    cmd.Parameters.AddWithValue("@Comment", comment);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    return 1;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _conn.Close();
            }
        }


        /// <summary>
        ///   Get DataSet by passing SP Name and String
        /// </summary>
        /// <param name="spName"></param>
        /// <param name="Parms"></param>
        /// <param name="parmValues"></param>
        /// <returns></returns>
        public DataSet GetDataSet(string spName, string Parms, string parmValues)
        {
            DataSet ds = new DataSet();

            try
            {
                _conn = GetDbConnection();
                using (var cmd = _conn.CreateCommand())
                {
                    cmd.CommandText = spName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 10000;
                    if (!string.IsNullOrEmpty(Parms) && !string.IsNullOrEmpty(parmValues))
                    {
                        if (Parms.Contains("$"))
                        {

                            string[] parms = Parms.Split('$');
                            string[] parmvalues = parmValues.Split('$');
                            string parameter; string parametervalue;
                            for (int i = 0; i < parms.Length; i++)
                            {
                                parameter = parms[i];
                                for (int j = 0; j < parmvalues.Length; j++)
                                {
                                    parametervalue = parmvalues[i];
                                    cmd.Parameters.AddWithValue(parameter, parametervalue.Trim());
                                    break;
                                }
                            }

                        }
                        else
                        {

                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandTimeout = 1000;
                            cmd.Parameters.AddWithValue(Parms, parmValues.Trim());
                            // cmd.ExecuteNonQuery();

                        }
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }

            }
            catch (Exception)
            {
                throw;
            }
            return ds;
        }


        #region File Related
        public void Createfolder(string path)
        {
            string target = HttpContext.Current.Server.MapPath(path);
            CreateFolder(target);
        }
        private static void CreateFolder(string path)
        {
            if (!System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
        }
        public string UserFilePath(string target)
        {
            string monthname = DateTime.Now.ToString("MMMyyyy");
            //string strYR = DateTime.Now.Year.ToString();
            string userFolder = target + monthname;
            return userFolder;
        }
        public string UploadFilePath(FileUpload upload, string filename, string folderPath)
        {
            string theFilePath = string.Empty;
            string target = HttpContext.Current.Server.MapPath(folderPath);
            //create folder uploads
            CreateFolder(target);
            //create user folder
            string monthname = DateTime.Now.ToString("MMMyyyy");
            //string strYR = DateTime.Now.Year.ToString();
            string userFolder = target + monthname;
            CreateFolder(userFolder);
            //string RenameFile = uploadID + "_" + CustId + "_" + upload.FileName;
            theFilePath = Path.Combine(userFolder, filename);
            upload.SaveAs(theFilePath);

            return theFilePath;
        }

        #endregion
    }
}
