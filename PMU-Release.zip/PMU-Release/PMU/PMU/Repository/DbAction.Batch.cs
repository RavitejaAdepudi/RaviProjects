﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using PMU.Models;
using PMU.Model;

namespace PMU
{
    public partial class DbAction
    {

        public List<DropDownDDL> GetJobRoles(int projectId, string centreId, bool isLocation)
        {
            DataTable dt = new DataTable();
            string spName = ConfigurationManager.AppSettings["RPL_SC_GetJobRoles"];
            var parms = new Dictionary<string, object>();
            parms.Add("@ProjectID", projectId);
            parms.Add("@CentreID", centreId);
            parms.Add("@IsCentre", !isLocation);
            dt = _dbA.GetDataTable(spName, parms);

            return DataTableToList(dt);
        }


        public DataTable GetEditBatch(string centreId, string batchName)
        {
            var dt = new DataTable();
            string spName = ConfigurationManager.AppSettings["GetEditBatch"];
            var parms = new Dictionary<string, object>();
            parms.Add("@CentreId", centreId);
            parms.Add("@BatchName", batchName);
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }



   
      

        public ManageBatchViewModel GetBatchesForJobRole(int centreId, int projectId, int jobRoleId, int sectorId, int subSectorId)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@CentreID", centreId);
            parms.Add("@ProjectID", projectId);
            parms.Add("@SectorId", sectorId);
            parms.Add("@SubSectorId", subSectorId);
            parms.Add("@JobRoleId", jobRoleId);
            var spName = Convert.ToString(ConfigurationManager.AppSettings["RPL_GetJobRoleDuration"]);
            var dt = _dbA.GetDataTable(spName, parms);
            var objjobrole = new ManageBatchViewModel();
            foreach (DataRow dr in dt.Rows)
            {
                objjobrole.JobRoleCode = dr["JobRoleCode"] as string;
                objjobrole.JobRoleDurationInHrs = (int)dr["JobRoleDuration"];
                objjobrole.MinBatchsize = (int)dr["MinBatchsize"];
                objjobrole.maxbatchsize = (int)dr["maxbatchsize"];

                objjobrole.Target = (int)dr["Target"];
                objjobrole.Target_Accomplished = (int)dr["Target_Accomplished"];
                objjobrole.Balance = (int)dr["Balance"];
            }

            List<ManageBatch> objlist = new List<ManageBatch>();
            var spNameBatchData = Convert.ToString(ConfigurationManager.AppSettings["RPL_GetBatchData"]);
            var batchData = _dbA.GetDataTable(spNameBatchData, parms);
            for (var i = 0; i < batchData.Rows.Count; i++)
            {
                var item = new ManageBatch();
                item.BatchName = $"{batchData.Rows[i]["BatchName"]}";
                item.BatchStartDate = Convert.ToDateTime(batchData.Rows[i][1]).ToString("dd-MMM-yyyy") != null
                    ? Convert.ToDateTime(batchData.Rows[i][1]).ToString("dd-MMM-yyyy")
                    : "";
                item.BatchEndDate = Convert.ToDateTime(batchData.Rows[i][2]).ToString("dd-MMM-yyyy") != null
                    ? Convert.ToDateTime(batchData.Rows[i][2]).ToString("dd-MMM-yyyy")
                    : "";
                item.PreferedAssessmentDate = Convert.ToDateTime(batchData.Rows[i][3]).ToString("dd-MMM-yyyy") != null
                    ? Convert.ToDateTime(batchData.Rows[i][3]).ToString("dd-MMM-yyyy")
                    : "";
                item.EnrolmentClosureDate = Convert.ToDateTime(batchData.Rows[i][4]).ToString("dd-MMM-yyyy") != null
                    ? Convert.ToDateTime(batchData.Rows[i][4]).ToString("dd-MMM-yyyy")
                    : "";
                item.TotalCandidatesinBatch = !string.IsNullOrEmpty(Convert.ToString(batchData.Rows[i][5]))
                    ? Convert.ToInt32(batchData.Rows[i][5])
                    : 0;
                item.TrainerName = !string.IsNullOrEmpty(Convert.ToString(batchData.Rows[i][6]))
                    ? Convert.ToString(batchData.Rows[i][6])
                    : "";
                item.Remaining = !string.IsNullOrEmpty(Convert.ToString(batchData.Rows[i][7]))
                    ? Convert.ToInt32(batchData.Rows[i][7])
                    : 0;
                item.BatchApprovalStatus = !string.IsNullOrEmpty(Convert.ToString(batchData.Rows[i][8]))
                    ? Convert.ToString(batchData.Rows[i][8])
                    : "";
                item.RemarksforSSC = !string.IsNullOrEmpty(Convert.ToString(batchData.Rows[i][9]))
                    ? Convert.ToString(batchData.Rows[i][9])
                    : "";
                objlist.Add(item);
            }
            objjobrole.ManageBatchList = objlist;
            return objjobrole;
        }
     
        public string SendBatchToSscApproval(string batchName, int centreId, bool isLocation)
        {
            string spName = ConfigurationManager.AppSettings["RPL_Send_Batch_To_SSC"];
            var parms = new Dictionary<string, object>();
            parms.Add("@CentreId", centreId);
            parms.Add("@BatchName", batchName);

            var number = _dbA.ExecuteNonQuery(spName, parms);
            var result = "";
            var messageSuccess = ConfigurationManager.AppSettings["PMU_SendToSSC_SuccessMessage"];
            var messageFailure = ConfigurationManager.AppSettings["PMU_SendToSSC_FailureMessage"];
            if (number > 0)
            {
                result = $"Success-{messageSuccess} : {batchName}";
            }
            else
            {
                result = $"Failure-{messageFailure}";
            }
            return result;
        }

        public DataTable Get_BatchStatusApproved()
        {
            DataTable dt = new DataTable();
            //string Parms = "";
            //string ParmValues = "";
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["OpenBatchStatus"].ToString();
            //dt = _dbA.GetValidationDataTable(SPName, Parms, ParmValues);
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }

        public DataTable GetViewApprovedBatchList(string ApprovedStatus, string contactid, string tcid)
        {
            DataTable dt = new DataTable();
            string Parms = "status" + "$" + "contactId " + "$" + "centreId ";
            string ParmValues = ApprovedStatus + "$" + contactid + "$" + tcid;
            //string Parms = "status";
            //string ParmValues = ApprovedStatus;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["BatchApproved"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
            return dt;
        }
        public DataTable GetFilterBatchList(string ceremStatus, string piaName,string batchName,DateTime? fromDt,DateTime? toDt, int start, int pageSize, string OrderBy, string Sort) //, int start, int pageSize, string OrderBy, string Sort
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@StartDate", fromDt);
            parm.Add("@EndDate", toDt);
            parm.Add("@CeremonyStatus", ceremStatus);
            parm.Add("@PIAName", piaName);
            parm.Add("@Batchname", batchName);
            parm.Add("@Start", start);
            parm.Add("@PageSize", pageSize);
            parm.Add("@OrderBy", OrderBy);
            parm.Add("@Sort", Sort);
            string spName = string.Empty;
            DataTable dt = new DataTable();

            spName = ConfigurationManager.AppSettings["BatchListByFilter"].ToString();

            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }

        public DataTable UpdateBatchAssetsDetails(string batchid,string imgName,string description)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchId ", batchid);
            parm.Add("@ImageName", imgName);
            parm.Add("@Description", description);

            string spName = string.Empty;
            DataTable dt = new DataTable();
            spName = ConfigurationManager.AppSettings["BatchAssetInsert"];
            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }
        public DataTable UpdateBatchAssetsDescription( string batchid, string imgName, string description)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchId ", batchid);
            parm.Add("@ImageName", imgName);
            parm.Add("@Description", description);

            string spName = string.Empty;
            DataTable dt = new DataTable();
            spName = ConfigurationManager.AppSettings["BatchAssetDescription"];
            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }

        public DataTable Get_ApprovedBatchJobRole()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["JobRoles"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }
        public DataTable GetBatchAssetsDescription(CandidateEnrollmentViewModel viewModel, string batchid, string imgName)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchId ", batchid);
            parm.Add("@ImageName", imgName);
           // parm.Add("@Description", description);

            string spName = string.Empty;
            DataTable dt = new DataTable();
            spName = ConfigurationManager.AppSettings["GetDescription"];
            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }
        public DataTable ApproveDenyBatchAssetsDescription(CandidateEnrollmentViewModel viewModel, string userid, string batchid, string imgName, int verified)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchId ", batchid);
            parm.Add("@ImageName", imgName);
            parm.Add("@VerifiedBy", userid);
            parm.Add("@VerificationStatus", verified);
            string spName = string.Empty;
            DataTable dt = new DataTable();
            spName = ConfigurationManager.AppSettings["ApproveBatchAsset"];
            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }

        public DataSet GetCeremonyStatusList(string batchId)
        {
            DataSet dt = new DataSet();
            string parms = "BatchName";
            string parmValues = batchId;
            var spName = ConfigurationManager.AppSettings["GetBatchDetailsforCeremony"];
            dt = _dbA.GetDataSet(spName, parms, parmValues);
            return dt;
        }

        public int UpdateCeremonyStatus(int batchID, int Status, string CerStatusDescrip, string rejVal, string rejDesc)
        {
            var parm = new Dictionary<string, object>();
            int RecordsAffected;
            parm.Add("@BatchId", batchID);
            parm.Add("@CeremonyStatus", Status);
            parm.Add("@CeremonyDescription", CerStatusDescrip);
            parm.Add("@RejectionReason", rejVal);
            parm.Add("@RejectionDescription", rejDesc);

            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["UpdateCeremonyStatus"];
            RecordsAffected = _dbA.ExecuteNonQuery(spName, parm);
            return RecordsAffected;
        }
        public DataTable PhotoVerificationStatusList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["PhotoVerificationStatusList"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }
        public DataTable CeremonyStatusList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["CeremonyStatusList"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }
        public DataTable TrainingPartnerList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["TrainingPartnerList"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }

        public DataTable GetBatchListByPartner(int partner)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@TrainingPartner ", partner);
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["BatchListByTrainingPartner"].ToString();
            dt = _dbA.GetDataTable(SPName, parm);
            return dt;
        }

        public DataTable GetBatchByBatchID(int batchID)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchId ", batchID);
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["GetBatchAssetByBatch"].ToString();
            dt = _dbA.GetDataTable(SPName, parm);
            return dt;
        }
    }
}
