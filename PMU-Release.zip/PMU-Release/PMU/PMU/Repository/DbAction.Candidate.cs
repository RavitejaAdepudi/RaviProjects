﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMU.Models;

namespace PMU
{
    public partial class DbAction
    {
        
        public DataTable AvailableTarget(string batchName)
        {
            DataTable dt = new DataTable();
            string parms = "batchName ";
            string parmValues = batchName;
            var spName = ConfigurationManager.AppSettings["TargetAvailable"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            return dt;
        }

        public DataSet GetEnrollCandiadateList(string batchId, string centreId)
        {
            DataSet ds = new DataSet();
            string parms = "BatchName" + "$" + "CentreId";
            string parmValues = batchId + "$" + centreId;
            var spName = ConfigurationManager.AppSettings["GetBatchDetails"];
            ds = _dbA.GetDataSet(spName, parms, parmValues);

            return ds;
        }

        public DataTable GetGuestOfHonourDDL()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["GuestOfHonourDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }

        public DataTable GetReasonForRejectionDDL()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["ReasonForRejectionDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return dt;
        }

        public void AddEnroledCandidate(string candidateId, string batchId, string centreId)
        {
            string parms = "BatchName" + "$" + "CandID" + "$" + "CentreId";
            string parmValues = batchId + "$" + candidateId + "$" + centreId;
            var spName = ConfigurationManager.AppSettings["CandEnrolledInsert"];
            _dbA.InserEnrolledCandidates(spName, parms, parmValues);
        }

        public void RemoveEnroledCandidate(string candidateId, string batchId, string centreId)
        {
            string parms = "BatchName" + "$" + "CandID" + "$" + "CentreId";
            string parmValues = batchId + "$" + candidateId + "$" + centreId;
            var spName = ConfigurationManager.AppSettings["EnroledCandidateRemove"];
            _dbA.InserEnrolledCandidates(spName, parms, parmValues);
        }

        //public DataTable CreateCandidateReg(CandidateRegistrationViewModel viewModel, int userId)
        //{
        //    int addressVerificationStatus = (viewModel.IsSelectorEnterAddress == true) ? 1 : 0;

        //    //@CentreID ,   @SchemeID ,   @TrainingType ,   @SectorID ,   @SubSectorID ,     @JobRoleID ,     @CandidateName ,   @Gender ,  
        //    //@YearofBirth ,    @DateofBirth ,    @TypeofDisability ,    @AadhaarNumber ,    @AadharVerificationStatusID , @AlternateIDType ,    
        //    // @AlternateIDNumber ,   @AlternativeIDVerificationStatusID ,     @EligibleforDisbursementID ,     @EducationAttained ,    @CasteCategory , 

        //    //  @Religion ,   @TraineeAddressLine1 ,  @Pincode ,   @AddressVerification ,  Locality ,   @CTV ,  @PostOffice , @SubDistrict ,  
        //    // @CityID ,  @State ,  @District ,@Constituency , MobileNo ,   @MobileOTP ,@MobileOTPVerificationStatusID , @MobileExistsinSystemStatusID ,  
        //    //@LandlineNumber , @EmailAddress , @IFSCCode , @BankAccountNumber , getdate(),  @NameasinBank ,0 , 1  @CentreCandId,@Employment ,  @EmploymentDetails


        //    if (viewModel.AadhaarVerificationStatus == "Successful" && string.IsNullOrEmpty(viewModel.Gender))
        //    {
        //        viewModel.Gender = viewModel.nGender;
        //    }
        //    if (viewModel.IsDOBorDOY && string.IsNullOrEmpty(viewModel.DateofBirth))
        //    {
        //        viewModel.DateofBirth = viewModel.tDateofBirth;
        //    }
        //    if (!viewModel.IsDOBorDOY && string.IsNullOrEmpty(viewModel.YearofBirth))
        //    {
        //        viewModel.YearofBirth = viewModel.tYearofBirth;
        //    }

        //    var parm = new Dictionary<string, object>();
        //    parm.Add("@CentreCandId ", viewModel.CentreCandidateID);
        //    parm.Add("@CentreID ", viewModel.CentreID);
        //    parm.Add("@SectorID", viewModel.Sector);
        //    parm.Add("@SubSectorID", viewModel.SubSector);
        //    parm.Add("@JobRoleID", viewModel.JobRole);
        //    parm.Add("@CandidateName ", viewModel.CandidateName);
        //    parm.Add("@Gender ", viewModel.Gender);
        //    parm.Add("@YearofBirth", viewModel.YearofBirth);
        //    parm.Add("@DateofBirth ", viewModel.DateofBirth);
        //    parm.Add("@TypeofDisability ", viewModel.DisabilityType);
        //    parm.Add("@AadhaarNumber ", viewModel.AadhaarNumber);
        //    parm.Add("@AadhaarVerificationStatus ", viewModel.AadhaarVerificationStatus);
        //    parm.Add("@AlternateIDType ", viewModel.AlternateID);
        //    parm.Add("@AlternateIDNumber ", viewModel.AlternateIDNumber);
        //    parm.Add("@AlternateIDVerificationStatus ", viewModel.AlternateIDVerificationStatus);
        //    parm.Add("@EducationAttained ", viewModel.EducationAttained);
        //    parm.Add("@CasteCategory", viewModel.CasteCategory);
        //    parm.Add("@Religion", viewModel.Religion);
        //    parm.Add("@TraineeAddressLine1 ", viewModel.TraineeAddressLine1);
        //    parm.Add("@Pincode ", viewModel.PINCode);
        //    parm.Add("@AddressVerification ", addressVerificationStatus);
        //    parm.Add("@Locality ", viewModel.LocalityOthers);
        //    parm.Add("@CTV ", viewModel.TraineeVillageTownCityOthers);
        //    parm.Add("@PostOffice ", viewModel.PostOfficeOthers);
        //    parm.Add("@SubDistrict ", viewModel.TraineeSubDistrictOthers);
        //    parm.Add("@LocalityID ", viewModel.Locality);
        //    parm.Add("@CTVID ", viewModel.TraineeVillageTownCity);
        //    parm.Add("@PostOfficeID ", viewModel.PostOffice);
        //    parm.Add("@SubDistrictID ", viewModel.TraineeSubDistrict);
        //    parm.Add("@State ", viewModel.TraineeState);
        //    parm.Add("@District", viewModel.TraineeDistrict);
        //    parm.Add("@Constituency", viewModel.Constituency);
        //    parm.Add("@MobileNo", viewModel.TraineeMobileNumber);
        //    parm.Add("@MobileOTP ", viewModel.EnterOTP);
        //    parm.Add("@MobileOTPVerificationStatus", viewModel.MobileOTPVerificationStatus);
        //    parm.Add("@MobileNumberExistsinsystem ", viewModel.MobileNumberExistsinSystem);
        //    parm.Add("@LandlineNumber ", viewModel.LandlineNumber);
        //    parm.Add("@EmailAddress", viewModel.TraineeEmailAddress);
        //    parm.Add("@IFSCCode ", viewModel.IFSCCode);
        //    parm.Add("@BankAccountNumber ", viewModel.BankAccountNumber);
        //    parm.Add("@NameasinBank", viewModel.NameasinBank);
        //    parm.Add("@Employment ", viewModel.Employment);
        //    parm.Add("@salutation", viewModel.Salutation);
        //    parm.Add("@EmploymentDetails", viewModel.EmploymentDescription);
        //    parm.Add("@UserID", userId);

        //    string spName = string.Empty;
        //    DataTable dt = new DataTable();
        //    spName = ConfigurationManager.AppSettings["CandidateRegnInsert"];
        //    //dbA.CreateCandidateReg(SPName, Parms, ParmValues);NameasinBank
        //    dt = _dbA.GetDataTable(spName, parm);



        //    return dt;
        //}


        //public void GetAllDdlList(CandidateRegistrationViewModel viewModel)
        //{
        //    DataTable dt = new DataTable();
        //    string spName = string.Empty;
        //    string filter = string.Empty;
        //    spName = ConfigurationManager.AppSettings["IndependentDDL"];
        //    dt = _dbA.GetDataTable(spName);

        //    if (dt.Rows.Count > 0)
        //    {
        //        DataView dv = dt.DefaultView;

        //        filter = ConfigurationManager.AppSettings["GenderFilter"];
        //        dv.RowFilter = filter; //"Property='Gender'";
        //        viewModel.GenderList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["DisabilityTypeFilter"];
        //        dv.RowFilter = filter; //"Property='Type of Disability'";
        //        viewModel.DisabilityTypeList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["AlternateIDTypeFilter"];
        //        dv.RowFilter = filter; //"Property='Alternate id Type'";
        //        viewModel.AlternateIDList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["EducationAttainedFilter"];
        //        dv.RowFilter = filter; //"Property='Education Attained'";
        //        dv.Sort = "PriorityOrder ASC";
        //        viewModel.EducationAttainedList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["CasteCategoryFilter"];
        //        dv.RowFilter = filter; //"Property='Caste Category'";
        //        viewModel.CasteCategoryList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["TraineeReligionFilter"];
        //        dv.RowFilter = filter; //"Property='Trainee Religion'";
        //        viewModel.ReligionList = AllDdlDataTableToList(dv.ToTable());

        //        filter = ConfigurationManager.AppSettings["EmploymentFilter"];
        //        dv.RowFilter = filter; //"Property='Employment Type'";
        //        viewModel.EmploymentList = AllDdlDataTableToList(dv.ToTable());
        //    }
        //}

        //public void GetPostOfficeDetails(CandidateRegistrationViewModel viewModel, string PINCode, string Locality)
        //{

        //    DataTable dt = new DataTable();
        //    string Parms = "PINCode" + "$" + "LocalityID";
        //    string ParmValues = PINCode + "$" + Locality;
        //    string SPName = string.Empty;
        //    SPName = ConfigurationManager.AppSettings["AddressPostOfficeDDL"].ToString();
        //    dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
        //    viewModel.PostOfficeList = AllDdlDataTableToList(dt);

        //}

        //public void GetCityVillageTownDetails(CandidateRegistrationViewModel viewModel, string PINCode, string Locality, string PostOffice)
        //{

        //    DataTable dt = new DataTable();
        //    string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID";
        //    string ParmValues = PINCode + "$" + Locality + "$" + PostOffice;
        //    string SPName = string.Empty;
        //    SPName = ConfigurationManager.AppSettings["AddressCityVillageTownDDL"].ToString();
        //    dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
        //    viewModel.TraineeVillageTownCityList = AllDdlDataTableToList(dt);

        //}

        //public void GetSubDistrictDetails(CandidateRegistrationViewModel viewModel, string PINCode, string Locality, string PostOffice, string Village)
        //{

        //    DataTable dt = new DataTable();
        //    string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID";
        //    string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village;
        //    string SPName = string.Empty;
        //    SPName = ConfigurationManager.AppSettings["AddressSubDistrictDDL"].ToString();
        //    dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
        //    viewModel.TraineeSubDistrictList = AllDdlDataTableToList(dt);

        //}

        //public void GetStatetDetails(CandidateRegistrationViewModel viewModel, string PINCode, string Locality, string PostOffice, string Village, string Subdistrict)
        //{

        //    DataTable dt = new DataTable();
        //    string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID" + "$" + "Subdistrictid";
        //    string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village + "$" + Subdistrict;
        //    string SPName = string.Empty;
        //    SPName = ConfigurationManager.AppSettings["AddressStateDDL"].ToString();
        //    dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
        //    viewModel.TraineeStateList = AllDdlDataTableToList(dt);

        //}

        //public void GetDistrictDetails(CandidateRegistrationViewModel viewModel, string PINCode, string Locality, string PostOffice, string Village, string Subdistrict, string State)
        //{

        //    DataTable dt = new DataTable();
        //    string Parms = "PINCode" + "$" + "LocalityID" + "$" + "postofficeID" + "$" + "VillageID" + "$" + "Subdistrictid" + "$" + "Stateid";
        //    string ParmValues = PINCode + "$" + Locality + "$" + PostOffice + "$" + Village + "$" + Subdistrict + "$" + State;
        //    string SPName = string.Empty;
        //    SPName = ConfigurationManager.AppSettings["AddressDistrictDDL"].ToString();
        //    dt = _dbA.GetDataTable(SPName, Parms, ParmValues);
        //    viewModel.TraineeDistrictList = AllDdlDataTableToList(dt);

        //}

        public DataTable GetEligibilityMsg(string centreCandId, string candName) //To display the reason for not Eligible for diff kind of Eligibility types 
        {
            DataTable dt = new DataTable();
            string Parms = "CentreCandId" + "$" + "CandName";
            string ParmValues = centreCandId + "$" + candName;
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["GetEligibilityMsgs"];
            dt = _dbA.GetValidationDataTable(SPName, Parms, ParmValues);

            return dt;
        }
    }
}
