﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PMU.Models;
using System.Data;
using System.Configuration;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;
using System.Text;
using PMU.Infrastructure;
using System.Security.Policy;

namespace PMU
{
    public partial class DbAction
    {
        public List<LogoType> GetDDLLogoType()
        {
            List<LogoType> objLogoTypeList = new List<LogoType>();
            LogoType objLogoType = null;
            DataTable table = new DataTable();
            int flag = 0;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMU_GetLogoTypeList"];
            table = _dbA.GetDataTable(spName);
            if (table != null && table.Rows.Count > 0)
            {
                foreach (DataRow row in table.Rows)
                {
                    objLogoType = new LogoType();
                    if (flag == 0)
                    {
                        objLogoType.LogoTypeId = -1;
                        objLogoType.LogoTypeName = "Select";
                        objLogoTypeList.Add(objLogoType);
                        objLogoType = new LogoType();
                        flag = 1;
                    }
                    objLogoType.LogoTypeId = Convert.ToInt32(row["DropDownId"]);
                    objLogoType.LogoTypeName = row["DropDownValue"].ToString();
                    objLogoTypeList.Add(objLogoType);
                }
            }
            return objLogoTypeList;
        }

        public MultiLogoList LoadAssetById(int assetId)
        {
            DataTable table = new DataTable();
            Dictionary<string, object> parm = new Dictionary<string, object>();
            MultiLogoList objDualMultiLogo = new MultiLogoList();
            parm.Add("@AssetId", assetId);
            string spName = ConfigurationManager.AppSettings["PMU_LoadAssetById"];
            table = _dbA.GetDataTable(spName, parm);
            if (table.Rows.Count > 0)
            {
                foreach (DataRow dr in table.Rows)
                {
                    objDualMultiLogo.AssetName = dr["AssetName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AssetName"]);
                    objDualMultiLogo.OriginalFileName = dr["OriginalFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["OriginalFileName"]);
                    objDualMultiLogo.AlternateFileName = dr["AlternateFileName"] == DBNull.Value ? string.Empty : Convert.ToString(dr["AlternateFileName"]);
                    objDualMultiLogo.LogoTypeId = dr["AssetType"] == DBNull.Value ? 0 : Convert.ToInt32(dr["AssetType"]);
                    objDualMultiLogo.LogoType = dr["DropDownValue"] == DBNull.Value ? string.Empty : Convert.ToString(dr["DropDownValue"]);
                }
            }
            return objDualMultiLogo;
        }
        public int DeleteLogo(int userId, int deletedBy)
        {
            int isSuccess = 0;
            DataTable table = new DataTable();
            Dictionary<string, object> parm = new Dictionary<string, object>();
            parm.Add("@AssetId", userId);
            parm.Add("@DeletedBy", deletedBy);
            string spName = ConfigurationManager.AppSettings["PMU_DeleteAssetDetail"];
            table = _dbA.GetDataTable(spName, parm);
            if (table != null && table.Rows.Count > 0)
            {
                if (table.Columns.Contains("Column1"))
                {
                    string status = Convert.ToString(table.Rows[0]["Column1"].ToString());
                    if (status == "Deleted Successfully")
                    {
                        isSuccess = 1;
                    }
                }
            }
            return isSuccess;
        }
        public int SubmitLogoForVerification(DualMultiLogo objDualMultiLogo)
        {
            int isSuccess = 0;
            DataSet objDataSet = new DataSet();
            Dictionary<string, object> parm = new Dictionary<string, object>();
            parm.Add("@AssetId", objDualMultiLogo.AssetId);
            parm.Add("@AssetName", objDualMultiLogo.AssetName);
            parm.Add("@AssetCategoryName", "Logo");
            parm.Add("@AssetType", objDualMultiLogo.LogoTypeId);
            parm.Add("@OriginalFileName", objDualMultiLogo.OriginalFileName);
            parm.Add("@AlternativeFilename", objDualMultiLogo.AlternateFileName);
            parm.Add("@CreatedBy", objDualMultiLogo.CreatedBy);
            parm.Add("@TrainingType", objDualMultiLogo.TrainingType);
            parm.Add("@IPAddress", objDualMultiLogo.IpAddress);
            parm.Add("@BrowserType", objDualMultiLogo.BrowserType);
            string spName = ConfigurationManager.AppSettings["PMU_SaveOrUpdateAssetDetails"];
            objDataSet = _dbA.GetDataSet(spName, parm);
            if (objDataSet.Tables[0] != null && objDataSet.Tables[0].Rows.Count > 0)
            {
                if (objDataSet.Tables[0].Columns.Contains("Column1"))
                {
                    string status = Convert.ToString(objDataSet.Tables[0].Rows[0]["Column1"].ToString());
                    if (status == "Inserted Successfully")
                    {
                        string emailSent = string.Empty;
                        string approverEmail = "";
                        int approverId = 0;
                        string attachment = "";
                        DualMultiLogo objCreatedDualMultiLogo = new DualMultiLogo();
                        objCreatedDualMultiLogo.AssetId = Convert.ToInt32(objDataSet.Tables[0].Rows[0]["Column2"]);
                        objCreatedDualMultiLogo.AssetName = objDualMultiLogo.AssetName;
                        objCreatedDualMultiLogo.LogoTypeName = Convert.ToString(objDataSet.Tables[0].Rows[0]["Column3"].ToString());
                        objCreatedDualMultiLogo.TrainingTypeName = Convert.ToString(objDataSet.Tables[0].Rows[0]["Column4"].ToString());
                        if (objDataSet.Tables[1] != null && objDataSet.Tables[1].Rows.Count > 0)
                        {
                            foreach (DataRow dr in objDataSet.Tables[1].Rows)
                            {
                                approverId = dr["UserID"] == DBNull.Value ? 0 : Convert.ToInt32(dr["UserID"]);
                                approverEmail = dr["Email"] == DBNull.Value ? string.Empty : Convert.ToString(dr["Email"]);
                                Dictionary<int, string> email = new Dictionary<int, string>();
                                email.Add(approverId, approverEmail);
                                objCreatedDualMultiLogo.EmailList.Add(email);

                            }
                        }

                        //attachment = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["LogoFilePath"]) + objDualMultiLogo.AlternateFileName;
                        //  attachment = Utility.BuildAssetPath(ConfigurationManager.AppSettings["LogoStorageFilePath"], objDualMultiLogo.LogoTypeName) + objDualMultiLogo.AlternateFileName;
                        emailSent = SendLogoVerificationMail(objCreatedDualMultiLogo);//, attachment);
                         if (emailSent=="Success")
                              isSuccess = 1;
                    }
                    else if (status == "Asset Exists")
                        isSuccess = 2;
                }
            }
            return isSuccess;
        }

        public DataTable GetAllLogos(int start, int pageSize, string orderBy, string sort, string searchByLogoType, int trainingType)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@offset", start);
            parms.Add("@next", pageSize);
            parms.Add("@orderby", orderBy);
            parms.Add("@sortdirection", sort);
            parms.Add("@searchByLogoType", searchByLogoType);
            parms.Add("@trainingType", trainingType.ToString());
            // parms.Add("@search", search);
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["PMU_GetAllLogos"].ToString();
            dt = _dbA.GetDataTable(SPName, parms);
            return dt;
        }




        public string SendLogoVerificationMail(DualMultiLogo objDualMultiLogo)//, string attachment)
        {
            string isMailSent = string.Empty;

            if (objDualMultiLogo != null && objDualMultiLogo.EmailList != null)
            {
                // Task.Run(async () =>
                //  {
                isMailSent = SendVerificationEmailToVerifyLogo(objDualMultiLogo);//, attachment);
                // });
            }

            return isMailSent;
        }

        public string SendVerificationEmailToVerifyLogo(DualMultiLogo objDualMultiLogo)//, string attachment)
        {
            string isMailSent = string.Empty;

            try
            {

                var path = "~\\App_Data\\EmailContent\\LogoVerificationMail.txt";
                

                if (System.Web.HttpContext.Current != null)
                    path = System.Web.HttpContext.Current.Server.MapPath(path);
                else
                    path = HttpRuntime.AppDomainAppPath + path.Replace("~", string.Empty).Replace('/', '\\');

                //var contentPath = System.Web.HttpContext.Current.Server.MapPath("~/Documents/EmailVerificationContent.txt");
                var mailcontent = System.IO.File.ReadAllText(path);
                mailcontent = mailcontent.Replace("@@LOGONAME@@", objDualMultiLogo.AssetName);
                mailcontent = mailcontent.Replace("@@LOGOTYPE@@", objDualMultiLogo.LogoTypeName);

                mailcontent = mailcontent.Replace("@@Training Type@@", objDualMultiLogo.TrainingTypeName);
                string verificationLink = ConfigurationManager.AppSettings["LogoVerificationPath"];
                string previewLink = ConfigurationManager.AppSettings["LogoPreviewPath"];
                foreach (Dictionary<int, string> email in objDualMultiLogo.EmailList)
                {
                    foreach (var item in email)
                    {
                        var previewText = Encoding.UTF8.GetBytes(objDualMultiLogo.AssetId.ToString());
                        string previewQueryString = Convert.ToBase64String(previewText);
                        var approveText = Encoding.UTF8.GetBytes(objDualMultiLogo.AssetId.ToString() + '+' + item.Key + "+Approve");
                        string approveQueryString = Convert.ToBase64String(approveText);
                        var rejectText = Encoding.UTF8.GetBytes(objDualMultiLogo.AssetId.ToString() + '+' + item.Key + "+Reject");
                        string rejectQueryString = Convert.ToBase64String(rejectText);
                        mailcontent = mailcontent.Replace("@@PreviewLink@@", previewLink + previewQueryString);
                        mailcontent = mailcontent.Replace("@@ApproveLink@@", verificationLink + approveQueryString);
                        mailcontent = mailcontent.Replace("@@RejectLink@@", verificationLink + rejectQueryString);
                        var subject = "Logo Verification";

                        // var recordsAffected = 0;
                        //objData.UpdateEmailVerificationHash(agencyId, eMailActivationCode, typeofuser);

                        // if (recordsAffected > 0)
                        //{
                        isMailSent = SendMail(item.Value, subject, mailcontent);//, attachment);

                        // }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            return isMailSent;
        }

        public static string SendMail(string toEmail, string subject, string mailContent)//, string attachedFilePath)
        {
            string MailResult = "Fail";
            try
            {

                var fromEmail = ConfigurationManager.AppSettings["From"];
                var fromEmailPassword = ConfigurationManager.AppSettings["Pwd"];
                var smtpHost = ConfigurationManager.AppSettings["Host"];
                var smtpPort = ConfigurationManager.AppSettings["Port"];

                var mailMsg = new MailMessage(fromEmail, toEmail)
                {
                    Body = mailContent,
                    IsBodyHtml = true,
                    From = new MailAddress(fromEmail),
                    Subject = subject
                };


                string emailCC = ConfigurationManager.AppSettings["EmailLogoVerificationCC"];

                if (emailCC != "")
                {
                    string[] cc = emailCC.Split(',');
                    if (cc != null)
                    {
                        foreach (string item in cc)
                        {
                            MailAddress bcc = new MailAddress(item);
                            mailMsg.Bcc.Add(bcc);
                        }
                    }
                }
                //if (!string.IsNullOrEmpty(attachedFilePath))
                //{
                //    mailMsg.Attachments.Add(new Attachment(attachedFilePath));
                //}

                SmtpClient smtp = new SmtpClient
                {
                    Host = smtpHost,
                    EnableSsl = true
                };

                NetworkCredential networkCred = new NetworkCredential(fromEmail, fromEmailPassword);
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = networkCred;
                smtp.Port = Convert.ToInt32(smtpPort);

                smtp.Send(mailMsg);
                MailResult = "Success";

            }
            catch (Exception EX)
            {
                throw EX;
                // ignored
            }
            return MailResult;
        }
    }
}