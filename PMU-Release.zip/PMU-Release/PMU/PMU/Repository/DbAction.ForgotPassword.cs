﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using PMU.Models;

namespace PMU
{
    public partial class DbAction
    {
        public DataTable CheckUserID(string userid)//, out string nID)
        {
            DataTable dt = new DataTable();
            //string Parms = "@emailid";
            string Parms = "@UserName";
            string ParmValues = userid;

            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["PMU_ForgotPassword"].ToString();
            dt = _dbA.GetDataTable(SPName, Parms, ParmValues);

            return dt;
        }
        public DataTable CheckRequestPasswordChange(string userId)
        {
            DataTable dt = new DataTable();
            var pram = new Dictionary<string, object>();
            pram.Add("@UserID", userId);
            string spName = ConfigurationManager.AppSettings["RequestForgotPasswordChange"];
            dt = _dbA.GetDataTable(spName, pram);
            return dt;
        }
        public DataTable SaveNewPassword(string password, int userId)
        {
            int reset = 1;
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@UserId", userId);
            parms.Add("@pNewPassword", password);
            parms.Add("@ResetOrChange", reset);

            string spName = ConfigurationManager.AppSettings["PMU_ForgotPasswordChangeForgot"];
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }
        public DataTable ChangePassword(string oldpassword, string newpassword, int userId, string userName)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@UserId", userId);
            parms.Add("@Username", userName);
            parms.Add("@pOldPassword", oldpassword);
            parms.Add("@pNewPassword", newpassword);

            string spName = ConfigurationManager.AppSettings["PMU_ForgotPasswordReset"];
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }
        public DataTable ChangeExpiredPassword(string oldpassword, string newpassword, string userName)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@Username", userName);
            parms.Add("@pOldPassword", oldpassword);
            parms.Add("@pNewPassword", newpassword);
            string spName = ConfigurationManager.AppSettings["PMU_ChangeExpiredPassword"];
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }
        public string GetGeoSpecialDetails(string isStateorDistrict, string stateorDistrictId, string tcid)
        {
            DataTable dt = new DataTable();
            string parms = "stateOrDistricttype" + "$" + "stateOrDistrictid" + "$" + "centreId";
            string parmValues = isStateorDistrict + "$" + stateorDistrictId + "$" + tcid;
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["GeoSpecialDetails"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            if (dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            return "N";
        }
        public DataTable CheckUserId(string userid, out string nId)//, out string nID)
        {
            DataTable dt = new DataTable();
            //string Parms = "@emailid";
            string parms = "@UserName";
            string parmValues = userid;

            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["RPL_ForgotPassword"];
            dt = _dbA.GetDataTable(spName, parms, parmValues);
            nId = string.Empty;
            if (!string.IsNullOrEmpty(dt.Rows[0]["ContactID"].ToString()))
            {
                nId = dt.Rows[0]["ContactID"].ToString();
            }
            return dt;
        }

    }
}