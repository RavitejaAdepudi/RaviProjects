﻿using PMU.Models;
using PMU.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Web.Mvc;
using System.Web;

namespace PMU
{
    public partial class DbAction
    {
        #region Location       
        public TrainingLocations BindLocationDetails(int projectId, int partnerId, int locationId)
        {
            DbAction db = new DbAction();
            DataTable table = new DataTable();
            TrainingLocations trainingLocations = new TrainingLocations();
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMU_GetProjectLocations"];
            var parms = new Dictionary<string, object>();
            parms.Add("@ProjectId", projectId);
            parms.Add("@PartnerId", partnerId);
            parms.Add("@LocationID", locationId);
            table = _dbA.GetDataTable(spName, parms);
            var records = new List<TrainingLocations>();
            if (table != null && table.Rows.Count > 0)
            {
                foreach (DataRow row in table.Rows)
                {
                    //trainingLocations.SubmittedToPmu = row.IsNull("SubmittedToPmu")
                    //   ? false
                    //   : Convert.ToBoolean(row["SubmittedToPmu"]);

                    trainingLocations.PINCode = row["Pincode"].ToStr();
                    trainingLocations.LocationID = row["LocationID"].ToInt();
                    trainingLocations.TraineeAddressLine1 = row["Address Line"].ToStr();
                    trainingLocations.Locality = row["LocalityId"].ToStr();
                    trainingLocations.LocationName = row["CentreName"].ToStr();
                    if (row.IsNull("Locality") && row.IsNull("CityID"))
                    {
                        trainingLocations.SelectAddress = "checked";
                        trainingLocations.EnteredAddress = "";
                    }
                    else
                    {
                        trainingLocations.SelectAddress = string.IsNullOrEmpty($"{row["CityID"]}") ? "" : "checked";
                        trainingLocations.EnteredAddress = string.IsNullOrEmpty($"{row["CityID"]}") ? "checked" : "";
                    }

                    trainingLocations.IsSelectorEnterAddress = !string.IsNullOrEmpty($"{row["CityID"]}");

                    trainingLocations.TraineeVillageTownCity = row["Village ID"].ToStr();
                    trainingLocations.PostOffice = row["PostOfficeId"].ToStr();
                    trainingLocations.TraineeSubDistrict = row["Subdistrict ID"].ToStr();
                    trainingLocations.TraineeState = row["StateID"].ToStr();
                    trainingLocations.TraineeDistrict = row["DistrictID"].ToStr();
                    trainingLocations.Constituency = row["ConstituencyID"].ToStr();

                    trainingLocations.TraineeMobileNumber = row["SPOCMobileNo"].ToStr();

                    trainingLocations.STD = row["SPOCSTD"].ToStr();
                    trainingLocations.LandlineNumber = row["SPOCLandlineNo"].ToStr();

                    trainingLocations.EmailAddress = row["CentreSPOCEmail"].ToStr();
                    if (trainingLocations.IsSelectorEnterAddress)
                    {
                        //viewModel.LocalityOthers = string.Format($"{row["Locality"]}");
                        //viewModel.TraineeVillageTownCityOthers = string.Format($"{row["CTV"]}");
                        //viewModel.PostOfficeOthers = string.Format($"{row["PostOffice"]}");
                        //viewModel.TraineeSubDistrictOthers = string.Format($"{row["SubDistrict"]}");
                    }
                    else
                    {
                        trainingLocations.LocalityOthers = row["Locality"].ToStr();
                        trainingLocations.TraineeVillageTownCityOthers = row["CTV"].ToStr();
                        trainingLocations.PostOfficeOthers = row["PostOffice"].ToStr();
                        trainingLocations.TraineeSubDistrictOthers = row["SubDistrict"].ToStr();
                    }

                    trainingLocations.ProjectType = row["ProjectType"].ToStr();
                    trainingLocations.EmployerName = row["EmployerName"].ToStr();
                    trainingLocations.CityId = row["CityId"].ToString();
                    trainingLocations.JobRoleID = row["JobRoleID"].ToInt();
                    trainingLocations.SectorID = row["SectorID"].ToInt();
                    trainingLocations.JobRoleName = row["JobRoleCode"].ToStr();
                    trainingLocations.IsHostelFacilityMale = row["HostelFacilityMale"].ToBoolean();
                    trainingLocations.ISHostelFacilityFemale = row["HostelFacilityFemale"].ToBoolean();
                    trainingLocations.IsHostelFacilityTransgender = row["HostelFacilityTransgender"].ToBoolean();
                    trainingLocations.IsAllowAlternateID = row["IsAllowAlternateID"].ToBoolean();
                    trainingLocations.IsAllowBankAccount = row["IsAllowBankAccount"].ToBoolean();
                    //trainingLocations.UserID = string.Format($"{row["UserID"]}").Split(',');

                    trainingLocations.HostelCapacity = row["HostelCapacity"].ToString();
                    trainingLocations.ConsumedHostelCapacity = row["ConsumedHostelCapacity"].ToString();


                    var traineeStateList = new List<DropDownDDL>();
                    traineeStateList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var localityList = new List<DropDownDDL>();
                    localityList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var traineeDistrictList = new List<DropDownDDL>();
                    traineeDistrictList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var traineeSubDistrictList = new List<DropDownDDL>();
                    traineeSubDistrictList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var traineeVillageTownCityList = new List<DropDownDDL>();
                    traineeVillageTownCityList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var postOfficeList = new List<DropDownDDL>();
                    postOfficeList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var constituencyList = new List<DropDownDDL>();
                    constituencyList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var guardianTypeList = new List<DropDownDDL>();
                    guardianTypeList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    var jobroleList = new List<DropDownDDL>();
                    jobroleList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

                    //if (viewModel.TrainingCampOrEmployerLocationId != 0)//Get Location user Contacts
                    //    viewModel.ManageContactsList = dbA.GetContactDetails(viewModel.TrainingCampOrEmployerLocationId.ToInt(), projectId.ToInt(), partnerId);

                    if (!string.IsNullOrEmpty(trainingLocations.PINCode) && trainingLocations.IsSelectorEnterAddress)
                    {
                        trainingLocations = GetAddressDetails(trainingLocations.PINCode, trainingLocations);
                        trainingLocations.ConstituencyList = GetConstituency(trainingLocations.TraineeState);

                        if (!string.IsNullOrEmpty(trainingLocations.Locality))
                        {

                            db.GetModifyPostOfficeDetails(trainingLocations.PINCode, trainingLocations.Locality, trainingLocations.CityId);
                        }

                        if (!string.IsNullOrEmpty(trainingLocations.PostOffice))
                        {
                            db.GetModifyCityVillageTownDetails(trainingLocations.PINCode, trainingLocations.Locality, trainingLocations.PostOffice);
                        }
                        if (!string.IsNullOrEmpty(trainingLocations.TraineeVillageTownCity))
                        {
                            db.GetModifySubDistrictDetails(trainingLocations.PINCode, trainingLocations.Locality, trainingLocations.PostOffice, trainingLocations.TraineeVillageTownCity);
                        }
                        if (!string.IsNullOrEmpty(trainingLocations.TraineeSubDistrict))
                        {
                            trainingLocations.TraineeStateList = GetState();
                        }
                        if (!string.IsNullOrEmpty(trainingLocations.TraineeState))
                        {
                            trainingLocations.TraineeDistrictList = GetDistrict(trainingLocations.TraineeState);
                            trainingLocations.ConstituencyList = GetConstituency(trainingLocations.TraineeState);
                        }

                        Logger.LogMessage("BindCandidateDetails PINCode:" + trainingLocations.PINCode);
                    }
                    else if (!string.IsNullOrEmpty(trainingLocations.PINCode) && !trainingLocations.IsSelectorEnterAddress)
                    {
                        trainingLocations.TraineeStateList = GetState();
                        if (!string.IsNullOrEmpty(trainingLocations.TraineeState))
                        {
                            trainingLocations.TraineeDistrictList = GetDistrict(trainingLocations.TraineeState);
                            trainingLocations.ConstituencyList = GetConstituency(trainingLocations.TraineeState);
                        }
                        trainingLocations.LocalityList = localityList;
                        trainingLocations.TraineeSubDistrictList = traineeSubDistrictList;
                        trainingLocations.TraineeVillageTownCityList = traineeVillageTownCityList;
                        trainingLocations.PostOfficeList = postOfficeList;
                    }
                    else
                    {
                        trainingLocations.LocalityList = localityList;
                        trainingLocations.TraineeSubDistrictList = traineeSubDistrictList;
                        trainingLocations.TraineeVillageTownCityList = traineeVillageTownCityList;
                        trainingLocations.PostOfficeList = postOfficeList;
                        trainingLocations.TraineeStateList = traineeStateList;
                        trainingLocations.TraineeDistrictList = traineeDistrictList;
                        trainingLocations.ConstituencyList = constituencyList;
                    }
                    trainingLocations.LocationJobroleListDdl = GetProjectLocationJobRole(projectId);
                    IList<TrainingLocations> trainingLocationList = new List<TrainingLocations>();
                    //trainingLocations.LocationJobRoleDetailsList = GetLocationJobRoleList(locationId, SessionMgr.ProjectID.ToInt(), SessionMgr.LoginUserDetails.CentreId);
                    trainingLocations.LocationJobRoleDetailsList = GetLocationJobRoleList(locationId, projectId, SessionMgr.LoginUserDetails.CentreId, SessionMgr.PartnerID.ToInt());
                    IList<ManageContacts> manageContactsList = new List<ManageContacts>();
                    trainingLocations.ManageContactsList = GetManageContactList(locationId, projectId, SessionMgr.LoginUserDetails.CentreId, SessionMgr.TrainingType);
                    trainingLocations.PartnerID = SessionMgr.PartnerID.ToInt();
                    trainingLocations.PartnerName = SessionMgr.TrainingPartner;
                    trainingLocations.TrainingType = SessionMgr.TrainingType;
                    trainingLocations.ProjectID = projectId;
                    SessionMgr.ManageContacts = trainingLocations.ManageContactsList;
                    SessionMgr.TrainingLocationsList = trainingLocations.LocationJobRoleDetailsList;
                }
            }
            return trainingLocations;
        }
        public TrainingLocations BindLocationDetails()
        {
            TrainingLocations trainingLocations = new TrainingLocations();
            var traineeStateList = new List<DropDownDDL>();
            traineeStateList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var localityList = new List<DropDownDDL>();
            localityList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var traineeDistrictList = new List<DropDownDDL>();
            traineeDistrictList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var traineeSubDistrictList = new List<DropDownDDL>();
            traineeSubDistrictList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var traineeVillageTownCityList = new List<DropDownDDL>();
            traineeVillageTownCityList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var postOfficeList = new List<DropDownDDL>();
            postOfficeList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var constituencyList = new List<DropDownDDL>();
            constituencyList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var guardianTypeList = new List<DropDownDDL>();
            guardianTypeList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            var jobroleList = new List<DropDownDDL>();
            jobroleList.Add(new DropDownDDL { nIndex = -1, tDisplayName = "Select" });

            //if (viewModel.TrainingCampOrEmployerLocationId != 0)//Get Location user Contacts
            //    viewModel.ManageContactsList = dbA.GetContactDetails(viewModel.TrainingCampOrEmployerLocationId.ToInt(), projectId.ToInt(), partnerId);

            if (!string.IsNullOrEmpty(trainingLocations.PINCode) && trainingLocations.IsSelectorEnterAddress)
            {
                trainingLocations = GetAddressDetails(trainingLocations.PINCode, trainingLocations);
                trainingLocations.ConstituencyList = GetConstituency(trainingLocations.TraineeState);

            }
            else if (!string.IsNullOrEmpty(trainingLocations.PINCode) && !trainingLocations.IsSelectorEnterAddress)
            {
                trainingLocations.TraineeStateList = GetState();
                if (!string.IsNullOrEmpty(trainingLocations.TraineeState))
                {
                    trainingLocations.TraineeDistrictList = GetDistrict(trainingLocations.TraineeState);
                    trainingLocations.ConstituencyList = GetConstituency(trainingLocations.TraineeState);
                }
                trainingLocations.LocalityList = localityList;
                trainingLocations.TraineeSubDistrictList = traineeSubDistrictList;
                trainingLocations.TraineeVillageTownCityList = traineeVillageTownCityList;
                trainingLocations.PostOfficeList = postOfficeList;
            }
            else
            {
                trainingLocations.LocalityList = localityList;
                trainingLocations.TraineeSubDistrictList = traineeSubDistrictList;
                trainingLocations.TraineeVillageTownCityList = traineeVillageTownCityList;
                trainingLocations.PostOfficeList = postOfficeList;
                trainingLocations.TraineeStateList = traineeStateList;
                trainingLocations.TraineeDistrictList = traineeDistrictList;
                trainingLocations.ConstituencyList = constituencyList;
            }

            //trainingLocations.SectorTypeList = GetCommonDropdownLookup(PropertyLookup.SectorList);
            trainingLocations.LocationJobroleListDdl = GetProjectLocationJobRole(SessionMgr.ProjectID.ToInt());
            IList<TrainingLocations> trainingLocationList = new List<TrainingLocations>();
            trainingLocations.LocationJobRoleDetailsList = trainingLocationList;
            trainingLocations.PartnerID = SessionMgr.PartnerID.ToInt();
            trainingLocations.PartnerName = SessionMgr.TrainingPartner;
            trainingLocations.TrainingType = SessionMgr.TrainingType;
            trainingLocations.ProjectID = SessionMgr.ProjectID.ToInt();
            return trainingLocations;
        }

        public List<TrainingLocations> GetLocationJobRoleDetails(int CID, int TCID, int TrainingType, int ProjectID, string trainingTypeName, int partnerID)
        {
            DataTable _dt = new DataTable();
            var sproclocationtargetNameRequest = ConfigurationManager.AppSettings["LocationTargetDetails"];
            List<TrainingLocations> locationtarget = new List<TrainingLocations>();
            var parm = new Dictionary<string, object>();
            parm.Add("@ContactID", CID);
            parm.Add("@TCID", TCID);
            parm.Add("@TrainingTypeID", TrainingType);
            parm.Add("@ProjectID", ProjectID);
            parm.Add("@PartnerID", partnerID);
            _dt = _dbA.GetDataTable(sproclocationtargetNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                for (int i = 0; i < _dt.Rows.Count; i++)
                {
                    locationtarget.Add(new TrainingLocations
                    {
                        LocationName = _dt.Rows[i]["LocationName"].ToStr(),
                        JobRoleName = _dt.Rows[i]["JobRoleCode"].ToStr(),
                        JobRoleDisplayName = _dt.Rows[i]["JobRoleCode"].ToStr()?.Replace(",", " <br/>"),
                        JobRoleTarget = _dt.Rows[i]["AssignedTarget"].ToInt(),
                        JobRoleIDString = _dt.Rows[i]["JobRoleID"].ToStr(),
                        PartnerID = _dt.Rows[i]["PartnerID"].ToInt(),
                        //TrainingType = Convert.ToInt32(_dt.Rows[i][7]),
                        LocationID = _dt.Rows[i]["LocationID"].ToInt(),
                        ProjectID = _dt.Rows[i]["ProjectID"].ToInt(),
                        TrainingType = trainingTypeName
                    });
                }
            }
            return locationtarget;
        }
        public DataTable SaveLocation(TrainingLocations model)
        {
            XElement xmlLocationUserDetails;
            XElement xmlLocationJobRoleDetails;
            var parms = new Dictionary<string, object>();
            parms.Add("@ProjectID", model.ProjectID);
            parms.Add("@PriorityOrder", model.PriorityOrder);
            parms.Add("@LocationID", model.LocationID);
            parms.Add("@PartnerID", model.PartnerID);
            parms.Add("@ContactID", model.ContactID);
            parms.Add("@CentreName", model.LocationName);
            parms.Add("@AddressLine1", model.TraineeAddressLine1);
            parms.Add("@Pincode", model.PINCode);
            parms.Add("@StateID", model.TraineeState);
            parms.Add("@DistrictID", model.TraineeDistrict);
            parms.Add("@SubDistrict", model.TraineeSubDistrictOthers);
            parms.Add("@SubDistrictID", model.TraineeSubDistrict);
            parms.Add("@ConstituencyID", model.Constituency);
            parms.Add("@CityID", model.TraineeVillageTownCity);
            //parms.Add("@CentreSPOCMobNo",  model.  );
            parms.Add("@CentreSPOCEmail", model.EmailAddress);
            //parms.Add("@CentreContactNumber",  model.  );
            parms.Add("@PostOffice", model.PostOfficeOthers);
            parms.Add("@PostOfficeID", model.PostOffice);
            parms.Add("@Locality", model.LocalityOthers);
            parms.Add("@LocalityID", model.Locality);
            parms.Add("@CTV", model.TraineeVillageTownCityOthers);
            //parms.Add("@State",    model.State  );
            //parms.Add("@CentreEmail",  model.  );
            //parms.Add("@District", model.  );
            parms.Add("@SPOCSTD", model.STD);
            parms.Add("@SPOCLandlineNo", model.LandlineNumber);
            parms.Add("@SPOCEmailID", model.EmailAddress);
            parms.Add("@SPOCMobileNo", model.TraineeMobileNumber);
            //parms.Add("@ProjectID", model.ProjectID);
            parms.Add("@JobRole", string.Join(",", model.JobRoleID));
            parms.Add("@SectorID", string.Join(",", model.SectorID));
            parms.Add("@HostelFacilityMale", model.IsHostelFacilityMale);
            parms.Add("@HostelFacilityFemale", model.ISHostelFacilityFemale);
            parms.Add("@HostelFacilityTransgender", model.IsHostelFacilityTransgender);
            parms.Add("@IsAllowAlternateID", model.IsAllowAlternateID);
            parms.Add("@IsAllowBankAccount", model.IsAllowBankAccount);
            parms.Add("@TrainingTypeID", SessionMgr.TrainingTypeID.ToInt());
            if(model.HostelCapacity!=null)
            {
                parms.Add("@HostelCapacity", model.HostelCapacity);
            }
            else
            {
                parms.Add("@HostelCapacity",0);
            }
            //Location Job Role
            if (model.LocationID == 0)
            {
                if (SessionMgr.TrainingLocationsList != null && SessionMgr.TrainingLocationsList.Count() > 0)
                {
                    xmlLocationJobRoleDetails = new XElement("LocationJobRoles",
                                            from location in SessionMgr.TrainingLocationsList
                                            select new XElement("LocationJobRole",
                                                       new XElement("ProjectID", model.ProjectID),
                                                       new XElement("CentreOrLocationID", model.TrainingCampOrEmployerLocationId),
                                                       new XElement("SectorID", location.SectorID),
                                                       new XElement("JobRoleID", location.JobRoleID),
                                                       new XElement("IsCenter", location.IsCenter),
                                                       new XElement("JobRoleTarget", location.JobRoleTarget),
                                                       new XElement("Type", "I"),
                                                       new XElement("RowVersionCol", location.RowVersion)
                                                      ));
                    parms.Add("@xmlLocationJobRoleDoc", xmlLocationJobRoleDetails.ToStr());
                }
                else
                    parms.Add("@xmlLocationJobRoleDoc", string.Empty);

            }
            else
            {
                if (model.LocationJobRoleDetailsList != null && model.LocationJobRoleDetailsList.Count() > 0)
                {
                    xmlLocationJobRoleDetails = new XElement("LocationJobRoles",
                                            from location in model.LocationJobRoleDetailsList
                                            select new XElement("LocationJobRole",
                                                       new XElement("ProjectID", model.ProjectID),
                                                       new XElement("CentreOrLocationID", model.TrainingCampOrEmployerLocationId),
                                                       new XElement("SectorID", location.SectorID),
                                                       new XElement("JobRoleID", location.JobRoleID),
                                                       new XElement("IsCenter", location.IsCenter),
                                                       new XElement("JobRoleTarget", location.JobRoleTarget),
                                                       new XElement("Type", "I"),
                                                       new XElement("RowVersionCol", location.RowVersion)
                                                      ));
                    parms.Add("@xmlLocationJobRoleDoc", xmlLocationJobRoleDetails.ToStr());
                }
                else
                    parms.Add("@xmlLocationJobRoleDoc", string.Empty);
            }

            //Location User details
            if (SessionMgr.ManageContacts != null && SessionMgr.ManageContacts.Count() > 0)
            {
                xmlLocationUserDetails = new XElement("LocationUsers",
                                        from modelDetails in SessionMgr.ManageContacts
                                        select new XElement("LocationUser",
                                                   new XElement("ProjectID", model.ProjectID),
                                                   new XElement("CentreOrLocationID", model.TrainingCampOrEmployerLocationId),
                                                   new XElement("ContactID", modelDetails.ManageContactID),
                                                   new XElement("IsSpoc", modelDetails.IsSpoc),//TODO
                                                   new XElement("SectorID", model.SectorID),
                                                   new XElement("Type", "I"),//TODO
                                                    new XElement("NewPassword", modelDetails.NewEncPassword)
                                                  ));
                parms.Add("@xmlManageContactsdoc", xmlLocationUserDetails.ToStr());
            }
            else
                parms.Add("@xmlManageContactsdoc", string.Empty);
            parms.Add("@IPAddress", HttpContext.Current.Request.UserHostAddress);
            parms.Add("@CreatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@UpdatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@CreatedDate", null);
            parms.Add("@UpdatedDate", null);
            var spName = ConfigurationManager.AppSettings["PMU_SaveProjectLocations"];
            return _dbA.GetDataTable(spName, parms);
        }
        public string RemoveLocationJobRole(int projectID, int locationID, int jobRoleID, int trainingTypeID)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            var spName = ConfigurationManager.AppSettings["PMU_DeleteLocationJobRole"];
            parms.Add("@ProjectID", projectID);
            parms.Add("@CentreOrLocationID", locationID);
            parms.Add("@JobRoleID", jobRoleID);
            parms.Add("@TrainingTypeID", trainingTypeID);
            int result = _dbA.ExecuteNonQuery(spName, parms);
            if (result > 0)
            {
                return "Record has been Deleted Successfully";
            }
            else if (result == 0 || result == -1)
            {
                return "Job Role can not be deleted, to delete first remove all the enrolled Candidates.";
            }
            else
            {
                return "Some error has occured, Please try again later";
            }
        }

        public IList<ManageContacts> GetContactSearchDetails(string projectID, string partnerID, string contactName = null)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMU_GetContactSearch"];
            parms.Add("@contactName", contactName);
            parms.Add("@projectID", projectID);
            parms.Add("@partnerID", partnerID);
            return DataTableToContactSearchList(_dbA.GetDataTable(spName, parms), 'N');
        }

        private IList<ManageContacts> DataTableToContactSearchList(DataTable dt, char status)
        {
            IList<ManageContacts> list = new List<ManageContacts>();
            if (dt.Rows.Count > 0)
            {
                list = (from DataRow row in dt.Rows
                        select new ManageContacts()
                        {
                            UserID = row["UserID"].ToInt(),
                            ManageContactID = row["ManageContactID"].ToInt(),
                            ContactName = row["Username"].ToStr(),
                            Email = row["Email"].ToStr(),
                            AadhaarNumber = row["AadhaarNumber"].ToStr(),
                            MobileNumber = row["MobileNumber"].ToStr(),
                            Status = status
                        }).ToList();
            }
            return list;
        }

        public IList<ManageContacts> GetContactDetails(int locationID, int projectID, string partnerID)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            string spName = string.Empty;
            spName = ConfigurationManager.AppSettings["PMU_GetContactDetails"];
            parms.Add("@projectID", projectID);
            parms.Add("@partnerID", partnerID);
            parms.Add("@LocationID", locationID);
            return DataTableToContactDetailsList(_dbA.GetDataTable(spName, parms), 'I');
        }
        private IList<ManageContacts> DataTableToContactDetailsList(DataTable dt, char status)
        {
            var list = new List<ManageContacts>();
            if (dt.Rows.Count > 0)
            {
                list = (from DataRow row in dt.Rows
                        select new ManageContacts()
                        {
                            UserID = row["UserID"].ToInt(),
                            IsSpoc = row["IsSPOC"] == DBNull.Value ? false : Convert.ToBoolean(row["IsSPOC"]),
                            ManageContactID = row["ManageContactID"].ToInt(),
                            ContactName = row["Username"].ToStr(),
                            Email = row["Email"].ToStr(),
                            AadhaarNumber = row["AadhaarNumber"].ToStr(),
                            MobileNumber = row["MobileNumber"].ToStr(),
                            Status = status
                        }).ToList();
            }
            return list;
        }

        public object AddLocationJobRole(int partnerId, int locationId, int projectId, int jobRoleId, int? jobRoleTarget, int trainingTypeID)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("@PartnerID", partnerId);
            dict.Add("@LocationID", locationId);
            dict.Add("@ProjectID", projectId);
            dict.Add("@JobRoleID", jobRoleId);
            dict.Add("@JobRoleTarget", jobRoleTarget);
            dict.Add("@TrainingTypeID", trainingTypeID);
            string spName = ConfigurationManager.AppSettings["PMU_Location_AddJobRole"];
            return _dbA.ExecuteNonQuery(spName, dict);
        }

        public object UpdateLocationJobRole(int partnerId, int locationId, int projectId, int jobRoleId, int? jobRoleTarget, int trainingTypeID)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("@PartnerID", partnerId);
            dict.Add("@LocationID", locationId);
            dict.Add("@ProjectID", projectId);
            dict.Add("@JobRoleID", jobRoleId);
            dict.Add("@JobRoleTarget", jobRoleTarget);
            dict.Add("@TrainingTypeID", trainingTypeID);
            string spName = ConfigurationManager.AppSettings["PMU_Location_UpdateJobRole"];
            return _dbA.ExecuteNonQuery(spName, dict);
        }

        public List<UserModel> GetUserDetails(string ManageContactID)
        {
            List<UserModel> userDetails = new List<UserModel>();
            string Sproc = ConfigurationManager.AppSettings["GetUserDetails"];
            var parms = new Dictionary<string, object>();
            parms.Add("@ManageContactID", ManageContactID);

            DataTable dt = _dbA.GetDataTable(Sproc, parms);
            if (dt != null && dt.Rows.Count > 0)
            {
                userDetails = dt.AsEnumerable().ToList().ConvertAll(dr => new UserModel
                {
                    UserId = Convert.ToInt32(dr["UserID"]),
                    Username = Convert.ToString(dr["Username"]),
                    Fullname = Convert.ToString(dr["Fullname"]),
                    EMail = Convert.ToString(dr["Email"]),
                    Password = Convert.ToString(dr["Password"]),
                });
            }
            return userDetails;
        }

        #region Remove Location
        public DataTable RemoveProjectLocation(int projectID, int trainingTypeID, int locationID, int userId)
        {
            try
            {
                DataTable dt = new DataTable();
                var parms = new Dictionary<string, object>();
                var spName = ConfigurationManager.AppSettings["PMU_DeleteProjectLocation"];
                parms.Add("@ProjectID", projectID);
                parms.Add("@TrainingTypeID", trainingTypeID);
                parms.Add("@CentreOrLocationID", locationID);
                parms.Add("@UserId", userId);
                return _dbA.GetDataTable(spName, parms);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        public void CreateEmailSendingStatus(int userId, string userEmail, int emailStatus)
        {
            Dictionary<string, object> dict = new Dictionary<string, object>();
            dict.Add("@UserId", userId);
            dict.Add("@Email", userEmail);
            dict.Add("@Status", emailStatus);
            string spName = ConfigurationManager.AppSettings["PMU_InsertEmailSendingStatus"];
            _dbA.ExecuteNonQuery(spName, dict);
        }

        public void InsertEmailSendingStatus(Int32 userId,
            string emailAddress, Int32 status)
        {
            string spName = ConfigurationManager.AppSettings["PMU_InsertEmailSendingStatus"];

            var dictionary = new Dictionary<string, object>();
            dictionary.Add("UserId", userId);
            dictionary.Add("Email", emailAddress);
            dictionary.Add("Status", status);
            _dbA.ExecuteNonQuery(spName, dictionary);
        }

        #endregion
    }
}