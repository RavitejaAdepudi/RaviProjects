﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;

namespace PMU
{
    public partial class DbAction
    {
        public int ApproveOrRejectLogo(int assetId, string reason, int userId, int isApprove)
        {
            int isSuccess = 0;
            DataTable table = new DataTable();
            Dictionary<string, object> parm = new Dictionary<string, object>();
            parm.Add("@AssetId", assetId);
            parm.Add("@ApproverId", userId);
            parm.Add("@IsApprove", isApprove);
            parm.Add("@Reason", reason);
            parm.Add("@SectorId", 0);
            string spName = ConfigurationManager.AppSettings["PMU_ApproveOrRejectLogo"];
            table = _dbA.GetDataTable(spName, parm);
            if (table != null && table.Rows.Count > 0)
            {
                if (table.Columns.Contains("Column1"))
                {
                    string status = Convert.ToString(table.Rows[0]["Column1"].ToString());
                    if (status == "Status Updated Successfully")
                    {
                        isSuccess = 1;
                    }
                }
            }
            return isSuccess;
        }

        public string GetCurrentStatus(int assetId)
        {
            string status = "";
            DataTable table = new DataTable();
            Dictionary<string, object> parm = new Dictionary<string, object>();
            parm.Add("@AssetId", assetId);

            string spName = ConfigurationManager.AppSettings["PMU_GetCurrentStatus"];
            table = _dbA.GetDataTable(spName, parm);

            if (table != null && table.Rows.Count > 0)
            {
                foreach (DataRow dr in table.Rows)
                {
                    status = dr["DropDownValue"] == DBNull.Value ? string.Empty : Convert.ToString(dr["DropDownValue"]);
                }
            }
            return status;
        }

    }
}