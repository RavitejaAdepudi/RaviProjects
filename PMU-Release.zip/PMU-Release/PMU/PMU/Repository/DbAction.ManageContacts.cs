﻿
using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;
using System.Net.Http.Headers;
using System.Data;
using System.Collections.Generic;
using System;
using PMU.Repository;
using PMU.Infrastructure;

namespace PMU
{
  
    public partial class DbAction
    {
        public DataTable CreateContacts(ManageContactsViewModel viewModel)
        {
            var parm = new Dictionary<string, object>();
            parm.Add("@Fullname", viewModel.ContactName);
            parm.Add("@Email", viewModel.EmailAddress);
            parm.Add("@ContactID", viewModel.ContactID);
            parm.Add("@TCTP", "SPIA");
            parm.Add("@PartnerID", viewModel.PartnerID);
            parm.Add("@CentreID", viewModel.CentreID);
            //parm.Add("@IsLocation", viewModel.IsLocation);
            parm.Add("@ContactNo", Convert.ToString(viewModel.MobileNumber));
            parm.Add("@Gender", viewModel.Gender);
            parm.Add("@Designation", viewModel.Designation);
            parm.Add("@AadhaarNumber", viewModel.AadhaarNumber);
            parm.Add("@AadhaarVerificationStatus", viewModel.AadhaarVerificationStatus);
            parm.Add("@MobileNumber", Convert.ToInt64(viewModel.MobileNumber));
            parm.Add("@MobileOTP", viewModel.EnterOTP);
            parm.Add("@MobileOTPVerificationStatus", viewModel.MobileOTPVerificationStatus);
            parm.Add("@STDCode", viewModel.StdCode);
            parm.Add("@LandlineNo", viewModel.LandlineNumber);
            parm.Add("@RandomPwd", viewModel.RandomPassword);
            parm.Add("@type", viewModel.Type);
            parm.Add("@ManageContactID", viewModel.ManageContactID);
            parm.Add("@UserID", viewModel.CreatedBy);
            string spName = string.Empty;
            DataTable dt = new DataTable();
            spName = ConfigurationManager.AppSettings["PMU_ManageContact_insert"];
            dt = _dbA.GetDataTable(spName, parm);
            return dt;
        }

        public void GetAllDdlList(ManageContactsViewModel viewModel)
        {
            DataTable dt = new DataTable();
            string spName = string.Empty;
            string filter = string.Empty;
            spName = ConfigurationManager.AppSettings["IndependentDDL"];
            dt = _dbA.GetDataTable(spName);

            if (dt.Rows.Count > 0)
            {
                DataView dv = dt.DefaultView;

                filter = ConfigurationManager.AppSettings["GenderFilter"];
                dv.RowFilter = filter; //"Property='Gender'";
                viewModel.GenderList = AllDdlDataTableToList(dv.ToTable());
            }
        }
        public DataTable GetAllContactList(int UserID, int? ManageContactId)
        {
            string retVal = string.Empty;

            var parm = new Dictionary<string, object>();

            parm.Add("@UserID", UserID);
            parm.Add("@ManageContactId ", ManageContactId);
            var spName = ConfigurationManager.AppSettings["SPIA_GetAllContacts"];
            DataTable dt = _dbA.GetDataTable(spName, parm);

            return dt;
        }
        public DataTable GetAllContactList(int UserID, int? ManageContactId, int startFrom, int pageSize, string orderBy, string sort)
        {
            string retVal = string.Empty;

            var parm = new Dictionary<string, object>();

            parm.Add("@UserID", UserID);
            parm.Add("@ManageContactId ", ManageContactId);

            parm.Add("@Start", startFrom);
            parm.Add("@PageSize ", pageSize);
            parm.Add("@OrderBy", orderBy);
            parm.Add("@Sort ", sort);

            var spName = ConfigurationManager.AppSettings["SPIA_GetAllContacts"];
            DataTable dt = _dbA.GetDataTable(spName, parm);

            return dt;
        }

        /////This is for Sending Email using WebAPI and it is common for All Email Methods
        public async Task<HttpResponseMessage> SendRequestAsync(EmailContent emailContent)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                emailContent.EmailFrom = ConfigurationManager.AppSettings["From"].ToString();
                emailContent.EmailSentPassword = ConfigurationManager.AppSettings["Pwd"].ToString();
                emailContent.SMTPHost = ConfigurationManager.AppSettings["Host"].ToString();
                emailContent.SMTPPort = ConfigurationManager.AppSettings["Port"].ToString();
                var apiUrl = ConfigurationManager.AppSettings["EmailAPIUrl"].ToString();

                var myContent = JsonConvert.SerializeObject(emailContent);
                var buffer = Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                //using(var result = await httpClient.PostAsync(apiUrl, byteContent))
                //{
                //    result.EnsureSuccessStatusCode();
                //    return result;
                //}
                var result = httpClient.PostAsync(apiUrl, byteContent).Result;
                return result;
            }
        }

        public IList<DropDownDDL> RemoteSeverValidationTrainingPartner(string controlValue, string controlType)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@ControlValue", controlValue);
            parms.Add("@ControlType", controlType);
            var spName = ConfigurationManager.AppSettings["RemoteServerDuplicationValidationTP"];
            dt = _dbA.GetDataTable(spName, parms);
            var resultData = DataTableToList(dt);
            if (resultData.Count > 0)
            {
                resultData.RemoveAt(0);
            }
            return resultData;
        }

        public DataTable RemoteSeverValidationTrainingPartner(string controlValue, string controlType, string CalledBy)
        {
            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            parms.Add("@ControlValue", controlValue);
            parms.Add("@ControlType", controlType);
            parms.Add("@CalledBy", CalledBy);
            var spName = ConfigurationManager.AppSettings["RemoteServerDuplicationValidationTP"];
            return _dbA.GetDataTable(spName, parms);
        }

        public DataTable GetUsersForLocation(int locationId)
        {
            var spName = ConfigurationManager.AppSettings["PMULOCATION_GetLocationUsersForEmail"];
            var parms = new Dictionary<string, object>();
            parms.Add("@LocationID", locationId);

            return _dbA.GetDataTable(spName, parms);
        }

        public ManageContacts GetContactByContact(int contactID)
        {
            ManageContacts viewmodel = new ManageContacts();
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@ContactID", contactID);
            var spName = ConfigurationManager.AppSettings["PMULocation_GetContactByContact"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            viewmodel = GetManageContact(dt);
            return viewmodel;
        }

        private ManageContacts GetManageContact(DataTable dt)
        {
            ManageContacts viewmodel = new ManageContacts();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    viewmodel.ContactName = dr["ContactName"].ToString();
                    viewmodel.UserID = Convert.ToInt32(dr["ContactID"]);
                    viewmodel.Email = dr["Email"].ToString();
                    //viewmodel.MobileNumber = dr["MobileNumber"].ToString();
                    //viewmodel.AadhaarNumber = dr["AadhaarNumber"].ToString();
                    //viewmodel.Gender = dr["Gender"].ToString();
                    //viewmodel.Designation = dr["Designation"].ToString();
                    //viewmodel.AadhaarVerificationStatus = dr["Aadhaar Verification Status"].ToString();
                    //viewmodel.MobileOTPVerificationStatus = dr["Mobile OTP Verification Status"].ToString();
                    //viewmodel.STDCode = dr["STDCode"].ToString();
                    //viewmodel.LandlineNo = dr["LandlineNo"].ToString();
                }
            }
            return viewmodel;

        }
    }
}