﻿using PMU.Models;
using PMU.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Web.Mvc;
using System.Web;
using System.Net;

namespace PMU
{
    public partial class DbAction
    {
        DataTable _dt = new DataTable();

        #region CreateProject

        public IList<DropDownDDL> GetTrainingPartnerTypeList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["SPIAGetDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return DataTableToList(dt);
        }
        public IList<DropDownDDL> GetTrainingTypes()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["GetTrTypeDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return DataTableToList(dt);
        }
        public IList<DropDownDDL> GetProjectType()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["ProjectTypeDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToList(dt));
        }
        public IList<DropDownDDL> GetDisbursementModeTypeList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["DisbursementDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToList(dt));
        }
        public IList<DropDownDDL> GetCertificateTemplateTypeList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["CertficateTemplate"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToList(dt, false));
        }
        public IList<DropDownDDL> GetSectorTypeList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["ProjectTypeDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToList(dt));
        }
        public IList<DropDownDDL> GetProjectJobroleList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["ProjectJobRoleDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToJobRoleList(dt));
        }
        public List<DropDownDDL> DataTableToJobRoleList(DataTable table)
        {
            var list = new List<DropDownDDL>(table.Rows.Count);
            //if (includeSelectDefault)
            //{
            //    var ddl = new DropDownDDL()
            //    {
            //        nIndex = -1,
            //        tDisplayName = "Select"
            //    };
            //    list.Add(ddl);
            //}

            foreach (DataRow row in table.Rows)
            {
                var values = row.ItemArray;
                var ddl = new DropDownDDL()
                {
                    nIndex = Convert.ToInt32(values[0]),
                    tDisplayName = values[1].ToString()
                };
                ddl.tDisplayCode = values.Length > 2 ? $"{values[2]}" : string.Empty;
                ddl.nAltIndex = values.Length > 3 ? $"{values[3]}" : string.Empty;
                list.Add(ddl);
            }
            return list;
        }
        public IList<DropDownDDL> GetLocationJobroleList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["LocationJobRoleDDL"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToJobRoleList(dt));
        }
        public IList<DropDownDDL> GetPlacementApplicableDisbursmentList()
        {
            DataTable dt = new DataTable();
            string SPName = string.Empty;
            SPName = ConfigurationManager.AppSettings["PlacementApplicableDisbursement"].ToString();
            dt = _dbA.GetDataTable(SPName);
            return (DataTableToList(dt));
        }
        public DataTable SaveSPIAProject(ProjectViewModel model)
        {
            XElement xmlProjectJobRole;
            XElement xmlGovtCertificateLogo;
            XElement xmlCorporateCertificateLogo;

            //XDocument xmlLocation;
            var parms = new Dictionary<string, object>();
            parms.Add("@ProjectID", model.ProjectID);
            parms.Add("@PartnerID", model.TrainingPartnerID);
            parms.Add("@CRMProjectID", model.CRMProjectID);
            parms.Add("@ProjectName", model.ProjectName);
            parms.Add("@ProjectCode", model.ProjectCode);
            parms.Add("@ProjectType", model.ProjectTypeID);
            parms.Add("@StartDate", model.StartDate);
            parms.Add("@EndDate", model.EndDate);
            parms.Add("@LocationCount", model.LocationCount);
            parms.Add("@AllowedJobRoleCount", model.AllowedJobRoleCount);
            parms.Add("@IsActive", model.IsActive);
            parms.Add("@IsDeleted", model.IsDeleted);
            parms.Add("@MaxPIAFeesPayout", model.PIAFee);
            parms.Add("@HasBridgeCourse", model.HasBridgeCourse);
            parms.Add("@IsPlacementApplicable", model.IsPlacementApplicable);
            parms.Add("@TrainingType", model.TrainingTypeID);
            parms.Add("@PlacementDisbursement", model.PlacementDisbursementID);
            parms.Add("@DisbursementMode", model.DisbursementModeID);
            parms.Add("@ProjectJobRoleTarget", model.ProjectJobRoleTarget);
            parms.Add("@CertificateTemplateType", model.CertificateTemplateTypeID);
            parms.Add("@CustomTemplateLogoURL", model.CustomTemplateLogoURL);
            parms.Add("@CustomTemplateName", model.FileName);
            parms.Add("@ProjectDuration", model.ProjectDuration);
            parms.Add("@BatchDuration", model.BatchDuration);
            if (SessionMgr.ProjectJobRole != null)
            {
                xmlProjectJobRole = new XElement("ProjectJobRoles",
                                        from jobRole in SessionMgr.ProjectJobRole
                                        select new XElement("ProjectJobRole",
                                                   new XElement("SectorID", jobRole.SectorID),
                                                   new XElement("JobRoleID", jobRole.JobroleID),
                                                   new XElement("JobRoleTarget", jobRole.JobRoleTarget),
                                                   new XElement("HasBridgeCourse", jobRole.HasBridgeCourse),
                                                   new XElement("BridgeCourseHours", jobRole.BridgeCourseDuration),
                                                   new XElement("BridgeCourseDiscountPercentage", jobRole.BridgeCourseDiscount),
                                                   new XElement("Type", "I")//TODO
                                                  ));
                parms.Add("@xmlProjecJobRoleDoc", xmlProjectJobRole.ToStr());
            }
            else
                parms.Add("@xmlProjecJobRoleDoc", string.Empty);


            if (model.CustomTemplateType.CustomFileSelectedGovt.Count > 0)
            {
                xmlGovtCertificateLogo= new XElement("GovtCertificateLogo",
                                        from govt in model.CustomTemplateType.CustomFileSelectedGovt
                                        select new XElement("GovtCertificate",
                                                   new XElement("AssetId", govt.AssetId),
                                                   new XElement("LogoType", nameof(PMU.CustomLogoFor.Government)),
                                                   new XElement("LogoNum", govt.FileNumber),
                                                   new XElement("Position", govt.Position),
                                                   new XElement("CustomTemplateId", model.CustomCertificateTemplateId),
                                                   new XElement("Type", "I")//TODO
                                                  ));
                parms.Add("@xmlGovtCertificateLogo", xmlGovtCertificateLogo.ToStr());
            }
            else
                parms.Add("@xmlGovtCertificateLogo", string.Empty);


            if (model.CustomTemplateType.CustomFileSelectedCorporate.Count > 0)
            {
                xmlCorporateCertificateLogo = new XElement("CorpCertificateLogo",
                                        from corp in model.CustomTemplateType.CustomFileSelectedCorporate
                                        select new XElement("CorpCertificate",
                                                   new XElement("AssetId", corp.AssetId),
                                                   new XElement("LogoType", nameof(PMU.CustomLogoFor.Corporation)),
                                                   new XElement("LogoNum", corp.FileNumber),
                                                    new XElement("Position", corp.Position),
                                                   new XElement("CustomTemplateId", model.CustomCertificateTemplateId),
                                                   new XElement("Type", "I")//TODO
                                                  ));
                parms.Add("@xmlCorporateCertificateLogo", xmlCorporateCertificateLogo.ToStr());
            }
            else
                parms.Add("@xmlCorporateCertificateLogo", string.Empty);
           
            //if (model.LocationList != null && model.LocationList.Count() > 0)//TODO Don't Remove
            //{
            //    xmlLocation = new XDocument(new XElement("Root",
            //                              from location in model.LocationList
            //                              select new XElement("Location", new XAttribute("Id", location.LocationID),
            //                              from jobRole in location.SelectedJobRoleList
            //                              select new XElement("LocationJobRole",
            //                                    new XElement("ProjectID", model.ProjectID),
            //                                    new XElement("CenterOrLocationID", location.LocationID),
            //                                    new XElement("SectorID", location.SectorID),
            //                                    new XElement("JobRoleID", jobRole),
            //                                    new XElement("IsCenter", model.IsCenter),//TODO
            //                                    new XElement("Type", "I")
            //                            ))));
            //    parms.Add("@xmlLocatinDoc", xmlLocation.ToStr());
            //}
            //else
            //{
            //    parms.Add("@xmlLocatinDoc", string.Empty);
            //}
            parms.Add("@IdAddress", HttpContext.Current.Request.UserHostAddress);
            parms.Add("@CreatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@UpdatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@CreatedDate", null);
            parms.Add("@UpdatedDate", null);
            parms.Add("@IsAllowBatchCreateDate", model.IsBatchBackDateEnable);
            parms.Add("@BackDate", model.BatchBackDate);
            parms.Add("@CustomCertificateTemplateId", model.CustomCertificateTemplateId);

            var spName = ConfigurationManager.AppSettings["PMUSaveProjectDetails"];
            return _dbA.GetDataTable(spName, parms);
        }

        public DataTable EditRPLProject(ProjectViewModel model)
        {
            XElement xmlProjectJobRole;
            var parms = new Dictionary<string, object>();
            parms.Add("@ProjectID", model.ProjectID);
            parms.Add("@PartnerID", model.TrainingPartnerID);
            parms.Add("@ProjectName", model.ProjectName);
            parms.Add("@TrainingType", model.TrainingTypeID);
            parms.Add("@ProjectJobRoleTarget", model.ProjectJobRoleTarget);

            if (SessionMgr.ProjectJobRole != null)
            {
                xmlProjectJobRole = new XElement("ProjectJobRoles",
                                        from jobRole in SessionMgr.ProjectJobRole
                                        select new XElement("ProjectJobRole",
                                                   new XElement("SectorID", jobRole.SectorID),
                                                   new XElement("JobRoleID", jobRole.JobroleID),
                                                   new XElement("JobRoleTarget", jobRole.JobRoleTarget),
                                                   new XElement("HasBridgeCourse", jobRole.HasBridgeCourse),
                                                   new XElement("BridgeCourseHours", jobRole.BridgeCourseDuration == 0 ? 0 : jobRole.BridgeCourseDuration),
                                                   new XElement("BridgeCourseDiscountPercentage", jobRole.BridgeCourseDiscount == null ? 0 : jobRole.BridgeCourseDiscount),
                                                   new XElement("Type", "I")//TODO
                                                  ));
                parms.Add("@xmlProjecJobRoleDoc", xmlProjectJobRole.ToStr());
            }
            else
                parms.Add("@xmlProjecJobRoleDoc", string.Empty);
            parms.Add("@IdAddress", HttpContext.Current.Request.UserHostAddress);
            parms.Add("@CreatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@UpdatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@CreatedDate", null);
            parms.Add("@UpdatedDate", null);
            parms.Add("@IsAllowBatchCreateDate", model.IsBatchBackDateEnable);
            parms.Add("@BackDate", model.BatchBackDate);

            var spName = ConfigurationManager.AppSettings["RPLProjectJobRoleEdit"];
            return _dbA.GetDataTable(spName, parms);
        }
        public IList<TrainingPartner> GetSearchTrainingPartnerDetails(string piaName)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> param = new Dictionary<string, object>();
            string SPName = string.Empty;
            param.Add("@PartnerName", piaName);
            SPName = ConfigurationManager.AppSettings["PMUSearchTrainingPartnerDetails"].ToString();
            dt = _dbA.GetDataTable(SPName, param);
            return (DataTableToTrainingPartnerList(dt));
        }
        public IList<TrainingPartner> DataTableToTrainingPartnerList(DataTable dt)
        {
            TrainingPartner viewModel = new TrainingPartner();
            var trainingPartnerList = new List<TrainingPartner>();
            if (dt.Rows.Count > 0)
            {
                trainingPartnerList = (from DataRow row in dt.Rows
                                       select new TrainingPartner()
                                       {
                                           PartnerID = row["PartnerID"].ToInt(),
                                           PartnerName = row["PartnerName"].ToStr(),
                                           PartnerType = row["PartnerType"].ToStr(),
                                           ContactNo = row["ContactNo"].ToStr(),
                                           Email = row["Email"].ToStr(),
                                           SPOCName = row["SPOCName"].ToStr(),
                                           SPOCMobile = row["SPOCMobile"].ToStr(),
                                           SPOCEmail = row["SPOCEmail"].ToStr(),
                                       }).ToList();
            }
            return trainingPartnerList;
        }
        public DataTable SavePIADetails(TrainingPartner model)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@PartnerName", model.PartnerName);
            parms.Add("@SPOCName", model.SPOCName);
            parms.Add("@SPOCEmail", model.SPOCEmail);
            parms.Add("@SPOCMobile", model.SPOCMobile);
            parms.Add("@CentreID", model.CentreID);
            parms.Add("@ContactID", model.ContactID);
            parms.Add("@RandomPwd", model.RandomPassword);
            parms.Add("@IPAddress", HttpContext.Current.Request.UserHostAddress);
            //parms.Add("@IPAddress", Dns.GetHostEntry(Dns.GetHostName()).AddressList.First(f => f.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork).ToString());
            parms.Add("@CreatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@UpdatedBy", SessionMgr.LoginUserDetails.UserId);
            parms.Add("@CreatedDate", null);
            parms.Add("@UpdatedDate", null);

            DataTable dt = new DataTable();
            var spName = ConfigurationManager.AppSettings["PMUSaveTrainingPartnerDetails"];
            dt = _dbA.GetDataTable(spName, parms);
            return dt;
        }
        public IList<DropDownDDL> GetJobRoleBySector(string sectorID, string sectorTypeID)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@SectorID", sectorID);
            parms.Add("@SectorTypeID", sectorTypeID);
            var spName = ConfigurationManager.AppSettings["GetJobRoleBySector"];
            return DataTableToList(_dbA.GetDataTable(spName, parms), false);
        }

        public IList<DropDownDDL> GetDisbursementModeByPlacement(string placementID)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@PlacementID", placementID);
            var spName = ConfigurationManager.AppSettings["GetDisbursementModeByPlacement"];
            return DataTableToList(_dbA.GetDataTable(spName, parms), false);
        }
        public IList<DropDownDDL> GetSectorBySectorType(string sectorType)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@SectorTypeID", sectorType);
            var spName = ConfigurationManager.AppSettings["GetSectorBySectorType"];
            return DataTableToList(_dbA.GetDataTable(spName, parms), false);
        }
        public Dictionary<string, string> CheckIsProjectValid(string projectName, string traingingTypeID, decimal sourceTarget)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> param = new Dictionary<string, object>();
            string SPName = string.Empty;
            param.Add("@ProjectName", projectName);
            param.Add("@TrainingTypeID", traingingTypeID);
            param.Add("@sourceTarget", sourceTarget);
            SPName = ConfigurationManager.AppSettings["PMUCheckIsProjectExists"].ToString();
            dt = _dbA.GetDataTable(SPName, param);
            Dictionary<string, string> dect = new Dictionary<string, string>
                {
                    {"ProjectValidation", dt.Rows[0]["ProjectValidation"].ToStr()},
                    {"SchemLevelValidation", dt.Rows[0]["schemLevelValidation"].ToStr()}
                };
            return (dect);
        }

        public IList<DropDownDDL> GetProjectTypeByTrainingType(string trainingTypeID)
        {
            var parms = new Dictionary<string, object>();
            parms.Add("@TrainingType", trainingTypeID);
            var spName = ConfigurationManager.AppSettings["GetProjectTypeByTraningType"];
            return DataTableToList(_dbA.GetDataTable(spName, parms), false);
        }


        #endregion

        #region ProjectsSearch

        public IList<ProjectsModel> getProjectList(string trainingTypeID, string partnerID, string projectTypeID, string sectorID, string jobRoleID)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            var sprocprojectNameRequest = ConfigurationManager.AppSettings["ProjectList"];
            var parm = new Dictionary<string, object>();
            var projecttypelist = new List<ProjectsModel>();
            parm.Add("@TrainingTypeID", trainingTypeID.ToDbObject());
            parm.Add("@PartnerID", partnerID.ToDbObject());
            parm.Add("@ProjectTypeID", projectTypeID.ToDbObject());
            parm.Add("@SectorID", sectorID.ToDbObject());
            parm.Add("@JobRoleID", jobRoleID.ToDbObject());

            _dt = _dbA.GetDataTable(sprocprojectNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                projecttypelist = (from DataRow dr in _dt.Rows
                                   select new ProjectsModel()
                                   {
                                       //SerialNo = dr["SerialNo"].ToInt(),
                                       ProjectID = dr["ProjectID"].ToInt(),
                                       ProjecTypeId = dr["ProjectTypeID"].ToStr(),
                                       ProjectType = dr["ProjectType"].ToStr(),
                                       ProjectName = dr["ProjectName"].ToStr(),
                                       JobRole = dr["JobRole"].ToStr(),
                                       Sector = dr["SectorName"].ToStr(),
                                       JobRoleDisplayName = dr["JobRole"].ToStr()?.Replace(",", " <br/>"),
                                       SectorDisplayName = dr["SectorName"].ToStr()?.Replace(",", " <br/>"),
                                       TrainingTypeID = dr["TrainingType"].ToInt(),
                                       TrainingTypeName = dr["TrainingTypeName"].ToStr(),
                                       SubmittedToPMU = dr["SubmittedToPMU"].ToStr(),
                                   }).ToList();
            }
            _viewModel.ProjectDetailsList = projecttypelist;
            return (projecttypelist);
        }
        public ProjectViewModel getProjectDetails(int trainingtypeid, int projectid)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            var sprocprojectNameRequest = ConfigurationManager.AppSettings["ProjectDetails"];
            var parm = new Dictionary<string, object>();
            parm.Add("@TrainingType", trainingtypeid);
            parm.Add("@ProjectID", projectid);
            _dt = _dbA.GetDataTable(sprocprojectNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                foreach (DataRow row in _dt.Rows)
                {
                    _viewModel.TrainingPartner = row["PartnerName"].ToStr();
                    _viewModel.AccountID = row["PartnerID"].ToStr();
                    _viewModel.CRMProjectID = row["CRMProjectID"].ToStr();
                    _viewModel.TrainingType = row["TrainingType"].ToStr();
                    _viewModel.ProjectID = row["ProjectID"].ToInt();
                    _viewModel.ProjectType = row["ProjectType"].ToStr();
                    _viewModel.ProjectName = row["ProjectName"].ToStr();
                    _viewModel.IsPlacementApplicable = row["IsPlacementApplicable"].ToBoolean();
                    _viewModel.Disbursement = row["PlacementDisbursement"].ToStr();
                    _viewModel.DisbursementMode = row["DisbursementMode"].ToStr();
                    _viewModel.CustomTemplateLogoURL = row["CustomTemplateLogoURL"].ToStr();
                    _viewModel.FileName = row["CustomTemplateName"].ToStr();
                    _viewModel.PIAFee = row["MaxPIAFeesPayout"].ToDecimal();
                    _viewModel.ProjectJobRoleTarget = row["ProjectJobRoleTarget"].ToInt();
                    _viewModel.CustomTemplateLogoURL = _viewModel.CustomTemplateLogoURL;// Server.MapPath();
                    _viewModel.ProjectDuration = row["ProjectDuration"].ToInt();
                    _viewModel.BatchDuration = row["BatchDuration"].ToInt();
                    _viewModel.StartDate = row["StartDate"].ToDatetimeddmmyyyy();
                    _viewModel.EndDate = row["EndDate"].ToDatetimeddmmyyyy();
                    _viewModel.BatchBackDate = row["BatchCreateInBackDate"] == DBNull.Value ? string.Empty : row["BatchCreateInBackDate"].ToDatetimeddmmyyyy();
                    _viewModel.IsBatchBackDateEnable = row["IsAllowBatchCreateInBackDate"] == DBNull.Value ? false : Convert.ToBoolean(row["IsAllowBatchCreateInBackDate"]);
                    _viewModel.CertificateTemplate = row["CertificateTemplateType"] == DBNull.Value ? string.Empty : row["CertificateTemplateType"].ToString();
                    _viewModel.CertificateTemplateTypeID = row["CertificateTemplateTypeId"] == DBNull.Value ? string.Empty : row["CertificateTemplateTypeId"].ToString();
                    _viewModel.TrainingPartnerID = row["PartnerID"] == DBNull.Value ? 0 : row["PartnerID"].ToInt();
                    _viewModel.TrainingTypeID = row["TrainingTypeId"] == DBNull.Value ? 0 : row["TrainingTypeId"].ToInt();
                    _viewModel.CustomCertificateTemplate = row["TemplateType"] == DBNull.Value ? string.Empty : row["TemplateType"].ToString();
                    _viewModel.CustomCertificateTemplateId = row["CustomCertificateTemplateId"] == DBNull.Value ? 0 : row["CustomCertificateTemplateId"].ToInt();

                    var parameter = new Dictionary<string, object>();
                    parameter.Add("@ProjectID", projectid);
                    DataTable d = _dbA.GetDataTable(ConfigurationManager.AppSettings["PMU_GetCustomLogoByProjectID"],parameter);

                    if (d.Rows.Count > 0)
                    {
                        foreach (DataRow sa in d.Rows)
                        {
                            CustomFileDetail obj = new CustomFileDetail()
                            {
                                AssetId = string.IsNullOrEmpty(Convert.ToString(sa["AssetId"])) ? 0 : Convert.ToInt32(sa["AssetId"]),
                                IndustryType = $"{sa["AssetType"]}",
                                FileName = $"{sa["AlternateFileName"]}",
                                FileNumber = string.IsNullOrEmpty(Convert.ToString(sa["FileNumber"])) ? 0 : Convert.ToInt32(sa["FileNumber"]),
                                Position = $"{sa["Position"]}",
                            };

                            if (obj.IndustryType == nameof(CustomLogoFor.Government))
                            {
                                _viewModel.CustomTemplateType.CustomFileSelectedGovt.Add(obj);
                            }
                            else if (obj.IndustryType == nameof(CustomLogoFor.Corporation))
                            {
                                _viewModel.CustomTemplateType.CustomFileSelectedCorporate.Add(obj);
                            }
                        }
                    }

                }
            }
            //JobRoles Sector
            _viewModel.ProjectJobRoleList = GetProjectJobRoleDetails(SessionMgr.LoginUserDetails.CentreId, SessionMgr.LoginUserDetails.ContactId, trainingtypeid, projectid, SessionMgr.LoginUserDetails.UserId);
            //var sprocsectortargetRequest = ConfigurationManager.AppSettings["ProjectAffiliatedSectorDetails"];
            //var parmtarget = new Dictionary<string, object>();
            //parmtarget.Add("@ProjectID", projectid);
            //var projectJobRoleList = new List<ProjectJobRole>();
            //_dt = _dbA.GetDataTable(sprocsectortargetRequest, parmtarget);
            //if (_dt != null && _dt.Rows.Count > 0)
            //{
            //    for (int i = 0; i < _dt.Rows.Count; i++)
            //    {
            //        projectJobRoleList.Add(new ProjectJobRole
            //        {
            //            SectorID = _dt.Rows[i]["SectorID"].ToInt(),
            //            Sector = _dt.Rows[i]["SectorName"].ToStr(),
            //            JobroleID = _dt.Rows[i]["JobRoleID"].ToInt(),
            //            selectedJobRoleText = _dt.Rows[i]["JobRole"].ToStr(),
            //            JobRoleTarget = _dt.Rows[i]["JOBROLETARGET"].ToInt()
            //        });
            //    }
            //}
            //_viewModel.ProjectJobRoleList = projectJobRoleList;

            return _viewModel;
        }
        public ProjectViewModel getPartnerList(string partnername)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            var sprocpartnerRequest = ConfigurationManager.AppSettings["PartnerDetails"];
            var parmtarget = new Dictionary<string, object>();
            parmtarget.Add("@PartnerName", partnername);
            _dt = _dbA.GetDataTable(sprocpartnerRequest, parmtarget);
            var partnerdetailslist = new List<TrainingPartner>();
            if (_dt != null && _dt.Rows.Count > 0)
            {
                for (int i = 0; i < _dt.Rows.Count; i++)
                {
                    partnerdetailslist.Add(new TrainingPartner
                    {
                        PartnerID = _dt.Rows[i][0].ToInt(),
                        PartnerName = _dt.Rows[i][1].ToStr(),
                        SPOCName = _dt.Rows[i][2].ToStr(),
                        SPOCEmail = _dt.Rows[i][3].ToStr(),
                        SPOCMobile = _dt.Rows[i][4].ToStr()
                    });
                }
            }
            //If No TP found for Name Provided
            else
            {
                _viewModel.ProjectErrorMsg = "No Records Found";
            }
            _viewModel.TrainingPartnerList = partnerdetailslist;
            return _viewModel;
        }
        public List<ProjectJobRole> GetProjectJobRoleDetails(int CID, int TCID, int TrainingType, int ProjectID, int partnerID)
        {
            DataTable _dt = new DataTable();
            var parm = new Dictionary<string, object>();
            parm.Add("@ContactID", CID);
            parm.Add("@TCID", TCID);
            parm.Add("@TrainingTypeID", TrainingType);
            parm.Add("@ProjectID", ProjectID);
            parm.Add("@PartnerID", partnerID);
            var sprocsectortargetNameRequest = ConfigurationManager.AppSettings["JobRoleTargetDetails"];
            List<ProjectJobRole> projectJobRoleList = new List<ProjectJobRole>();
            _dt = _dbA.GetDataTable(sprocsectortargetNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                for (int i = 0; i < _dt.Rows.Count; i++)
                {
                    projectJobRoleList.Add(new ProjectJobRole
                    {
                        Sector = _dt.Rows[i]["SectorName"].ToStr(),
                        selectedJobRoleText = _dt.Rows[i]["JobRole"].ToStr(),
                        JobRoleTarget = _dt.Rows[i]["target"].ToDecimal(),
                        RemainingTarget = _dt.Rows[i]["RemainingTarget"].ToDecimal(),
                        SectorID = _dt.Rows[i]["SectorID"].ToInt(),
                        JobroleID = _dt.Rows[i]["JobRoleID"].ToInt(),
                        HasBridgeCourse = _dt.Rows[i]["HasBridgeCourse"].ToBoolean(),
                        BridgeCourseDuration = _dt.Rows[i]["BridgeCourseHours"].ToInt(),
                        BridgeCourseDiscount = _dt.Rows[i]["BridgeCourseDiscountPercentage"].ToDecimal(),
                        SectorTypeId = _dt.Rows[i]["SectorTypeId"].ToInt(),
                      //  isTargetAllocation = true
                    });
                }
            }
            return projectJobRoleList;
        }
        public IList<ProjectJobRole> getTargetJobRoleDetails(int locationid, int partnerid, int projectid)
        {
            IList<ProjectJobRole> projectList = new List<ProjectJobRole>();
            var sprocprojectNameRequest = ConfigurationManager.AppSettings["JobRoleDetails"];
            var parm = new Dictionary<string, object>();
            parm.Add("@LocationID", locationid);
            parm.Add("@PartnerID", partnerid);
            parm.Add("@ProjectID", projectid);
            _dt = _dbA.GetDataTable(sprocprojectNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                for (int i = 0; i < _dt.Rows.Count; i++)
                {
                    ProjectJobRole projectJobRole = new ProjectJobRole();
                    projectJobRole.selectedJobRoleText = _dt.Rows[i]["JobRole"].ToStr();
                    projectJobRole.JobRoleTarget = _dt.Rows[i]["JobRoleTarget"].ToInt();
                    projectJobRole.RemainingTarget = _dt.Rows[i]["RemaingTarget"].ToInt();
                    projectList.Add(projectJobRole);
                }
            }
            return projectList;
        }
        public List<DropDownDDL> getTargetSectorDetails(int partnerid, int projectid, int locationid, int jobroleid)
        {
            var sprocprojectNameRequest = ConfigurationManager.AppSettings["JobRoleList"];
            var jobroleList = new List<DropDownDDL>();
            var parm = new Dictionary<string, object>();
            parm.Add("@JobRoleID", jobroleid);
            parm.Add("@LocationID", locationid);
            parm.Add("@PartnerID", partnerid);
            parm.Add("@ProjectID", projectid);
            _dt = _dbA.GetDataTable(sprocprojectNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                for (int i = 0; i < _dt.Rows.Count; i++)
                {
                    jobroleList.Add(new DropDownDDL
                    {
                        nIndex = _dt.Rows[i][0].ToInt(),
                        tDisplayName = _dt.Rows[i][1].ToStr()
                    });
                }
            }

            return (jobroleList);
        }
        public Dictionary<string, string> ProjectWiseTarget(int projectID, int JobRoleID, int SourceTarget, int SumofTarget, int LocationID, int traingingType, int partnerID)
        {

            DataTable dt = new DataTable();
            var parms = new Dictionary<string, object>();
            var spName = ConfigurationManager.AppSettings["PMU_GetProjectWiseTarget"];
            parms.Add("@ProjectID", projectID);
            parms.Add("@JobRoleID", JobRoleID);
            parms.Add("@SourceTarget", SourceTarget);
            parms.Add("@SumofTarget", SumofTarget);
            parms.Add("@LocationID", LocationID);
            parms.Add("@TrainingTypeID", traingingType);
            parms.Add("@PartnerID", partnerID);
            dt = _dbA.GetDataTable(spName, parms);
            Dictionary<string, string> dect = new Dictionary<string, string>
                {
                    {"ValidMessage", dt.Rows[0]["Validationmessage"].ToStr()},
                    {"RemaingTarget", dt.Rows[0]["RemainingTarget"].ToStr()}
                };

            return (dect);
        }

        #endregion

        //-----------Target Related------------------
        public PMUTargetAllocation getTargetPartnerJobRoleLocationList(int CID, int TCID, int TrainingTypeId, int projectid, int partnerID)
        {
            PMUTargetAllocation _viewModel = new PMUTargetAllocation();
            _viewModel.TrainingType = TrainingTypeId.ToString();
            _viewModel.ProjectID = projectid;

            //Bind Partner Details
            var sproctrainingpartnerNameRequest = ConfigurationManager.AppSettings["TargetPartnerDetails"];
            var parm = new Dictionary<string, object>();
            parm.Add("@ContactID", CID);
            parm.Add("@TCID", TCID);
            parm.Add("@TrainingTypeID", _viewModel.TrainingType);
            parm.Add("@ProjectID", _viewModel.ProjectID);
            parm.Add("@PartnerID", partnerID);
            _dt = _dbA.GetDataTable(sproctrainingpartnerNameRequest, parm);
            if (_dt != null && _dt.Rows.Count > 0)
            {
                _viewModel.TrainingPartner = _dt.Rows[0]["PartnerName"].ToStr();
                _viewModel.ProjectName = _dt.Rows[0]["ProjectName"].ToStr();
                _viewModel.TrainingPartnerID = _dt.Rows[0]["PartnerID"].ToInt();
                _viewModel.TrainingType = _dt.Rows[0]["TrainingType"].ToStr();
                _viewModel.ProjectID = _dt.Rows[0]["ProjectID"].ToInt();
            }
            //Bind Job role Details


            return _viewModel;
        }

        public bool GetJobRoleDelete(int projectId, int jobRoleId)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> param = new Dictionary<string, object>();
            string SPName = string.Empty;
            param.Add("@ProjectId", projectId);
            param.Add("@JobRole", jobRoleId);
            SPName = ConfigurationManager.AppSettings["GetDeleteJobRole"].ToString();
            dt = _dbA.GetDataTable(SPName, param);
            return Convert.ToBoolean(dt.Rows[0][0]);
        }

        public DataTable GetProjectJobRoleDetailsForDownload(int CID, int TCID, int TrainingType, int ProjectID, int partnerID)
        {
            DataTable _dt = new DataTable();
            var parm = new Dictionary<string, object>();
            parm.Add("@ContactID", CID);
            parm.Add("@TCID", TCID);
            parm.Add("@TrainingTypeID", TrainingType);
            parm.Add("@ProjectID", ProjectID);
            parm.Add("@PartnerID", partnerID);
            var sprocsectortargetNameRequest = ConfigurationManager.AppSettings["JobRoleTargetDetails"];
            List<ProjectJobRole> projectJobRoleList = new List<ProjectJobRole>();
            _dt = _dbA.GetDataTable(sprocsectortargetNameRequest, parm);
            return _dt;
        }

        public DataTable GetProjectDetailsForDownload(int trainingtypeid, int projectid)
        {
            ProjectViewModel _viewModel = new ProjectViewModel();
            var sprocprojectNameRequest = ConfigurationManager.AppSettings["ProjectDetails"];
            var parm = new Dictionary<string, object>();
            parm.Add("@TrainingType", trainingtypeid);
            parm.Add("@ProjectID", projectid);
            _dt = _dbA.GetDataTable(sprocprojectNameRequest, parm);
            return _dt;
        }

        public DataTable CheckJobRoleInLocation(int projectId,
            int jobRoleId,int jobRoleTarget)
        {
            Dictionary<string, object> param = new Dictionary<string, object>();
            string SPName = string.Empty;
            param.Add("@ProjectId", projectId);
            param.Add("@JobRole", jobRoleId);
            param.Add("@JobRoleTarget", jobRoleTarget);
            SPName = ConfigurationManager.AppSettings["GetJobRoleLocationStatus"].ToString();
            DataTable result = _dbA.GetDataTable(SPName, param);
            return result;
        }

    }
}


