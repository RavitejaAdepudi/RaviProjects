﻿using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System;
using System.IO;

namespace PMU
{
    public partial class DbAction
    {
        #region TrainingCenterVerification
        public IList<TrainingLocations> GetTraingcentersforVerification(string tringTypeID,string verificationStatusID)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@trainingTypeID", tringTypeID.ToDbObject());
            parm.Add("@verificationStatusID", verificationStatusID.ToDbObject());
            var spName = ConfigurationManager.AppSettings["GetPlacementTrainingCenters"];
            return GetTraingcentersforVerificationList(_dbA.GetDataTable(spName, parm));
        }
        public IList<TrainingLocations> GetTraingcentersforVerificationList(DataTable dt)
        {
            IList<TrainingLocations> list = new List<TrainingLocations>();
            TrainingLocations trainingLocations = new TrainingLocations();
            list = (from DataRow dr in dt.Rows
                               select new TrainingLocations()
                               {
                                   //SerialNo = dr["SerialNo"].ToInt(),
                                   TrainingCampOrEmployerLocationId = dr["LocationID"].ToInt(),
                                   LocationName = dr["CentreName"].ToStr(),
                                   BatchApprovalStatus = dr["BatchApprovalStatus"].ToStr(),
                                   TrainingType = dr["trainingType"].ToStr(),
                                   TotalBatchAssessed = dr["TotalBatchesAssessed"].ToInt(),
                                   TotalBatchesPendingValidation = dr["TotalBatchesPendingValidation"].ToInt(),
                               }).ToList();
            return list;
        }

        #endregion TrainingCenterVerification

        #region BatchDetails
        public IList<BatchDetails> GetBatchDetailsList(string locationID,string tringTypeID, string verificationStatusID,string fromDate,string toDate)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@trainingTypeID", tringTypeID.ToDbObject());
            parm.Add("@verificationStatusID", verificationStatusID.ToDbObject());
            parm.Add("@FromDate", fromDate.ToDbObject());
            parm.Add("@ToDate", toDate.ToDbObject());
            parm.Add("@LocationID", locationID.ToDbObject());
            var spName = ConfigurationManager.AppSettings["GetPlacementBatchDetails"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            return (GetBatchDetailsList(dt));
        }
        public IList<BatchDetails> GetBatchDetailsList(DataTable dt)
        {
            IList<BatchDetails> list = new List<BatchDetails>();
            BatchDetails trainingLocations = new BatchDetails();
            list = (from DataRow dr in dt.Rows
                    select new BatchDetails()
                    {
                        //SerialNo = dr["SerialNo"].ToInt(),
                        BatchID = dr["BatchID"].ToInt(),
                        LocationID = dr["LocationID"].ToInt(),
                        BatchName = dr["BatchName"].ToStr(),
                        LocationName = dr["CentreName"].ToStr(),
                        PreferredAssessmentDate = dr["PreferedAssessmentDate"].ToDatetimemmddyyyy(),
                        //AssessmentStartDate = dr["TotalBatchesAssessed"].ToStr(),
                        //AssessmentEndDate = dr["TotalBatchesPendingValidation"].ToStr(),
                        TotalCountCandidates = dr["TotalCandidatesinBatch"].ToInt(),
                        TotalCertifiedCandidates = dr["TotalCertifiedCandidates"].ToInt(),
                        VerificatinStatus = dr["VerificationStatus"].ToStr(),
                        TrainingTypeName = dr["TrainingTypeName"].ToStr()
                    }).ToList();
            return list;
        }

        #endregion CandidateList

        #region CandidateList

        public IList<DropDownDDL> GetCandidateDropdownList(int batchID,int locationID)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            parms.Add("@BatchID", batchID);
            parms.Add("@CenterID", locationID);
            return DataTableToList(_dbA.GetDataTable(ConfigurationManager.AppSettings["GetDropdownSelectcandidates"], parms), false);
        }

        public IList<PostPlacement> CandidateEligibleforPostPlacement(string Centreid, string Batchid)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            string parmValues = string.Empty;
            string spName = string.Empty;
            parms.Add("@CentreID", Centreid);
            parms.Add("@BatchID", Batchid);
            spName = ConfigurationManager.AppSettings["PMU_GetEligiblePostPlacement"];
            return (CandidateEligibleforPostPlacement(_dbA.GetDataTable(spName, parms)));
        }
        public IList<PostPlacement> CandidateEligibleforPostPlacement(DataTable dt)
        {
            IList<PostPlacement> list = new List<PostPlacement>();
            PostPlacement trainingLocations = new PostPlacement();
            list = (from DataRow dr in dt.Rows
                    select new PostPlacement()
                    {
                        Month1 = dr["Month1"].ToInt(),
                        Month2 = dr["Month2"].ToInt(),
                        Month3 = dr["Month3"].ToInt(),
                        Month4 = dr["Month4"].ToInt(),
                        Month5 = dr["Month5"].ToInt(),
                        Month6 = dr["Month6"].ToInt(),
                    }).ToList();
            return list;
        }

        #endregion CandidateList

        #region EligiblePostPlacement
        public IList<PostPlacement> GetEligiblePlacementDetails(string batchID, string locationID,string candidateID)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@BatchID", batchID);
            parm.Add("@LocationID", locationID);
            parm.Add("@CandidateID", candidateID);
            var spName = ConfigurationManager.AppSettings["PMU_GetEligiblePostPlacement"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            return (GetEligiblePlacementDetailsList(dt));
        }
        private IList<PostPlacement> GetEligiblePlacementDetailsList(DataTable dt)
        {
            IList<PostPlacement> list = new List<PostPlacement>();
            PostPlacement trainingLocations = new PostPlacement();
            list = (from DataRow dr in dt.Rows
                    select new PostPlacement()
                    {
                        Month1 = dr["Month1"].ToInt(),
                        Month2 = dr["Month2"].ToInt(),
                        Month3 = dr["Month3"].ToInt(),
                        Month4 = dr["Month4"].ToInt(),
                        Month5 = dr["Month5"].ToInt(),
                        Month6 = dr["Month6"].ToInt(),
                    }).ToList();
            return list;
        }
        #endregion EligiblePostPlacement

        #region PlacementDetails
        public IList<CandidateEmploymentModel> GetPlacementDetails(string tringTypeID, string verificationStatusID)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@trainingTypeID", tringTypeID);
            parm.Add("@verificationStatusID", verificationStatusID);
            var spName = ConfigurationManager.AppSettings["PMULocation_GetContactByContact"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            return (GetPlacementDetailsList(dt));
        }
        public IList<CandidateEmploymentModel> GetPlacementDetailsList(DataTable dt)
        {
            IList<CandidateEmploymentModel> list = new List<CandidateEmploymentModel>();
            CandidateEmploymentModel trainingLocations = new CandidateEmploymentModel();
            list = (from DataRow dr in dt.Rows
                    select new CandidateEmploymentModel()
                    {
                        FromDate = dr["FromDate"].ToStr(),
                        ToDate = dr["ToDate"].ToStr(),
                        NatureOfEmployment = dr["NatureOfEmployment"].ToStr(),
                        PMUVerificationStatus = dr["PMUVerificationStatus"].ToStr(),
                    }).ToList();
            return list;
        }

        public IList<CandidateEmploymentModel> GetCandidateDetails(int candID)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            parms.Add("@CandidateID", candID);
            return DataTableToCandidateDetailsList(_dbA.GetDataTable(ConfigurationManager.AppSettings["GetCandidateDetails"], parms));
        }
        public IList<CandidateEmploymentModel> DataTableToCandidateDetailsList(DataTable dt)
        {
            CandidateEmploymentModel viewModel = new CandidateEmploymentModel();
            var list = new List<CandidateEmploymentModel>();
            if (dt.Rows.Count > 0)
            {
                list = (from DataRow row in dt.Rows
                        select new CandidateEmploymentModel()
                        {

                            EmploymentDetailID = row["EmploymentDetailID"].ToInt(),
                            CandidateID = row["CandidateID"].ToInt(),
                            FromDate = row["FromDate"].ToDatetimeddmmyyyy(),
                            ToDate = row["ToDate"].ToDatetimeddmmyyyy(),
                            EmploymentTypeId =row["EmployerType"].ToInt(),
                            EmployerTypeDesc = row["EmployerTypeDesc"].ToStr(),
                            NatureOfEmployment = row["NatureOfEmployment"].ToStr(),
                            EmployerLocationID = row["EmployerLocationID"].ToInt(),
                            CandidateDesignation = row["CandidateDesignation"].ToStr(),
                            SelfMonthlyIncome = row["SelfMonthlyIncome"].ToInt(),
                            WageMonthlyIncome = row["WageMonthlyIncome"].ToInt(),
                            //SelfDocumentProofID = row["SelfDocumentProofID"].ToInt(),
                            //SelfDocumentProofName = row["SelfDocumentProofName"].Tostr(),
                            //WageDocumentProofID = row["WageDocumentProofID"].ToInt(),
                            //WageDocumentProofName = row["WageDocumentProofName"].Tostr(),
                            EmployerID = row["EmployerID"].ToInt(),
                            OrgarnizationName = row["OrganizationName"].ToStr(),
                            StateName = row["StateName"].ToStr(),
                            DistrictName = row["DistrictName"].ToStr(),
                            DistrictID = row["SLRCID"].ToInt(),
                            StateID = row["DLRCID"].ToInt(),
                            //DistrictID = row["DistrictID"].ToInt(),
                            //StateID = row["StateID"].ToInt(),
                        }).ToList();
            }
            return list;
        }

        public CandEnrolment GetCandidateEnrollment(int? candID)
        {
            DataTable dt = new DataTable();
            Dictionary<string, object> parms = new Dictionary<string, object>();
            parms.Add("@CandidateID", candID);
            return DataTableToEnrollment(_dbA.GetDataTable(ConfigurationManager.AppSettings["GetCandidateEnrollment"], parms));
        }
        public CandEnrolment DataTableToEnrollment(DataTable dt)
        {
            CandEnrolment viewModel = new CandEnrolment();
            if (dt.Rows.Count > 0)
            {
                viewModel.CandidateName = dt.Rows[0]["CandidateName"].ToStr();
                viewModel.Gender = dt.Rows[0]["Gender"].ToStr();
                viewModel.DateofBirth = dt.Rows[0]["DateofBirth"].ToDatetimeddmmyyyy();
                //Added for year of birth 
                viewModel.DateofBirth = string.IsNullOrEmpty(viewModel.DateofBirth.ToStr()) ? (string.IsNullOrEmpty(dt.Rows[0]["YearofBirth"].ToStr()) ? "" : dt.Rows[0]["YearofBirth"].ToStr()) : viewModel.DateofBirth;
                viewModel.EligibleforPostPlacementSupport = dt.Rows[0]["EligibleforPostPlacementSupport"].ToStr();
                viewModel.BatchAssessmentDate = dt.Rows[0]["BatchAssessmentDate"].ToDatetimeddmmyyyy();
                viewModel.CertifiedDate = dt.Rows[0]["CertifiedDate"].ToDatetimeddmmyyyy();
            }
            return viewModel;
        }

        public IList<CandEnrolment> BatchtoCandiadteDetails(int batchid,int locationID)
        {
            DataTable dt = new DataTable();
            var batchtoCandlist = new List<CandEnrolment>();
            DataTable ds = new DataTable();
            try
            {
                Dictionary<string, object> parms = new Dictionary<string, object>();
                string parmValues = string.Empty;
                string spName = string.Empty;
                parms.Add("@CentreID", locationID);
                parms.Add("@BatchID", batchid);
                spName = ConfigurationManager.AppSettings["GetBatchtoCandidateList"];
                dt = _dbA.GetDataTable(spName, parms);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        CandEnrolment placementCandidateListInfo = new CandEnrolment();
                        placementCandidateListInfo.CandID = dt.Rows[i]["CandID"].ToInt();
                        placementCandidateListInfo.CentreID = dt.Rows[i]["CentreID"].ToStr();
                        placementCandidateListInfo.CandidateName = dt.Rows[i]["CandidateName"].ToStr();
                        placementCandidateListInfo.Gender = dt.Rows[i]["Gender"].ToStr();
                        placementCandidateListInfo.DateofBirth = dt.Rows[i]["DateofBirth"].ToDatetimeddmmyyyy();
                        placementCandidateListInfo.EligibleforPostPlacementSupport = dt.Rows[i]["postplacement"].ToStr();
                        placementCandidateListInfo.PlacementStatus = string.IsNullOrEmpty(dt.Rows[i]["PlacementStatus"].ToStr()) ? "NA" : dt.Rows[i]["PlacementStatus"].ToStr();
                        batchtoCandlist.Add(placementCandidateListInfo);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return (batchtoCandlist);
        }

        #endregion PlacementDetails

        #region DocumentsDetails

        public CandidateEmploymentModel GetCandidateEmploymentDetails(string candEmpID)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@EmploymentDetailID", candEmpID);
            var spName = ConfigurationManager.AppSettings["GetEmployementDetails"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            return (GetCandidateEmploymentDetails(dt));
        }
        private CandidateEmploymentModel GetCandidateEmploymentDetails(DataTable dt)
        {
            CandidateEmploymentModel viewModel = new CandidateEmploymentModel();
            if (dt.Rows.Count > 0)
            {
                viewModel.FromDate = dt.Rows[0]["FromDate"].ToDatetimeddmmyyyy();
                viewModel.ToDate = dt.Rows[0]["ToDate"].ToDatetimeddmmyyyy();
                viewModel.EmployerTypeDesc = dt.Rows[0]["EmployerTypeDesc"].ToStr();
                viewModel.SelfMonthlyIncome = dt.Rows[0]["MonthlyIncome"].ToInt();
                viewModel.StateName = dt.Rows[0]["StateName"].ToStr();
                viewModel.DistrictName = dt.Rows[0]["DistrictName"].ToStr();
                viewModel.OrgarnizationName = dt.Rows[0]["NatureOfEmployment"].ToStr();
                viewModel.Designation = dt.Rows[0]["CandidateDesignation"].ToStr();
                viewModel.PMUVerificationStatus = dt.Rows[0]["PMUApproval"].ToStr();
            }
            return viewModel;
        }
        public IList<DocumentDetails> GetDocumentsDetails(string candEmpID)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@EmploymentDetailID", candEmpID);
            var spName = ConfigurationManager.AppSettings["GetEmployementDocumentDetails"];
            DataTable dt = _dbA.GetDataTable(spName, parm);
            return (GetDocumentsDetailsList(dt));
        }
        private IList<DocumentDetails> GetDocumentsDetailsList(DataTable dt)
        {
            IList<DocumentDetails> list = new List<DocumentDetails>();
            DocumentDetails trainingLocations = new DocumentDetails();
            list = (from DataRow dr in dt.Rows
                    select new DocumentDetails()
                    {
                        CandidateEmploymentAssetsID = dr["CandidateEmploymentAssetsID"].ToInt(),
                        DateUploaded = dr["CreatedDate"].ToDatetimeddmmyyyy(),
                        TypeofDocument = dr["DocumentProofName"].ToStr(),
                        DocumentFiled = dr["DocumentFile"].ToStr(),
                        ValidTo = dr["ValidFrom"].ToDatetimeddmmyyyy(),
                        ValidFrom = dr["ValidTo"].ToDatetimeddmmyyyy(),
                        DocumentLocation=Path.Combine(ConfigurationManager.AppSettings["PlacementCandidateFileLocation"], dr["DocumentFile"].ToStr())
                    }).ToList();
            return list;
        }
        public int SaveDocumentVerification(string EmploymentDetailID,string ReasonID, string OtherDesc)
        {
            string retVal = string.Empty;
            var parm = new Dictionary<string, object>();
            parm.Add("@EmploymentDetailID", EmploymentDetailID);
            //parm.Add("@ReasonID", viewModel.ReasonID);
            //parm.Add("@ReasonDesc", viewModel.ReasonDesc);
            parm.Add("@PMUOtherVerficationStatusDesc", OtherDesc);
            parm.Add("@PMUVerificationStatusID", ReasonID);
            var spName = ConfigurationManager.AppSettings["SaveDocumentVerification"];
            return (_dbA.ExecuteNonQuery(spName, parm));
        }
        #endregion DocumentsDetails
    }
}
