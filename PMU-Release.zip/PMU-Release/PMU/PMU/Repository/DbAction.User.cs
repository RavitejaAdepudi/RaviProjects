﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMU.Infrastructure;

namespace PMU
{
    public partial class DbAction
    {
        public List<UserRole> GetUserRoles(string username)
        {
            DataTable dt = new DataTable();

            string spName = ConfigurationManager.AppSettings["PMU_Login_Roles"];
            var parms = new Dictionary<string, object>();

            parms.Add("@Username", username);

            dt = _dbA.GetDataTable(spName, parms);

            var result = new List<UserRole>();
            foreach (DataRow row in dt.Rows)
            {
                var role = new UserRole();
                role.RoleName = $"{row["RoleName"]}";
                role.RoleId = row.IsNull("RoleID") ? 0 : (int)row["RoleID"];
                role.IsSysAdmin = row.IsNull("IsSysAdmin") ? false : (bool)row["IsSysAdmin"];
                result.Add(role);
            }
            return result;
        }

        public List<RolePermission> GetUserPermissions(string username)
        {
            DataTable dt = new DataTable();

            string spName = ConfigurationManager.AppSettings["PMU_Login_Permissions"];
            var parms = new Dictionary<string, object>();

            parms.Add("@Username", username);

            dt = _dbA.GetDataTable(spName, parms);

            var result = new List<RolePermission>();
            foreach (DataRow row in dt.Rows)
            {
                var permission = new RolePermission();
                permission.PermissionRoute = $"{row["PermissionRoute"]}";
                permission.RoleId = row.IsNull("RoleID") ? 0 : (int)row["RoleID"];
                permission.PermissionId = row.IsNull("PermissionID") ? 0 : (int)row["PermissionID"];
                //role.RoleId = row.IsNull("RoleId") ? 0 : Convert.ToInt32($"{row["RoleId"]}");
                //role.IsSysAdmin = row.IsNull("IsSysAdmin") ? false : Convert.ToBoolean($"{row["IsSysAdmin"]}");
                result.Add(permission);
            }
            return result;
        }
    }
}
