﻿$('#divLoading').bind('ajaxStart', function () {
    $(this).show();
}).bind('ajaxStop', function () {
    $(this).hide();
});
//Function to allow only numbers and backspace and del
function AllowNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46
     || event.keyCode === 37 || event.keyCode === 39) {
        return true;
    }
    else if (key < 48 || key > 57) {
        return false;
    }
    else return true;
};
//Function to allow only numbers and backspace and del and do not allow first letter zero
function AllowOnlyNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    //console.log(key);
    if (event.target.value.length === 0 && event.which === 48) {
        return false;
    }
    else if (event.keyCode === 8 || event.keyCode === 46
 || event.keyCode === 37 || event.keyCode === 39) {
        return true;
    }
    else if (key < 48 || key > 57) {
        return false;
    }
    else return true;
};
//Function to allow only numbers
function IsNumber(e) {
    var keyCode = e.which;
    if (keyCode < 48 || keyCode >= 58 && keyCode !== 8) {
        e.preventDefault();
    }
}

//Function to allow alphanumeric, Space
function IsAlphaNumeric(e) {
    var keyCode = e.which;
    if ((keyCode < 48 || keyCode >= 58) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && keyCode != 32 && keyCode != 8)
        e.preventDefault();
}

//Function to allow alphanumeric
function IsOnlyAlphaNumeric(e) {
    var keyCode = e.which;
    if ((keyCode < 48 || keyCode >= 58) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && keyCode != 8)
        e.preventDefault();
}

//Function to allow only characters
function IsAlpha(e) {
    var keyCode = e.which;
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && keyCode != 8)
        e.preventDefault();
}

//Function to allow only AlphaNumeric, Space and -
function IsChar(e) {
    var keyCode = e.which;
    //alert(keyCode);
    if ((keyCode < 48 || keyCode >= 58) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && (keyCode != 32) && (keyCode != 45) && keyCode != 8)
        e.preventDefault();
}

//Function to allow only Alphabets, Space and -
function OnlySpaceAlphabets(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && (keyCode != 32) && (keyCode != 45) && keyCode != 8)
        evt.preventDefault();
}

//Function to allow only Numeric, Space and -
function OnlySpaceNumbers(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if ((keyCode < 48 || keyCode >= 58) && (keyCode != 32) && (keyCode != 45) && keyCode != 8)
        evt.preventDefault();
}

//Function to allow only AlphaNumeric, Space, hyphen, slash, period, @, comma
function AlphaNumericSpace(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    //alert(keyCode);
    if ((keyCode < 48 || keyCode >= 58) &&
        (keyCode < 65 || keyCode > 90) &&
        (keyCode < 97 || keyCode >= 123) &&
        (keyCode != 32) && (keyCode != 45) &&
        keyCode != 47 && keyCode != 46 &&
        keyCode != 64 && keyCode != 44 && keyCode != 8) {
        evt.preventDefault();
    }
}

//Function to allow only AlphaNumeric, Space, hyphen, slash, period, comma
function AlphaNumericHyphen(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    //alert(keyCode);
    if ((keyCode < 48 || keyCode >= 58) &&
        (keyCode < 65 || keyCode > 90) &&
        (keyCode < 97 || keyCode >= 123) &&
        (keyCode != 32) && (keyCode != 45) &&
        keyCode != 47 && keyCode != 46 &&
        keyCode != 64 && keyCode != 44 && keyCode != 8) {
        evt.preventDefault();
    }
}

//Function to allow only Alphabets, Space ,hyphen, comma, dot
function OnlyAlphabetsHyphenComma(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if ((keyCode < 65 || keyCode > 90) &&
        (keyCode < 97 || keyCode >= 123) &&
        (keyCode != 32) && (keyCode != 45) &&
        (keyCode != 44) && (keyCode != 46) && keyCode != 8) {
        evt.preventDefault();
    }
}

function Logout() {
    var url = document.getElementById("LogoutAnchor").getAttribute("data-url");
    if (confirm("Are you sure want to Logout??")) {
        window.location.href = url;
    }
}

function AdjustUserName() {
    var nameLength = $('#userName').text().length;
    if (nameLength >= 15) {

        var wlcmTxt = $('#userName').text();
        wlcmTxt = wlcmTxt.substring(0, 15) + "...";
        $("#mainLi").css("width", "240px");
        $("#userName").text(wlcmTxt);
        $("#ChangePasswordLi").css("width", "238px");
        $("#LogoutLi").css("width", "238px");
    }
    else {
        $("#mainLi").css("width", "200px");
        $("#ChangePasswordLi").css("width", "198px");
        $("#LogoutLi").css("width", "198px");
    }
}


function changePassword() {
    var url = document.getElementById("changePassworAnchor").getAttribute("data-url");
    window.location.href = url;
}

function showHideMandatorySign(varObj, mandatoryId) {
    if ($("#" + varObj.id).val() == "") {
        $("#" + mandatoryId).show();
    }
    else {
        $("#" + mandatoryId).hide();
    }
}

function ValidateText(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if (keyCode == 34 || keyCode == 39 && keyCode != 8)
        return false;
    return true;
}

function numericAndValidText(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if ((keyCode < 48 || keyCode >= 58) || (keyCode == 34 || keyCode == 39) && keyCode != 8)
        return false;
    return true;

}

function alphnumericAndValidText(evt) {
    var keyCode = (evt.which) ? evt.which : event.keyCode
    if ((keyCode < 48 || keyCode >= 58) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && keyCode != 32 && (keyCode == 34 || keyCode == 39) && keyCode != 8)
        return false;
    return true;

}


function AllowNumbers(evt) {

    var keyCode = (evt.which) ? evt.which : event.keyCode
    if (keyCode < 48 || keyCode >= 58 && keyCode != 8)
        return false;
    return true;
}

function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    //just one dot
    if (number.length > 1 && charCode == 46) {
        return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1)) {
        return false;
    }
    return true;
}
function getSelectionStart(o) {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        if (document.selection) { //IE
            var r = self.document.body.createTextRange().duplicate();
            r.moveEnd('character', o.value.length)
            if (r.text == '') return o.value.length
            return o.value.lastIndexOf(r.text)
        }
        else return o.selectionStart;
    }
    else {
        if (window.getSelection) { //others
            var r = self.document.createRange().duplicate();
            r.moveEnd('character', o.value.length)
            if (r.text == '') return o.value.length
            return o.value.lastIndexOf(r.text)
        } else return o.selectionStart
    }
    //if (o.createTextRange) {
    //    var r = document.selection.createRange().duplicate()
    //    r.moveEnd('character', o.value.length)
    //    if (r.text == '') return o.value.length
    //    return o.value.lastIndexOf(r.text)
    //} else return o.selectionStart
}

//$(document)
//  .ajaxStart(function () {
//      waitingDialog.show('Loading.. Please wait')
//  })
//  .ajaxStop(function () {
//      waitingDialog.hide();
//  });
//var waitingDialog = (function ($) {

//    // Creating modal dialog's DOM
//    var $dialog = $(
//        '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
//        '<div class="modal-dialog modal-m">' +
//        '<div class="modal-content">' +
//            '<div class="modal-header"><h3 style="margin:0;"></h3></div>' +
//            '<div class="modal-body">' +
//                '<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar" style="width: 100%"></div></div>' +
//            '</div>' +
//        '</div></div></div>');

//    return {

//        show: function (message, options) {
//            // Assigning defaults
//            var settings = $.extend({
//                dialogSize: 'm',
//                progressType: ''
//            }, options);
//            if (typeof message === 'undefined') {
//                message = 'Loading';
//            }
//            if (typeof options === 'undefined') {
//                options = {};
//            }
//            // Configuring dialog
//            $dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
//            $dialog.find('.progress-bar').attr('class', 'progress-bar');
//            if (settings.progressType) {
//                $dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
//            }
//            $dialog.find('h3').text(message);
//            // Opening dialog
//            $dialog.modal();
//        },
//        /**
//         * Closes dialog
//         */
//        hide: function () {
//            $dialog.modal('hide');
//        }
//    }

//})(jQuery);


//$(document).ready(function() {
//    $('#moodleAnchor').click(function() {
//        $(this).target = "_blank";
//        window.open($(this).prop('href'));
//        return false;
//    });
//});​
function my_onkeydown_handler() {
    switch (event.keyCode) {
        case 116: // 'F5'
            event.returnValue = false;
            event.keyCode = 0;
            window.status = "We have disabled F5";
            break;
    }
}
function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82 || (e.which || e.keyCode) == 8) e.preventDefault(); };
$(document).ready(function () {

    //$(document).on("keydown", disableF5);
    focusOnValidationError('.input-validation-error:first', "");

    //To prevent page from F5 key   
    //$(document).keydown(function (e) {
    //    return (e.which || e.keyCode) != 116;
    //});


    //To disable back button in browser
    //history.pushState(null, null, document.title);
    //window.addEventListener('popstate', function () {
    //    history.pushState(null, null, document.title);
    //});
    //window.history.forward(1);
    //document.attachEvent("onkeydown", my_onkeydown_handler);
    //function my_onkeydown_handler() {
    //    switch (event.keyCode) {
    //        case 116: // 'F5'
    //            event.returnValue = false;
    //            event.keyCode = 0;
    //            //window.status = "We have disabled F5";
    //            break;
    //    }
    //}
    //document.onmousedown = disableclick;
    ////status = "Right Click is not allowed";
    //function disableclick(e) {
    //    if (event.button == 2) {
    //        //alert(status);
    //        return false;
    //    }
    //}
});

function focusOnValidationError(focusAttr) {

    var input = $(focusAttr);

    if (input.length > 0) {
        var target_top = ($(input).offset().top * -1) + 50;
        //target_top = $('#' + id).offset().top - 50;
        $('html, body').animate({
            scrollTop: target_top,
        }, 100);

        input.focus();
        //if (div != "") {
        //    if (input[0].type == "file") {
        //        var target_left = $(input).offset().left;

        //        $('.' + div).animate({
        //            scrollLeft: target_left,
        //        }, 100);
        //    }
        //    else {   
        //        $('.' + div).animate({
        //            scrollLeft: 0,
        //        }, 100);
        //    }

        //}

        //var errorInput = $(focusAttr).find(":input.validator_element_error:visible:enabled").first();
        //$('html,body').animate({ scrollTop: errorInput.offset().top }, 200, function () {
        //    errorInput.focus();
        //});
    }
}


function locateAndfocusControl(control) {
    var input = $(control);
    if (input.length > 0) {
        var dynamicId = Math.random().toString(36).substring(7) + "div";
        input.closest("div").prop("id", dynamicId);
        location.href = "#" + dynamicId;
        console.log(input.closest("div").find("input").prop("id"));
        input.closest("div").find("input").focus();

    }
}

function openMoodle() {
    var MoodleURL = document.getElementById("moodleAnchor").getAttribute("data-url");
    var win = window.open(MoodleURL, null, 'height=600, width=800, status=yes, toolbar=no, menubar=no, location=center, scrollbar=no');
}

function blockRefreshBackAndForward() {
    //To disable back button in browser
    history.pushState(null, null, document.title);
    window.addEventListener('popstate', function () {
        history.pushState(null, null, document.title);
    });

    //To prevent page from F5 key
    $(document).keydown(function (e) {
        return (e.which || e.keyCode) !== 116;
    });
}

$(function () {
    $(document).ajaxError(function (xhr, props) {
        if (props.status === 401) {
            window.location.href = window.location.href;
        }
    });
    //blockRefreshBackAndForward();
});
function OnlyAlphanumeralsBracketsOneSpace(evt) {
    //This is for text fields which allows only Alphabets,Numbers,single Quote,Simple Brackets
    var $control = $(evt.target);
    $control.css("textTransform", "capitalize");
    var traAddr = $control.val();
    var m = traAddr.substr($control.val().length - 1, $control.val().length);
    var keyCode = (evt.which) ? evt.which : event.keyCode;
    if ((keyCode < 48 || keyCode > 57) && (keyCode < 39 || keyCode > 41) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && keyCode !== 8 && keyCode !== 32) {

        evt.preventDefault();
    }

    else if (m === " ") {
        var m = traAddr.replace(/ +/g, " ");
        $control.val(m);
    }
}

function ValidationForNameField(e) {
    ////text fields validation for Alphabets,Numbers,single Quote,Simple Brackets
    var $control = $(e.target);
    var m = $control.val();
    var regex = /^[a-zA-Z0-9'() ]*$/;
    if (!regex.test(m)) {
        $control.val('');
        return false;
    }

    if (m === null || m === "") {
        $control.val('');
        return false;
    }
    else {

        $control.css('textTransform', 'capitalize');
        var n = m.replace(/ +(?= )/g, '');
        $control.val(n);
        $control.val($.trim($control.val()));
    }
}



function AlternateIDUpperCaseFormat(obj) {
    var mystring = obj.value;

    obj.value = mystring.toUpperCase();
    return true;
}

function NameCamelCaseFormat(obj) {
    var mystring = obj.value;
    var sp = mystring.split(' ');
    var wl = 0;
    var f, r;
    var word = new Array();
    for (i = 0 ; i < sp.length ; i++) {
        f = sp[i].substring(0, 1).toUpperCase();
        r = sp[i].substring(1).toLowerCase();
        word[i] = f + r;
        word[i] = NameCamelCaseFormat1(word[i])

    }
    newstring = word.join(' ');
    obj.value = newstring;
    return true;
}

function NameCamelCaseFormat1(obj) {
    var mystring = obj;
    var sp = mystring.split('(');
    var wl = 0;
    var f, r;
    var word = new Array();
    for (j = 0 ; j < sp.length ; j++) {
        f = sp[j].substring(0, 1).toUpperCase();
        r = sp[j].substring(1).toLowerCase();
        word[j] = f + r;
        word[j] = NameCamelCaseFormat2(word[j])
    }
    newstring = word.join('(');
    obj = newstring;
    return obj;
}
function NameCamelCaseFormat2(obj) {
    var mystring = obj;
    var sp = mystring.split(')');
    var wl = 0;
    var f, r;
    var word = new Array();
    for (k = 0 ; k < sp.length ; k++) {
        f = sp[k].substring(0, 1).toUpperCase();
        r = sp[k].substring(1).toLowerCase();
        word[k] = f + r;
        word[k] = NameCamelCaseFormat3(word[k])
    }
    newstring = word.join(')');
    obj = newstring;
    return obj;
}
function NameCamelCaseFormat3(obj) {
    var mystring = obj;
    var sp = mystring.split('\'');
    var wl = 0;
    var f, r;
    var word = new Array();
    for (l = 0 ; l < sp.length ; l++) {
        f = sp[l].substring(0, 1).toUpperCase();
        r = sp[l].substring(1).toLowerCase();
        word[l] = f + r;
    }
    newstring = word.join('\'');
    obj = newstring;
    return obj;
}

/*
Generic Bootstrap Model popup 
Author: Prashanth
Date:21/01/2017
*/
function confirmModel(heading, question, cancelButtonTxt, okButtonTxt, callback) {

    var confirmModal =
         $('<div class="modal fade" id="generalModalTwoButtons" >' +
                           '<div class="popup-inner">' +
                               '<div class="ary_surecont">' +
                                   '<div class="assdate_conts">' +
                                       '<ul class="clearfix">' +
                                           '<div class="pop_ctbtn_des clearfix">' +
                                              question +
                                               '<br />' +
                                               '<br />' +
                                               '<br />' +
                                               '<input type="submit" class="popsmt_btn" value="Yes" id="btnOK">' +
                                               '<input type="submit" class="popsmt_btn pop_down popup-close" data-dismiss="modal" value="No" >' +
                                           '</div>' +
                                       '</ul>' +
                                   '</div>' +
                               '</div>' +
                           '</div>' +
                       '</div>');

    confirmModal.find('#btnOK').click(function (event) {
        callback();
        confirmModal.modal('hide');
    });

    confirmModal.modal({ backdrop: 'static', keyboard: false });
};
function PreventSpace(ControlID) {
    var m = ControlID.id;

    var TempValue = $('#' + m).val();

    //m.replace(/^0+/, '');
    var mm = TempValue.replace(/ +/g, "");

    var str = mm.replace(/[^a-zA-Z 0-9]+/g, '');

    $('#' + m).val(str);

    var Value = str.replace(/^0+/, '');
    $('#' + m).val(Value);

    if (($('#' + m).val()) < 1) {
        $('#' + m).val('');
        $('#' + m + 'Span').show();
    }
}
function alertModel(msg) {
    var confirmModal = $('<div class="modal fade" id="alertpopupModal">' +
        '<div class="popup-inner">' +
                               '<div class="ary_surecont trener_bck">' +
                                   '<div class="seach_trn">' +
                                       '<ul class="clearfix">' +
                                           '<div class="pop_ctbtn_des clearfix">' +
                                              msg +
                                               '<br />' +
                                               '<br />' +
                                               '<br />' +
                                               '<input type="submit" class="popsmt_btn" value="OK" id="btnOK">' +
                                           '</div>' +
                                       '</ul>' +
                                   '</div>' +
                               '</div>' +
                       '</div>');
    confirmModal.find('#btnOK').click(function (event) {
        confirmModal.modal('hide');
    });
    confirmModal.modal({ backdrop: 'static', keyboard: false });
}



