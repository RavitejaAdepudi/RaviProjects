﻿function LoadAssetDetails(assetId)//, logoTypeId, assetname, originalFileName, logoFilePath, alternateFileName) {
{
    $.ajax({
        type: "POST",
        url: window.LoadAssetById,
        data: { "assetId": assetId },
        dataType: "json",
        success: function (data) {
            if (data != "") {
                $("#hdnAssetId").val(assetId);
                $("#SaveButtonDiv").css("display", "none");
                $("#SubmitButtonDiv").css("display", "block");
                $("#deleteTrigger").html("Cancel");
                $("#previewTrigger").addClass('disabled').removeAttr("href");
                $('#downloadDiv').css("display", "block");
                $("#hdnAlternateFileName").val(data.AlternateFileName);
                $("#ddlLogoType").val(data.LogoTypeId).change();
                $("#txtlogoName").val(data.AssetName);
                $('#downloadLogo').attr("href", data.LogoFilePath);
            }
        },
        error: function (x, e) {
            sweetAlert("Some error occurred.");
        }
    });
}

function DeleteAssetDetails(assetId)
{
    $("#btnAction").val("Delete");
    $("#hdnAssetId").val(assetId);
    $("#hdnAlternateFileName").val("");
    $('#confirmmsg').text("Do you want to delete the logo?");
    $('#confirmpopup').show();
}

function SavebuttonVisible() {
    var result = 0;
    var FileSize = $('#txtLogoFile')["0"].files[0].size;
    if (FileSize > 300000) {
        $("#txtLogoFile").val() == "";
        result++;
    }
    else {
        var imgHeight =0;
        var imgWidth = 0;
        var imgfile = $('#txtLogoFile')["0"].files["0"];
        var img = new Image();
        img.src = window.URL.createObjectURL(imgfile);

           img.onload = function () {
                   imgHeight = img.naturalHeight;
                   imgWidth = img.naturalWidth;


                   if (imgWidth == 200 && imgHeight == 130) {
                       //upload success
                   }
                   else {
                       $('#txtLogoFile').val("");
                       result++;

                   }
                   if (result != 0) {
                       $('#alertmsg').text("Please upload a image file with size less than 300KB and 200*130 dimensions");
                       $('#alertpopup').show();
                   }
                   else {
                       $("#SaveButtonDiv").css("display", "block");
                       $("#SubmitButtonDiv").css("display", "none");
                       $('#previewTrigger').attr('disabled', false);
                       $("#downloadDiv").css("display", "none");
                       $('#downloadLogo').attr("href", "#");
                   }
           }
    }
}
function previewLogo(assetId, alternateFileName) {
    $("#LogoPreview").html("");
    $.ajax({
        type: "POST",
        url: window.PreviewLogo,
        data: { "assetId": assetId, "alternateFileName": alternateFileName },
        dataType: "json",
        success: function (data) {
            if (data != "") {
                $('#LogoPreview').prepend('<img src="data:image/png;base64,' + data + '" style="max-height: 140px;"/>')
            }
            else
            {
                $('#alertmsg').text("Image not available.");
                $('#alertpopup').show();
            }
        },
        error: function (x, e) {
            $('#alertmsg').text("Some error occurred.");
            $('#alertpopup').show();
            $("#btnAction").val("");
        }
    });
}

function PreviewSampleLogo(imgPath)
{
    $("#LogoPreview").html("");
    $('#LogoPreview').prepend('<img src="data:image/png;base64,' + imgPath + '" style="max-height: 140px;"/>');
}

var DualMultiLogoApp = function () {
    var draw = true;
    var MultiLogoDataTable = function () {
        $("#tblMultiLogo").DataTable().destroy();
        var dataTabOptions = {
          //  "scrollX": true,
            "serverSide": true,
            "processing": true,
          //  "autoWidth": true,
            "paging": true,
            "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
            "pageLength": 5,
            "searching": false,
            "ajax": {
                "url": window.GetMultiLogoList,
                "type": "POST",
                "datatype": "json",
                "data": {
                    "searchByLogoType": 0
                },
            },
            'order': [[6, 'desc']],
            columns: [
                   { title: "S.No", "data": "SerialNumber", "name": "SerialNumber"},
                   { title: "Logo Type", "data": "LogoType", "name": "LogoType"},
                   { title: "Logo Name", "data": "AssetName", "name": "AssetName"},
                   {
                       title: "Logo", "data": "", "render": function (data, type, full, meta) {
                           var imgTag = '';
                           if (full.LogoFileImage) {
                               imgTag = '<img height="50px" width="70px" src="data:image/png;base64,' + full.LogoFileImage + '" id="' + full.AssetId + '"/>';
                           }
                           else {
                               imgTag = '<a class="btn disabled" disabled=disabled href="">Not Available</a>';
                           }
                           return imgTag;
                       }
                   },
                   { title: "Status", "data": "Status", "name": "Status" },
                   { title: "Reason for rejection", "data": "Reason", "name": "Reason" },
                   { title: "Request On", "data": "CreatedOn", "name": "CreatedOn"},
            {
                title: "Action",
                "orderable": false,
                "render": function (data, type, full, meta) {
                    var columnVal = "";
                    if (full.Status == "Approved") {
                        columnVal = '<button type="button" onClick=LoadAssetDetails("' + full.AssetId + '") class="btn btn-warning btn-xs view view tooltips gridbtncustom modalViewLink" data-original-title="Edit Details">Edit</button>'
                    }
                    else if (full.Status == "Rejected") {
                        columnVal = '<button type="button" data-button="btnDelete" onClick=DeleteAssetDetails("' + full.AssetId + '") class="btn red btn-xs view view tooltips gridbtncustom modalLink" data-original-title="Delete Logo?">Delete</button>'
                    }
                    if (columnVal != "")
                        columnVal = columnVal + '<button type="button" data-toggle="modal" data-target="#divPreviewModal" onClick = previewLogo("' + full.AssetId + '","' + full.AlternateFileName + '") class="btn green btn-xs ">Preview</button>';
                    else
                        columnVal = ' <button type="button" data-toggle="modal" data-target="#divPreviewModal" onClick=previewLogo("' + full.AssetId + '","' + full.AlternateFileName + '") class="btn green btn-xs  ">Preview</button>';
                    return columnVal;
                }
            }], 
            //data-button="btnPreview" 
            "fnCreatedRow": function (nRow, aData) {
                $(nRow).attr("id", aData[0]);
                $(nRow).addClass('multsel');
            },

        }
        
        $("#tblMultiLogo").DataTable(dataTabOptions);
        $("#tblMultiLogo tbody").show();
    }

    var searchSubmitLogo = function () {
        $("#searchSubmitTrigger").off();
        $("#searchSubmitTrigger").click(function (e) {
            $("#btnAction").val("searchSubmit");
            var result = 0;
            if ($("#ddlSearchLogoType").val() == -1)
                result++;
            if (result == 0) {
                $("#tblAvailableLogo").DataTable().destroy();
                var dataTabOptions = {
                   // "scrollX": true,
                    "serverSide": true,
                    "processing": true,
                  //  "autoWidth": true,
                    "paging": true,
                    "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
                    "pageLength": 5,
                    "searching": false,
                    "ajax": {
                        "url": window.GetMultiLogoList,
                        "type": "POST",
                        "datatype": "json",
                        "data": {
                            "searchByLogoType": $("#ddlSearchLogoType").val()
                        },
                    },
                    'order': [[4, 'desc']],
                    columns: [
                           { title: "S.No", "data": "SerialNumber", "name": "SerialNumber" },
                           { title: "Logo Name", "data": "AssetName", "name": "AssetName"},
                           {
                               title: "Logo", "data": "",  "render": function (data, type, full, meta) {
                                   var imgTag = '';
                                   if (full.LogoFileImage) {
                                       imgTag = '<img height="50px" width="70px" src="data:image/png;base64,' + full.LogoFileImage + '" id="' + full.AssetId + '"/>';
                                   }
                                   else {
                                       imgTag = '<a class="btn disabled" disabled=disabled href="">Not Available</a>';
                                   }
                                   return imgTag;
                               }
                           },
                           { title: "Approved By", "data": "ApprovedBy", "name": "ApprovedBy"},
                           { title: "Approved On", "data": "CreatedOn", "name": "CreatedOn" }
                    ],
                    "fnCreatedRow": function (nRow, aData) {

                        $(nRow).attr("id", aData[0]);
                    },

                }

                $("#tblAvailableLogo").DataTable(dataTabOptions);
                $("#tblAvailableLogo tbody").show();

            }
            else {
                $('#alertmsg').text("Please select the logo type to search");
                $('#alertpopup').show();
            }
        });
    }

    var submitLogo = function () {
        $("#submitTrigger").off();
        $("#submitTrigger").click(function (e) {
            $("#btnAction").val("Submit");
            var result = 0;
            var isImgfile = true;
            if ($("#ddlLogoType").val() == -1)
                result++;
            if ($("#txtlogoName").val() == "")
                result++;
            if ($("#downloadDiv").css('display') == 'none')
                {
                if ($("#txtLogoFile").val() == "")
                    result++;
                else {
                    var file = document.getElementById("txtLogoFile").files[0];
                    var extension = file.name.substring(file.name.lastIndexOf('.'));
                    var validFileType = ".jpg , .png , .bmp, .jpeg";
                    if (validFileType.toLowerCase().indexOf(extension) < 0) {
                        result++;
                        isImgfile = false;
                    }
                    else {
                        var FileSize = $('#txtLogoFile')["0"].files[0].size;
                        if (FileSize > 300000) {
                              $("#txtLogoFile").val() == "";
                              result++;
                              isImgfile = false;
                        }
                        else {
                           
                            var imgfile = $('#txtLogoFile')["0"].files["0"];
                            var img = new Image();
                            img.src = window.URL.createObjectURL(imgfile);
                            img.onload = function () {
                                var imgHeight = img.naturalHeight;
                                var imgWidth = img.naturalWidth;
                                if (imgWidth <= 200 && imgHeight <= 130) {
                                    //upload success
                                }
                                else {
                                    $('#txtLogoFile').val("");
                                    result++;
                                    isImgfile = false;
                                }
                            }
                                
                         //   }
                        }
                    }
                }
            }
            if (result == 0) {
            $('#confirmmsg').text("Do you want to submit the logo?");
            $('#confirmpopup').show();
            }
            else {
                if (isImgfile)
                    $('#alertmsg').text("Please fill in all details");
                else
                    $('#alertmsg').text("Please upload a image file with size less than 300KB and 200*130 dimensions");
                $('#alertpopup').show();
            }
        });
    }
    var saveLogo = function () {
        $("#saveTrigger").off();
        $("#saveTrigger").click(function (e) {
            $("#btnAction").val("Save");
            var result = 0;
            if ($("#txtLogoFile").val() == "")
                result++;
            else {
                var file = document.getElementById("txtLogoFile").files[0];
                var extension = file.name.substring(file.name.lastIndexOf('.'));
                var validFileType = ".jpg , .png , .bmp, .jpeg";
                if (validFileType.toLowerCase().indexOf(extension) < 0) {
                    result++;
                }
                else {
                    var FileSize = $('#txtLogoFile')["0"].files[0].size;
                    if (FileSize > 300000) {
                        $("#txtLogoFile").val() == "";
                        result++;
                    }
                    else {
                        //complete functionality for image dimensions
                        var imgfile = $('#txtLogoFile')["0"].files["0"];
                        var img = new Image();
                        img.src = window.URL.createObjectURL(imgfile);
                        img.onload = function () {
                            var imgHeight = img.naturalHeight;
                            var imgWidth = img.naturalWidth;
                            if (imgWidth <= 200 && imgHeight <= 130) {
                                //upload success
                            }
                            else {
                                $('#txtLogoFile').val("");
                                result++;
                            }
                       }
                    }
                }
            }
            if (result == 0) {
            $('#confirmmsg').text("Do you want to save the logo?");
            $('#confirmpopup').show();
            }
            else {
                $('#alertmsg').text("Please upload a image file with size less than 300KB and 200*130 dimensions");
                $('#alertpopup').show();
            }
        });
    }

    var PreviewAsset = function () {
        $("#previewTrigger").off();
        $("#previewTrigger").click(function (e) {
            previewLogo($("#hdnAssetId").val(), $("#hdnAlternateFileName").val());
        })
    }

    var deleteLogo = function () {
        $("#deleteTrigger").off();
        $("#deleteTrigger").click(function (e) {
            if ($("#deleteTrigger").html() == "Delete") {
                $("#btnAction").val("Cancel");
                $('#confirmmsg').text("Do you want to delete the logo?");
                $('#confirmpopup').show();
            }
            else
            {
                $("#ddlLogoType").val(-1).change();
                $("#txtlogoName").val("");
                $("#txtLogoFile").val("");
                $('#previewTrigger').attr("href", "#");
                $("#SubmitButtonDiv").css("display", "none");
                $("#SaveButtonDiv").css("display", "block");
                $('#downloadLogo').attr("href", "#");
                $('#downloadDiv').css("display", "none");
                $("#btnAction").val("");
            }
        })
    }
    
    //var previewLogo = function () {
    //    $("#previewTrigger").off();
    //    $("#previewTrigger").click(function (e) {
    //        $(".imgPreview").colorbox({ rel: 'imgPreview', width: "75%", height: "75%" });
    //    });
    //}
    var submitLogoOnConfirm = function () {
        $("#confirmTrigger").off();
        $("#confirmTrigger").click(function (e) {
            $('#confirmpopup').hide();
            var file = "";
            var formData = new FormData();
            var totalFiles = document.getElementById("txtLogoFile").files.length;
            for (var i = 0; i < totalFiles; i++) {
                file = document.getElementById("txtLogoFile").files[i];
                formData.append("fileUpload", file);
            }
            formData.append("logoTypeVal", $("#ddlLogoType option:selected").text());
            formData.append("logoTypeId", $("#ddlLogoType").val());
            formData.append("assetName", $("#txtlogoName").val());
            formData.append("assetId", $("#hdnAssetId").val());
           
           
            if ($("#btnAction").val() == "Submit") {
                $("#divLoading").show();
                    $.ajax({
                        type: "POST",
                        url: window.SubmitLogoFile,
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data == 1) {
                                $("#divLoading").hide();
                                $("#ddlLogoType").val(-1).change();
                                $("#txtlogoName").val("");
                                $("#txtLogoFile").val("");
                                $('#previewTrigger').attr("href", "#");
                                var table = $('#tblMultiLogo').DataTable();
                                table.ajax.reload();
                                $("#SubmitButtonDiv").css("display", "none");
                                $("#SaveButtonDiv").css("display", "block");
                                $('#downloadLogo').attr("href", "#");
                                $('#downloadDiv').css("display", "none");
                                $('#alertmsg').text("Logo submitted for verification");
                                $('#alertpopup').show();
                                $("#hdnAssetId").val(0);
                                $("#hdnAlternateFileName").val("");
                                $("#btnAction").val("");
                            }
                            else if (data == 2) {
                                $("#divLoading").hide();
                                $('#alertmsg').text("Logo/Logo Name exists already.");
                                $('#alertpopup').show();
                                $("#btnAction").val("");
                            }
                        },
                        error: function (x, e) {
                            $("#divLoading").hide();
                            $('#alertmsg').text("Some error occurred.");
                            $('#alertpopup').show();
                            $("#btnAction").val("");
                        }
                    });
                }
            else if ($("#btnAction").val() == "Save") {
                $("#divLoading").show();
                    $.ajax({
                        type: "POST",
                        url: window.SaveLogoFile,
                        data: formData,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data == 1) {
                                $("#divLoading").hide();
                                $("#SaveButtonDiv").css("display", "none");
                                $("#SubmitButtonDiv").css("display", "block");
                                $("#deleteTrigger").html("Delete");
                                $('#alertmsg').text("Logo saved successfully");
                                $('#alertpopup').show();
                                $("#btnAction").val("");
                                $("#hdnAlternateFileName").val("");
                            }
                        },
                        error: function (x, e) {
                            $("#divLoading").hide();
                            $('#alertmsg').text("Some error occurred.");
                            $('#alertpopup').show();
                            $("#btnAction").val("");
                        }
                    });
            }
            else if ($("#btnAction").val() == "Delete") {
                $("#divLoading").show();
                $.ajax({
                    type: "POST",
                    url: window.DeleteAsset,
                    data:{"assetId": $("#hdnAssetId").val()},
                    dataType: "json",
                    success: function (data) {
                        if (data == 1) {
                            $("#divLoading").hide();
                            var table = $('#tblMultiLogo').DataTable();
                            table.ajax.reload();
                            $('#alertmsg').text("Deleted successfully");
                            $('#alertpopup').show();
                            $("#hdnAssetId").val(0);
                            $("#btnAction").val("");
                            $("#hdnAlternateFileName").val("");
                        }
                    },
                    error: function (x, e) {
                        $("#divLoading").hide();
                        $('#alertmsg').text("Some error occurred.");
                        $('#alertpopup').show();
                        $("#btnAction").val("");
                    }
                });
            }
             else if ($("#btnAction").val() == "Cancel") {
                $("#divLoading").show();
                $.ajax({
                    type: "POST",
                    url: window.RemoveAsset,
                    data: formData,
                    dataType: "json",
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        if (data == 1) {
                            $("#divLoading").hide();
                            $('#alertmsg').text("Deleted successfully");
                            $('#alertpopup').show();
                            $("#ddlLogoType").val(-1).change();
                            $("#txtlogoName").val("");
                            $("#txtLogoFile").val("");
                            $('#previewTrigger').attr("href", "#");
                            $("#SubmitButtonDiv").css("display", "none");
                            $("#SaveButtonDiv").css("display", "block");
                            $('#downloadLogo').attr("href", "#");
                            $('#downloadDiv').css("display", "none");
                            $("#hdnAssetId").val(0);
                            $("#hdnAlternateFileName").val("");
                            $("#btnAction").val("");
                        }
                    },
                    error: function (x, e) {
                        $("#divLoading").hide();
                        $('#alertmsg').text("Some error occurred.");
                        $('#alertpopup').show();
                        $("#btnAction").val("");
                    }
                });
            }
           
        });
    }

    return {

        Load: function () {
           MultiLogoDataTable();
        },
        buttonClickFunctions: function () {
            deleteLogo();
            submitLogo();
            saveLogo();
             PreviewAsset();
            submitLogoOnConfirm();
            searchSubmitLogo();
        },
    }

}();
