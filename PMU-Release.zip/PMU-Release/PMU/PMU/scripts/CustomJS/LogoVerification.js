﻿var LogoVerificationApp=function()
{

        var approveLogo = function () {
        $("#btnApproveYes").off();
        $("#btnApproveYes").click(function (e) {
            var assetId = $("#hdnAssetId").val();
            var userId = $("#hdnUserId").val();
            $.ajax({
                type: "POST",
                url: window.ApproveLogo,
                data: {"assetId":assetId,"userId":userId},
                dataType: "json",
                
                success: function (data) {
                    if (data == 1) {
                        location.reload();
                    }
                },
                error: function (x, e) {
                    alert("Some error occurred.");
                }
            });
        });
    }

        var rejectLogo = function () {
            $("#btnRejectYes").off();
            $("#btnRejectYes").click(function (e) {
                if ($("#txtReason").val() != "") {
                    var assetId = $("#hdnAssetId").val();
                    var userId = $("#hdnUserId").val();
                    $.ajax({
                        type: "POST",
                        url: window.RejectLogo,
                        data: { "assetId": assetId, "reason": $("#txtReason").val(), "userId": userId },
                        dataType: "json",

                        success: function (data) {
                            if (data == 1) {
                                location.reload();
                            }
                        },
                        error: function (x, e) {
                            alert("Some error occurred.");
                        }
                    });
                }
                else
                {
                    alert("Please enter reason");
                }
            });
        }
        var cancelApprove = function () {
            $("#btnApproveNo").off();
            $("#btnApproveNo").click(function (e) {
                var x = confirm('Are You sure want to exit:');
                if (x) window.close();
            });
        }
        var cancelReject = function () {
            $("#btnRejectNo").off();
            $("#btnRejectNo").click(function (e) {
                var x = confirm('Are You sure want to exit:');
                if (x) window.close();
            });
        }
    return {

        buttonClickFunctions: function () {
            approveLogo();
            rejectLogo();
            cancelApprove();
            cancelReject();
        },
    }

}();