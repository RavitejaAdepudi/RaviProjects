﻿//Partial View


function saveLocation() {
    var templocationtarget = parseInt($('#LocationTarget').val());
    var templocationname = $('#LocationName').val();
    var temppartner = $('#TargetTrainingPartnerID').val();
    var tempproject = $('#TargetProjectID').val();
    if (templocationtarget != "" && templocationtarget != 0 && templocationname != "" && templocationname != null) {
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            async: true,
            url: urltargetSavelocation,
            data: { Locname: templocationname, AllocatedTarget: templocationtarget, PartnerID: temppartner, ProjectID: tempproject },
            success: function (result) {
                $('#dvViewProject').html(result);
                $('#clspopup1').show();
                var locationresponse = $('#LocationResponse').val();
                $('#LocationTarget').val('');
                $('#LocationName').val('');
                alertModel(locationresponse);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    else {
        alertModel("please Enter Location Name/Target");
    }
}

//Job Role details
function jobroleDetails() {
    var temppartnerid, templocationid, tempprojectid, tempjobroleid;
    var _TempTableTrCount = $("#LocationDetails tbody tr").length;
    if ($($($('#LocationDetails tbody tr')).find('td input[type=radio]')).is(':checked') == true) {
        var _TempTableTrCount = $("#LocationDetails tbody tr").length;
        var partnername = "", partnerid = "";
        if (_TempTableTrCount > 0) {
            for (i = 0; i < (_TempTableTrCount) ; i++) {
                if ($($($('#LocationDetails tbody tr')[i]).find('td input[type=radio]')).length > 0) {
                    if ($($($('#LocationDetails tbody tr')[i]).find('td input[type=radio]')[0]).is(':checked') == true) {
                        temppartnerid = $($($('#LocationDetails tbody tr')[i]).find('td input[type=hidden]')[0]).val();
                        templocationid = $($($('#LocationDetails tbody tr')[i]).find('td input[type=hidden]')[1]).val();
                        //tempjobroleid = $($($('#LocationDetails tbody tr')[i]).find('td input[type=hidden]')[2]).val();
                    }
                }
            }
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: urltargetJobRoleDetails,
                async: false,
                data: { PartnerID: temppartnerid, ProjectID: $("#ProjectID").val(), locationid: templocationid },
                success: function (result) {
                    $('#divViewJobRole').html(result);
                    $('#locations_jrt_popup').show();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alertModel("Some Error is Occurred, Please try after some time");
                }
            });
        }
    }
    else {
        alertModel("please Select Location ID - Location Name to View Job Role Details");
    }
}

//Script to delete existing job role.
function removeProjectLocation(projectID, locationID) {
    var callBack = function () {
        $("#divLoading").show();
        $.ajax({
            type: "GET",
            cache: false,
            url: urlremoveProjectLocation,
            contentType: 'application/json; charset=utf-8',
            async: true,
            data: { projectID: projectID, locationID: locationID },
            success: function (data) {
                $("#divLoading").hide();
                $("#divProjectJobRoleTarget").html(data.projectJobRolePartail);
                $("#divLocationJobRoleTarget").html(data.locationJobRolePartial);
                alertModel(data.status);
                $('[data-toggle="popover"]').popover();
            },
            error: function (jqXHR, exception) {
                $("#divLoading").hide();
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    confirmModel("Confirmation", "Are you sure you want to Delete Location?", "Cancel", "Ok", callBack);
}
