﻿
///*
// * date created: 2017-02-21
// * ver20170227
// * Created by Prashanth.
// */


$(document).ready(function () {
    $(document).ready(function () {
        $('[data-toggle="popover"]').popover();
    });
    $(".seldrop").change(function () {
        $(this).valid();
    });
    if ($("#IsSelectorEnterAddress").val() === "true" || $("#IsSelectorEnterAddress").val() === "True") {
        $("#radio_SelectAddress").prop("checked", true);
    }
    else {
        $("#radio_EnterAddress").prop("checked", true);
    }
    if ($("#radio_SelectAddress").is(":checked")) {
        SelectAddressValid();
    }
    else {
        EnterAddressValid();
    }

    $("#PINCode").on("blur", function () {
        var pinCode = $("#PINCode").val();
        var isChecked = $("#radio_SelectAddress").is(":checked");
        if (pinCode.length === 6)
            // setTimeout(PINCode(pinCode), 500000);
            PINCode(pinCode);
        else {
            PINCode(-1);
        }
    });

    $('#Locality').on('change', function () {
        var pinCode = $('#PINCode').val();
        var isChecked = $('#radio_SelectAddress').is(':checked');
        var locality = $('#Locality').val();
        if (pinCode.length == 6)
            PostOffice(pinCode, locality);

    });

    $('#PostOffice').on('change', function () {
        $("#tPostOffice").val($("#PostOffice option:selected").text());
        var pinCode = $('#PINCode').val();
        var isChecked = $('#radio_SelectAddress').is(':checked');
        var locality = $('#Locality').val();
        var postOffice = $('#PostOffice').val();
        if (pinCode.length == 6)
            CityVillageTown(pinCode, locality, postOffice);

    });

    $('#TraineeVillageTownCity').on('change', function () {
        var pinCode = $('#PINCode').val();
        var isChecked = $('#radio_SelectAddress').is(':checked');
        var locality = $('#Locality').val();
        var postOffice = $('#PostOffice').val();
        var village = $('#TraineeVillageTownCity').val();
        if (pinCode.length == 6)
            SubDistrict(pinCode, locality, postOffice, village);

    });

    $('#TraineeSubDistrict').on('change', function () {
        var pinCode = $('#PINCode').val();
        var isChecked = $('#radio_SelectAddress').is(':checked');
        var locality = $('#Locality').val();
        var postOffice = $('#PostOffice').val();
        var village = $('#TraineeVillageTownCity').val();
        var subDistrict = $('#TraineeSubDistrict').val();
        if (pinCode.length == 6)
            StateDetails(pinCode, locality, postOffice, village, subDistrict);

    });
    $("#TraineeSubDistrictOthers").on("change", function () {

        $("#tTraineeSubDistrict").val($("#TraineeSubDistrictOthers").val());
    });

    $("#radio_SelectAddress").click(function () {
        SelectAddressValid();
        var pinCode = $("#PINCode").val();
        if (pinCode.length === 6)
            PINCode(pinCode);
        else
            PINCode(-1);
        //Constituency(-1);

    });

    $("#radio_EnterAddress").click(function () {
        EnterAddressValid();
        //var pinCode = $('#PINCode').val();
        //if (pinCode.length == 6)
        //    PINCode(pinCode);
        //else
        PINCode(-1);
        //Constituency(-1);
        //District(-1);
        //State();

    });

    $("#TraineeState").on("change", function () {
        var stateId = $("#TraineeState").find(":selected").val();
        var isChecked = $("#radio_EnterAddress").is(":checked");
        var pinCode = $('#PINCode').val();
        var locality = $('#Locality').val();
        var postOffice = $('#PostOffice').val();
        var subDistrict = $('#TraineeSubDistrict').val();
        var village = $('#TraineeVillageTownCity').val();
        Constituency(stateId);
        GeoSpecialDetails(1, stateId);
        if (isChecked)
            District(stateId);
        else
            DistrictDetails(pinCode, locality, postOffice, village, subDistrict, stateId);
    });

    $("#TraineeDistrict").on("change", function () {
        var districtId = $("#TraineeDistrict").find(":selected").val();
        GeoSpecialDetails(2, districtId);
    });

    $("#Locality").on("change", function () {

        var localityIndex = $("#Locality").val();
        if (localityIndex === -1) {
            $("#localityDDLValidationError").show();
        }
        else {
            $("#localityDDLValidationError").hide();
        }
    });
    $("#LocalityOthers").on("change", function () {

        $("#tLocality").val($("#LocalityOthers").val());
    });

    $("#TraineeVillageTownCity").on("change", function () {

        var localityIndex = $("#TraineeVillageTownCity").val();
        if (localityIndex === -1) {
            $("#TraineeVillageTownCityValidationError").show();
        }
        else {
            $("#TraineeVillageTownCityValidationError").hide();
        }
    });

    $("#PostOffice").on("change", function () {

        var localityIndex = $("#PostOffice").val();
        if (localityIndex === -1) {
            $("#PostOfficeValidationError").show();
        }
        else {
            $("#PostOfficeValidationError").hide();
        }
    });
    $("#PostOfficeOthers").on("change", function () {

        $("#tPostOffice").val($("#PostOfficeOthers").val());
    });

    $("#TraineeSubDistrict").on("change", function () {

        var localityIndex = $("#TraineeSubDistrict").val();
        if (localityIndex === -1) {
            $("#TraineeSubDistrictOthersValidationError").show();
        }
        else {
            $("#TraineeSubDistrictOthersValidationError").hide();
        }
    });

    $("#radio_SelectAddress").click(function () {

        SelectAddressValid();
        var pinCode = $("#PINCode").val();
        if (pinCode.length === 6)
            PINCode(pinCode);
        else
            PINCode(-1);
        //Constituency(-1);

    });

    $("#radio_EnterAddress").click(function () {
        EnterAddressValid();
        //var pinCode = $('#PINCode').val();
        //if (pinCode.length == 6)
        //    PINCode(pinCode);
        //else
        PINCode(-1);
        //Constituency(-1);
        //District(-1);
        //State();

    });
    if ($(".selectpicker") != undefined) {
        $(".selectpicker").selectpicker("refresh");
        $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
    }
});
function IsAlphaNumericSpaceAllowOne(evt) {
    var TraAddr = $('#TraineeAddressLine1').val();
    var m = TraAddr.substr($('#TraineeAddressLine1').val().length - 1, $('#TraineeAddressLine1').val().length);
    var keyCode = (evt.which) ? evt.which : event.keyCode;
    if ((keyCode < 48 || keyCode >= 58) &&
        (keyCode < 65 || keyCode > 90) &&
        (keyCode < 97 || keyCode >= 123) &&
        (keyCode != 32) && (keyCode != 45) &&
         keyCode != 47 && keyCode != 46 &&
         keyCode != 64 && keyCode != 44 && keyCode != 8 &&
         keyCode != 35) {
        evt.preventDefault();
    }

    else if (m == " ") {
        var m = TraAddr.replace(/ +/g, " ");

        $('#TraineeAddressLine1').val(m);
    }
}

function GeoSpecialDetails(isStateorDistrict, stateorDistrictId) {
    var url = $("#lblState").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { IsStateorDistrict: isStateorDistrict, StateorDistrictId: stateorDistrictId },
        success: function (data) {

            if (isStateorDistrict === 1) {
                if (data !== "N") {
                    $("#lblState").text(data);
                    $("#lblDistrict").text("");
                }
                else {
                    $("#lblState").text("");
                    $("#lblDistrict").text("");
                }
            }
            else if (isStateorDistrict === 2) {
                if (data !== "N") {
                    $("#lblDistrict").text(data);
                }
                else
                    $("#lblDistrict").text("");
            }
            else {
                $("#lblState").text("");
                $("#lblDistrict").text("");
            }
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#divLoading").hide();
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertpopup").show();
        }
    });
}

function State() {
    var url = $("#stateurl").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        //data: { PINCode: pinCode },
        success: function (data) {
            var options = '';
            $.each(data, function (key, value) {
                options += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeState").html(options);
            $(".selectpicker").selectpicker("refresh");
            $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#divLoading").hide();
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertpopup").show();
        }
    });
    //$('#TraineeState').selectpicker('refresh');
}

function Constituency(stateId) {
    var url = $("#constituencyurl").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { StateId: stateId },
        success: function (data) {

            var options = '';
            $.each(data, function (key, value) {
                options += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#Constituency").html(options);
            $(".selectpicker").selectpicker("refresh");
            $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();

        },
        error: function (x, e) {
            $("#divLoading").hide();
            //alert("The call to the server side failed. " + x.responseText);
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertpopup").show();
        }
    });
    //$('#Constituency').selectpicker('refresh');
}

function District(stateId) {
    var url = $("#districturl").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { StateId: stateId },
        success: function (data) {

            var options = '';
            $.each(data, function (key, value) {
                options += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeDistrict").html(options);
            $(".selectpicker").selectpicker("refresh");
            $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#divLoading").hide();
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertpopup").show();
        }
    });
    //$('#TraineeDistrict').selectpicker('refresh');
}

function PINCode(pinCode) {

    var url = $("#pincodeurl").data("action-url");
    $("#divLoading").show();

    //        setTimeout(
    //function () {
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { PINCode: pinCode },
        success: function (data) {
            var options1 = "";
            $.each(data.TraineeStateList, function (key, value) {
                options1 += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeState").html(options1);

            var options2 = "";
            $.each(data.TraineeDistrictList, function (key, value) {
                options2 += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeDistrict").html(options2);

            var options3 = "";
            $.each(data.TraineeSubDistrictList, function (key, value) {
                options3 += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeSubDistrict").html(options3);

            var options4 = "";
            $.each(data.TraineeVillageTownCityList, function (key, value) {
                options4 += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#TraineeVillageTownCity").html(options4);

            var options5 = "";
            $.each(data.PostOfficeList, function (key, value) {
                options5 += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });

            $("#PostOffice").html(options5);

            var options = "";
            $.each(data.LocalityList, function (key, value) {
                options += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
            });
            $("#Locality").html(options);
            // if (pinCode.length == 6 && (data.TraineeStateList.length === 1 || data.TraineeDistrictList.length === 1 || data.TraineeSubDistrictList.length === 1 || data.TraineeVillageTownCityList.length === 1 || data.PostOfficeList.length === 1 || data.LocalityList.length === 1)) {
            if (pinCode.length == 6 && data.LocalityList.length === 1) {
                EnterAddressValid();
                District(-1);
                Constituency(-1);
                State();
                $("#radio_EnterAddress").prop("checked", "checked");

                $("#alertmsg").text("Pincode does not exists in our system. If your pincode is still correct, please proceed by entering address details in the Enter Domicile Address space.");
                $("#alertpopup").show();
            }
                //  else if (pinCode.length == 6 && (data.TraineeStateList.length > 1 && data.TraineeDistrictList.length > 1 || data.TraineeSubDistrictList.length > 1 || data.TraineeVillageTownCityList.length > 1 || data.PostOfficeList.length > 1 || data.LocalityList.length > 1)) {
            else if (pinCode.length == 6 && (data.LocalityList.length > 1)) {
                SelectAddressValid();
                Constituency(-1);
                $("#radio_SelectAddress").prop("checked", "checked");
            }
            else {
                //District(-1);
                Constituency(-1);
                State();
            }
            $(".selectpicker").selectpicker("refresh");
            $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#divLoading").hide();
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertpopup").show();
        }
    });
    //}, 2000);

    //$('#TraineeState').selectpicker('refresh');
    //$('#TraineeDistrict').selectpicker('refresh');
    //$('#TraineeSubDistrict').selectpicker('refresh');
    //$('#TraineeVillageTownCity').selectpicker('refresh');
    //$('#PostOffice').selectpicker('refresh');
    //$('#Constituency').val(null);
    //$('.selectpicker').selectpicker('refresh');
    //$('#Constituency').selectpicker('refresh');
}

function PostOffice(pinCode, locality) {
    var url = $("#Locality").data("action-url");
    $('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: 'json',
        async: true,
        // url:url,
        data: { PINCode: pinCode, Locality: locality },
        success: function (data) {
            var options = '';
            $.each(data, function (key, value) {
                options += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });

            $("#PostOffice").html(options);
            $('.selectpicker').selectpicker('refresh');
            $('.selectpicker').parents('form:first').validate().settings.ignore = ':not(select:hidden, input:visible, textarea:visible)';
            $('#divLoading').hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $('#divLoading').hide();
            $('#alertmsg').text('The call to the server side failed.' + x.responseText);
            $('#alertpopup').show();
        }

    });

}

function CityVillageTown(pinCode, locality, postOffice) {
    var url = $("#PostOffice").data("action-url");
    $('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: 'json',
        async: true,
        // url:url,
        data: { PINCode: pinCode, Locality: locality, PostOffice: postOffice },
        success: function (data) {
            var options = '';
            $.each(data, function (key, value) {
                options += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });

            $("#TraineeVillageTownCity").html(options);
            $('.selectpicker').selectpicker('refresh');
            $('.selectpicker').parents('form:first').validate().settings.ignore = ':not(select:hidden, input:visible, textarea:visible)';
            $('#divLoading').hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $('#divLoading').hide();
            $('#alertmsg').text('The call to the server side failed.' + x.responseText);
            $('#alertpopup').show();
        }

    });
}

function SubDistrict(pinCode, locality, postOffice, village) {
    var url = $("#TraineeVillageTownCity").data("action-url");
    $('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: 'json',
        async: true,
        // url:url,
        data: { PINCode: pinCode, Locality: locality, PostOffice: postOffice, Village: village },
        success: function (data) {

            var options = '';
            $.each(data, function (key, value) {
                options += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });

            $("#TraineeSubDistrict").html(options);
            $('.selectpicker').selectpicker('refresh');
            $('.selectpicker').parents('form:first').validate().settings.ignore = ':not(select:hidden, input:visible, textarea:visible)';
            $('#divLoading').hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $('#divLoading').hide();
            $('#alertmsg').text('The call to the server side failed.' + x.responseText);
            $('#alertpopup').show();
        }

    });

}

function StateDetails(pinCode, locality, postOffice, village, subDistrict) {
    var url = $("#TraineeSubDistrict").data("action-url");
    $('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: 'json',
        async: true,
        // url:url,
        data: { PINCode: pinCode, Locality: locality, PostOffice: postOffice, Village: village, SubDistrict: subDistrict },
        success: function (data) {
            var options = '';
            $.each(data, function (key, value) {
                options += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });

            $("#TraineeState").html(options);
            $('.selectpicker').selectpicker('refresh');
            $('.selectpicker').parents('form:first').validate().settings.ignore = ':not(select:hidden, input:visible, textarea:visible)';
            $('#divLoading').hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $('#divLoading').hide();
            $('#alertmsg').text('The call to the server side failed.' + x.responseText);
            $('#alertpopup').show();
        }

    });

}

function DistrictDetails(pinCode, locality, postOffice, village, subDistrict, state) {
    var url = $("#TraineeState").data("action-url");
    $('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: 'json',
        async: true,
        // url:url,
        data: { PINCode: pinCode, Locality: locality, PostOffice: postOffice, Village: village, SubDistrict: subDistrict, State: state },
        success: function (data) {

            var options = '';
            $.each(data, function (key, value) {
                options += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });

            $("#TraineeDistrict").html(options);
            $('.selectpicker').selectpicker('refresh');
            $('.selectpicker').parents('form:first').validate().settings.ignore = ':not(select:hidden, input:visible, textarea:visible)';
            $('#divLoading').hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $('#divLoading').hide();
            $('#alertmsg').text('The call to the server side failed.' + x.responseText);
            $('#alertpopup').show();
        }

    });

}


function SelectAddressValid() {

    $("#LocalityOthersValidationError").hide();
    $("#TraineeVillageTownCityOthersValidationError").hide();
    $("#PostOfficeOthersValidationError").hide();
    $("#TraineeSubDistrictOthersValidationError").hide();
    $("#PostOfficeOthers").val("");
    $("#LocalityOthers").val("");
    $("#TraineeVillageTownCityOthers").val("");
    $("#TraineeSubDistrictOthers").val("");


    $("#PostOffice").prop("disabled", false);
    $("#Locality").prop("disabled", false);
    $("#TraineeVillageTownCity").prop("disabled", false);
    $("#TraineeSubDistrict").prop("disabled", false);

    $("#PostOfficeOthers").prop("disabled", true);
    $("#LocalityOthers").prop("disabled", true);
    $("#TraineeVillageTownCityOthers").prop("disabled", true);
    $("#TraineeSubDistrictOthers").prop("disabled", true);

    $("#IsSelectorEnterAddress").val("true");
}

function EnterAddressValid() {

    $("#localityDDLValidationError").hide();
    $("#TraineeVillageTownCityValidationError").hide();
    $("#PostOfficeValidationError").hide();
    $("#TraineeSubDistrictOthersValidationError").hide();
    $("#TraineeSubDistrictValidationError").hide();

    $("#PostOffice").prop("disabled", true);
    $("#Locality").prop("disabled", true);
    $("#TraineeVillageTownCity").prop("disabled", true);
    $("#TraineeSubDistrict").prop("disabled", true);

    $("#PostOfficeOthers").prop("disabled", false);
    $("#LocalityOthers").prop("disabled", false);
    $("#TraineeVillageTownCityOthers").prop("disabled", false);
    $("#TraineeSubDistrictOthers").prop("disabled", false);

    $("#IsSelectorEnterAddress").val("false");
}

function DomanicileValue(e) {

    var keyCode = e.which;
    //alert(keyCode);
    if ((keyCode < 48 || keyCode >= 58) && (keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode >= 123) && (keyCode != 32) && (keyCode != 45) && keyCode != 8 &&
    (keyCode != 38) && (keyCode != 40) && (keyCode != 41) && (keyCode != 47) && (keyCode != 46)) {
        e.preventDefault();
        return false;
    } else {
        return true;
    }
}

function DomanicileAddressValidation(controlId, errorControlId) {

    var m = controlId.id;

    var tempValue = $("#" + m).val();
    var mm = tempValue.replace(/ +/g, " ");
    var str = mm.replace(/[^a-zA-Z()/.]+/g, " ");
    $("#" + m).val(str);


    $("#" + m).val($.trim($("#" + m).val()));


    if ($("#" + m).val() == "") {
        $("#" + errorControlId).show();
    }

    else {
        $("#" + errorControlId).hide();
    }
}
function PincodeValidation() {
    var traAddr = $("#PINCode").val();

    var numericReg = new RegExp("^\[1-9]{1}[0-9]{5}$");

    if ($("#PINCode").val().length > 0 && !(numericReg.test(traAddr))) {
        // alert("All the text boxes must have numeric values!");
        $("#alertmsgbutton").data("focus-control", "PINCode");
        $("#alertmsg").text("Enter 6 digit Pincode.");
        $("#alertpopup").show();

        return false;
    }
}

function locationjobRoleChange() {
    $('#btnLocationJobRoleAdd').text('Add');
    $('#txtLocationJobRoleTarget').val('');
}
function addLocationJobRole() {
    debugger
    var LocationJobRoleID = $('#ddlLocationJobRole').val();
    var errorMessage = "";
    if (LocationJobRoleID == '') {
        errorMessage = "Please select JobRole";
        errorMessage += "</br>";
    }
    if ($('#txtLocationJobRoleTarget').val().trim() == '') {
        errorMessage += "Please select the Location Target";
        errorMessage += "</br>";
    }
    //if (parseInt($('#txtLocationJobRoleTarget').val()) <= 0) {
    //    errorMessage += "Job Role Location Target should be greater than zero";
    //    errorMessage += "</br>";
    //}
    if (errorMessage == "") {
        if ($("#txtLocationID").val() == undefined || $("#txtLocationID").val() == '') {
            var locationID = 0
        }
        else {
            var locationID = $("#txtLocationID").val();
        }
        var dataToSend = { JobRoleID: $("#ddlLocationJobRole").val(), SelectedJobRolesNames: $("#ddlLocationJobRole :selected").text(), JobRoleTarget: $("#txtLocationJobRoleTarget").val(), LocationID: $("#txtLocationID").val(), Status: 'N' };
        if ($("#btnLocationJobRoleAdd").text() == 'Edit') {
            $.ajax({
                type: "GET",
                cache: false,
                url: EditLocationJobRole,
                contentType: 'application/json; charset=utf-8',
                async: true,
                data: dataToSend,
                success: function (data) {
                    if (data.length != 0) {
                        if (data.IsValid == false) {                           
                            alertModel(data.validationMessage);
                        }
                        else {
                            $("#ddlLocationJobRole").val('');
                            $("#txtLocationJobRoleTarget").val('');
                            $("#divLocationJobRole").html(data);
                            //$("#btnLocationJobRoleAdd").text('Add');
                            if ($("#hdnIsEdit").val() == "true") {
                                $("#divLocationJobRole").html(data.JobRoleResult);
                                $("#divProjectJobRoleTarget").html(data.projectJobRoleResult);
                                $("#divLocationJobRoleTarget").html(data.locationJobRoleResult);
                            }
                            else {
                                $("#divLocationJobRole").html(data);
                            }
                        }
                    }
                },
                error: function (x, e) {
                    alertModel("Some Error is Occurred, Please try after some time");
                }
            });
        }
        else {
            $.ajax({
                type: "POST",
                cache: false,
                url: AddLocationJobRole,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(dataToSend),
                success: function (data) {
                    if (data.length != 0) {
                        if (data == 'Exists') {
                            alertModel("This Job Role Id is already selected. Please select another");
                        }
                        else if (data.IsValid == false) {
                            alertModel(data.validationMessage);
                        }
                        else {
                            $("#ddlLocationJobRole").val('');
                            $("#txtLocationJobRoleTarget").val('');
                            //$("#divLocationJobRole").html(data);
                            if ($("#hdnIsEdit").val() == "true") {
                                $("#divLocationJobRole").html(data.JobRoleResult);
                                $("#divProjectJobRoleTarget").html(data.projectJobRoleResult);
                                $("#divLocationJobRoleTarget").html(data.locationJobRoleResult);
                            }
                            else {
                                $("#divLocationJobRole").html(data);
                            }
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alertModel("Some Error is Occurred, Please try after some time");
                }
            });
        }
        $("#ddlLocationJobRole").prop("disabled", false);
    }
    else {
        alertModel(errorMessage);
    }
}
function removeLocation(id) {
    var callBack = function () {
        $.ajax({
            type: "GET",
            cache: false,
            url: RemoveLocationJobRole,
            contentType: 'application/json; charset=utf-8',
            async: true,
            data: { JobRoleID: id, locationID: $("#txtLocationID").val() },
            success: function (data) {
                if (data.isDataBaseDelete == true) {
                    $("#divLocationJobRole").html(data.partialResult);
                    $("#divLocationJobRoleTarget").html(data.locationJobRolePartial);
                    $("#divProjectJobRoleTarget").html(data.projectJobRolePartail);
                    alertModel(data.status);
                }
                else {
                    $("#divLocationJobRole").html(data.partialResult);
                    alertModel(data.status);
                }
                $('[data-toggle="popover"]').popover();
            },
            error: function (x, e) {
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    confirmModel("Confirmation", "Are you sure you want to Delete Location Job Role?", "Cancel", "Ok", callBack);
}
function editLocationJobRole(id, target) {
    $('#txtLocationJobRoleTarget').val(target);
    $('#ddlLocationJobRole').val(id);
    $("#btnLocationJobRoleAdd").text('Edit');
    $("#ddlLocationJobRole").attr("disabled", "disabled");
}
function formSubmit() {
    //var $form = $(this);
    var $form = $('#TargetAllocationModel');
    if (!$form.valid()) {
        var validator = $('#TargetAllocationModel').validate();
        var errors = validator.errorList; //get the error elements, the actual labels
    }
    $($form).submit();
}

function loadLocationDetails(isLoad, id, isViewLocation) {
   
    $.ajax({
        type: "GET",
        cache: false,
        url: LoadLocationDetails,
        contentType: "application/json; charset=utf-8",
        async: false,
        data: { isLoadLocation: isLoad, locationID: id, projectID: $('#ProjectID').val(), isViewLocation:isViewLocation },
        success: function (data) {
            if (data.length != 0) {
                $('#divAddLocation').html(data);
                $('#divAddLocation').modal({ backdrop: 'static', keyboard: false, show: true });
                if (isLoad) {
                    $('#divLocations').find('input, textarea, button, select').not('.editableHC').prop('disabled', true);
                    $('#divLocationAddress').find('input, textarea, button, select').not('.editableHC').prop('disabled', true);
                    if (isViewLocation) {
                        $('#divJobRoles').find('input, textarea, button, select,image').prop('disabled', true);
                        $('#divContacts').find('input, textarea, button, select,image').prop('disabled', true);
                    }
                }
                else {
                    $('#divLocations').find('input, textarea, button, select').prop('disabled', false);
                    $('#divLocationAddress').find('input, textarea, button, select').prop('disabled', false);
                }
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}



$("#formLocationJobRole").submit(function (event)
{
    var IsHostelAvailableMale = $("input[name='IsHostelFacilityMale']:checkbox:checked").length;
    var IsHostelAvailableFemale = $("input[name='IsHostelFacilityTransgender']:checkbox:checked").length;
    var IsHostelAvailableTransgender = $("input[name='ISHostelFacilityFemale']:checkbox:checked").length;
    if (IsHostelAvailableMale > 0 || IsHostelAvailableFemale > 0 || IsHostelAvailableTransgender>0)
    {
        var hostelCapacity = $('#hostelFacility').val() == "" ? 0 : $('#hostelFacility').val();
        if (hostelCapacity <= 0) {
            alertModel("Please Enter Hostel Capacity");
            return false;
        }
        else if (consumedHostelCapacity < hostelCapacity) {
            alertModel("Hostel Capacity has been consumed more than required. Please select higher value.");
            return false;
        }
   }




    /* stop form from submitting normally */
    event.preventDefault();
    var $form = $(this);
    var tblContact = $form.find("#tblContact");
    if (!$form.valid()) {
        var validator = $('#TargetAllocationModel').validate();
        var errors = validator.errorList; //get the error elements, the actual labels
    }
    var isSpocSelected = false;
    $(tblContact).find('tr').each(function () {
        var row = $(this);
        if (row.find('input[type="radio"]').is('disabled')) {
            row.find('input[type="radio"]').disabled = false;
        }
        if (row.find('input[type="radio"]').is(':checked')) {
            isSpocSelected = true;
            $("#SelectedSPOCID").val(row.find('td input[type=hidden]').val());
        }
    });
    //To Searialize read only values
    var proxy = $(this).serialize;
    $.fn.serialize = function () {
        var inputs = this.find(':disabled');
        inputs.prop('disabled', false);
        var serialized = proxy.apply(this, arguments);
        inputs.prop('disabled', true);
        return serialized;
    };
    if (isSpocSelected) {
        var url = $form.attr('action');
        $.ajax({
            type: "POST",
            cache: false,
            url: url,
            data: $(this).serialize(), // serializes the form's elements.
            success: function (data, status, request) {
                if (data.Status == 'AddedSuccessfully') {
                    $("#divLocationJobRoleTarget").html(data.locationJobRoleResult);
                    $("#divProjectJobRoleTarget").html(data.projectJobRolePartail);
                    $("#divAddLocation").modal('hide');
                    alertModel("Location Details Saved Successfully");
                }
                else if (data.Status == 'Failure') {
                    alertModel("Unable to save Location, Please try after sometime.");
                }
                else {
                    alertModel(data.InfoMessage);
                }
            },
            beforeSend: function (xhr) {
                $("#divLoading").show();
            },
            complete: function () {
                $("#divLoading").hide();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $("#divLoading").hide();
            }
        });
    }
    else {
        alertModel("Please select the SPOC for selected contacts");
    }
    $('[data-toggle="popover"]').popover();
});

function closeModel(id) {
    $('#'+id).modal('hide');
}

