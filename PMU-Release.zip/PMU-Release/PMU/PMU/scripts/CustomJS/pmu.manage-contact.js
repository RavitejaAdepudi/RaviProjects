﻿$(document).ready(function () {
    contactlist();

    $("#btnVerifyAadhaar1").on("click", function () {
        AadharValidationStatusCheckForEdit();
    });

    $("#btnVerifyAadhaar").on("click", function () {
        AadharValidationCheck();
    });

    var OTPTimer;
    $("#btnGenerateResendOTP").on("click", function () {
        GetMobileOTP();
    });

    $("#btnGenerateOTPForEdit").on("click", function () {
        GetMobileOTPForEdit();
    });

    $("#EnterOTP").on("change", function () {
        var mobileNo = $("#ManageMobileNumber").val();
        var enterOTP = $("#EnterOTP").val();
        if (mobileNo.length == 10 && enterOTP.length == 4)
            EnterOTPCheck(enterOTP);
    });

    $("#txtenterOtp").on("change", function () {
        var mobileNo = $("#txtMobileNumber").val();
        var enterOTP = $("#txtenterOtp").val();
        if (mobileNo.length == 10 && enterOTP.length == 4)
            EnterOTPCheckEdit(enterOTP);
    });

    $("#ContactNameLocation").on("change", function () {
        $("#ErrorMessageForName").hide();
    });

    $("#AddBatchGender").on("change", function () {
        if ($("#AddBatchGender").val() != '-1') {
            $("#ErrorMessageForGender").hide();
        }

        //if ($('#AddBatchGender option:selected').text() == "Male") {
        //    $(".genper").not(".male_des").hide();
        //    $(".male_des, .male_cont").show();
        //    $(".female_cont, .transgender_cont").hide();
        //}
        //else if ($('#AddBatchGender option:selected').text() == "Female") {
        //    $(".genper").not(".female_des").hide();
        //    $(".female_des, .female_cont").show();
        //    $(".male_cont, .transgender_cont").hide();
        //}
        //else if ($('#AddBatchGender option:selected').text() == "Transgender") {
        //    $(".genper").not(".transgender_des").hide();
        //    $(".transgender_des, .transgender_cont").show();
        //    $(".female_cont, .male_cont").hide();
        //}
        //else {
        //    $(".male_des, .male_cont").hide();
        //    $(".female_des, .female_cont").hide();
        //    $(".transgender_des, .transgender_cont").hide();
        //}

    });

    var aadhaarStatus = $("#AadhaarVerificationStatus").val();

    $("#AadhaarVerificationStatusId").val(aadhaarStatus);

    var MobileStatus = $("#MobileOTPVerificationStatus").val();

    $("#MobileOTPVerificationStatusId").val(MobileStatus);

    $("#btnSaveButton").click(function () {
       
        $('#divLoading').show();
        var isSubmitted = false;
        var isValid = mandatoryFieldCheck();
        if (isValid && !isSubmitted) {
            submitManageContactForm();
            isSubmitted = true;
        }
        else {
            
            $('#divLoading').hide();
            $("#alertmsg").text("Please Enter/Select All Mandatory Fields");
            $("#alertValidationPopup").show();
        }

    });

    $("[data-popup-open]").on("click", function (e) {
        var targetedPopupClass = $(this).attr("data-popup-open");
        //$("[data-popup=\"" + targetedPopupClass + "\"]").fadeIn(350);
        e.preventDefault();
        if ($(this).data("function")) {
            eval($(this).data("function") + "(\"" + $(this).data("id") + "\")");
            $("[data-popup=\"" + targetedPopupClass + "\"]").fadeIn(350);
        } else {
            $("[data-popup=\"" + targetedPopupClass + "\"]").fadeIn(350);
        }
    });

    $("[data-popup-close]").on("click", function (e) {
        var targetedPopupClass = $(this).data("popup-close");
        $("[data-popup=\"" + targetedPopupClass + "\"]").fadeOut(350);

        e.preventDefault();
        if ($(e.target).data("chain-function") !== "") {
            eval($(e.target).data("chain-function") + "()");
        }

        if ($(e.target).data("focus-control") !== "") {
            var focuscontrol = $(e.target).data("focus-control");
            $("#" + focuscontrol).focus();
            $(e.target).data("focus-control", "");
        }

        if ($(e.target).data("focus-control-refid") !== "") {
            var focusControl = $(e.target).data("focus-control-refid");
            $("[data-validation-alias-control='" + focusControl + "']").focus();
            $(e.target).data("focus-control-refid", "");
        }
    });

    $("#ManageAadhaarNumber").on("change", function () {
        var aadhaarNumber = $("#ManageAadhaarNumber").val();
        if (aadhaarNumber != "") {
            if (aadhaarNumber.length == 12) {
                $("#AadhaarVerificationStatusId").val("Yet to be verified");
            }
            else {
                $("#AadhaarVerificationStatusId").val("Not Provided");
            }
        } else {
            $("#AadhaarVerificationStatusId").val("Not Provided");
        }
        $("#AadhaarVerificationStatus").val($("#AadhaarVerificationStatusId").text());
    });

    $("#ManageMobileNumber").on("change", function () {

        var mobileNo = $("#ManageMobileNumber").val();
        if (mobileNo.length == 10) {
            // $("#btnGenerateResendOTP").text("Generate OTP");
            $("#MobileOTPVerificationStatusId").val("Yet to be verified");
            $("#MobileOTPVerificationStatus").val($("#MobileOTPVerificationStatusId").text());
            $("#ErrorMessageForMobileNumber").hide();
            OTPClear();
        }
        if (mobileNo.length == 0) {
            // $("#btnGenerateResendOTP").text("Generate OTP");
            $("#MobileOTPVerificationStatusId").val("Not Provided");
            $("#MobileOTPVerificationStatus").val($("#MobileOTPVerificationStatusId").text());
            OTPClear();
        }
    });

    $("#txtAadhaarNumber").on("change", function () {
        var aadhaarNumber = $("#txtAadhaarNumber").val();
        if (aadhaarNumber != "") {
            if (aadhaarNumber.length == 12) {
                $("#AadhaarStatusIdForEdit").val("Yet to be verified");
            }
            else {
                $("#AadhaarStatusIdForEdit").val("Not Provided");
            }
        } else {
            $("#AadhaarStatusIdForEdit").val("Not Provided");
        }
        //  $("#AadhaarVerificationStatus").val($("#AadhaarStatusIdForEdit").text());
    });

    $("#txtMobileNumber").on("change", function () {

        var mobileNo = $("#txtMobileNumber").val();
        if (mobileNo.length == 10) {
            // $("#btnGenerateResendOTP").text("Generate OTP");
            $("#MobileOTPStatusForEdit").val("Yet to be verified");
            $("#validationMessageForMobileNumber").hide();
            //    $("#MobileOTPVerificationStatus").val($("#MobileOTPStatusForEdit").text());
            OTPClearEdit();
        }
        if (mobileNo.length == 0) {
            // $("#btnGenerateResendOTP").text("Generate OTP");
            $("#MobileOTPStatusForEdit").val("Not Provided");
            //    $("#MobileOTPVerificationStatus").val($("#MobileOTPStatusForEdit").text());
            OTPClearEdit();
        }
    });

    $("#ContactNameLocation").on("change", function () {
        $("#validationMessageForName").hide();
    });

    $("#ddlGender").on("change", function () {
        if ($("#ddlGender").val() != '-1') {
            $("#validationMessageForGender").hide();
        }
    });
});

var EditManageContactForm = function () {

    var isValid = mandatoryFieldCheckEditContact();
    if (isValid) {
        var ObjmanageContact = {
            ContactName: $('#ContactNameLocation').val(),
            Gender: $('#ddlGender').val(),
            AadhaarNumber: $('#txtAadhaarNumber').val(),
            AadhaarVerificationStatus: $('#AadhaarStatusIdForEdit').val(),
            MobileNumber: $('#txtMobileNumber').val(),
            Designation: $('#txtDesignation').val(),
            EnterOTP: $('#txtenterOtp').val(),
            StdCode: $('#txtStdCode').val(),
            MobileOTPVerificationStatus: $('#MobileOTPStatusForEdit').val(),
            LandlineNumber: $('#txtLandlineNumber').val(),
            EmailAddress: $('#txtEmailAddress').val(),
            ManageContactID: $('#txtManageContactId').val(),
            Type: "U",
        };
        if (email_id_idvalidate("txtEmailAddress")) {

            $.ajax({
                type: "POST",
                url: EditUrl,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ viewModel: ObjmanageContact }),
                dataType: "json",
                success: function (data) {
                    if (data != null && data.Status == 'Failure') {
                        $("#alertmsg").text(data.InfoMessage);
                        $("#alertValidationPopup").show();
                    }
                    else if (data != null && data.IsSuccess == 'Update') {
                        $("#alertmsg").text("Manage Contact Updated Successfully.");
                        $("#alertValidationPopup").show();
                        //$("#divCoursePartialView").hide();
                        $('#clspop').hide();
                        ClearAll()
                    }
                    else {
                        $("#alertmsg").text("Some Error ir Occurred, Please try after some time.");
                        $("#alertValidationPopup").show();
                        $("#divLoading").hide();
                    }
                    contactlist();
                },
                error: function (result) {
                    $("#divLoading").hide();
                    $(this).find("input[type=submit]").prop("disabled", false);
                }
            });
        }
    }
}

var mandatoryFieldCheck = function () {
    var isCustomValidationValid = true;
    if ($("#ContactNameLocation").val() === "") {
        $("#ErrorMessageForName").show();
        isCustomValidationValid = false;
    }
    else {
        $("#ErrorMessageForName").hide();
    }

    if ($("#ManageMobileNumber").val() === "") {
        $("#ErrorMessageForMobileNumber").show();
        isCustomValidationValid = false;
    }
    else {
        $("#ErrorMessageForMobileNumber").hide();
    }

    if ($("#ManageEmailAddress").val() === "") {
        $("#ErrorMessageForEmail").show();
        isCustomValidationValid = false;
    }
    else {
        $("#ErrorMessageForEmail").hide();
    }

    if ($("#AddBatchGender").val() === '-1') {
        $("#ErrorMessageForGender").show();
        isCustomValidationValid = false;
    }
    else {
        $("#ErrorMessageForGender").hide();
    }

    return isCustomValidationValid;
};

var mandatoryFieldCheckEditContact = function () {
    var isCustomValidationValid = true;
    $("#validationMessageForName").hide();
    $("#validationMessageForGender").hide();
    $("#validationMessageForMobileNumber").hide();
    $("#validationMessageForEmail").hide();

    if ($("#ContactNameLocation").val() === "") {
        $("#validationMessageForName").show();
        isCustomValidationValid = false;
    } else {
        $("#validationMessageForName").hide();
    }

    if ($("#ddlGender :selected").val() === "-1") {
        $("#validationMessageForGender").show();
        isCustomValidationValid = false;
    } else {
        $("#validationMessageForGender").hide();
    }

    if ($("#txtMobileNumber").val() === "") {
        $("#validationMessageForMobileNumber").show();
        isCustomValidationValid = false;
    } else {
        $("#validationMessageForMobileNumber").hide();
    }
    if ($("#txtEmailAddress").val() === "") {
        $("#validationMessageForEmail").show();
        isCustomValidationValid = false;
    } else {
        $("#validationMessageForEmail").hide();
    }
    return isCustomValidationValid;
};

var ClearAll = function () {
    // this for the Insert
    $('#ContactNameLocation').val('');
    $('#ManageAadhaarNumber').val('');
    $('#AadhaarVerificationStatus').val('Not Provided');
    $('#AadhaarVerificationStatusId').val('Not Provided');
    $('#ManageMobileNumber').val('');
    $('#Designation').val('');
    $('#EnterOTP').val('');
    $('#MobileOTPVerificationStatus').val('Not Provided');
    $('#MobileOTPVerificationStatusId').val('Not Provided');
    $('#StdCode').val('');
    $('#LandlineNumber').val('');
    $('#ManageEmailAddress').val('');
    $('#AddBatchGender').find('option[value="' + 0 + '"]').attr('selected', 'selected');
    $('#AddBatchGender').prop('selectedIndex', -1);
    $(".selectpicker").selectpicker("refresh");
    //$("select[name='Gender']").val(0);

    $("#ManageMobileNumber").attr("disabled", false);
    $("#ManageAadhaarNumber").attr("disabled", false);
    $("#txtMobileNumber").attr("disabled", false);
    $("#txtAadhaarNumber").attr("disabled", false);


    // this for the Update
    $('#ContactNameLocation').val('');
    $('#txtAadhaarNumber').val('');
    $('#AadhaarStatusIdForEdit').val('Not Provided');
    $('#txtMobileNumber').val('');
    $('#txtDesignation').val('');
    $('#txtenterOtp').val('');
    $('#MobileOTPStatusForEdit').val('Not Provided');
    $('#txtStdCode').val('');
    $('#txtLandlineNumber').val('');
    $('#ddlGender').find('option[value="' + 0 + '"]').attr('selected', 'selected');

}

var submitManageContactForm = function () {
    debugger
    var ObjmanageContact = {
        PartnerID:$('#PartnerID').val(),
        ContactName: $('#ContactNameLocation').val(),
        Gender: $('#AddBatchGender').val(),
        AadhaarNumber: $('#ManageAadhaarNumber').val(),
        AadhaarVerificationStatus: $('#AadhaarVerificationStatusId').val(),
        MobileNumber: $('#ManageMobileNumber').val(),
        Designation: $('#Designation').val(),
        EnterOTP: $('#EnterOTP').val(),
        MobileOTPVerificationStatus: $('#MobileOTPVerificationStatusId').val(),
        StdCode: $('#StdCode').val(),
        LandlineNumber: $('#LandlineNumber').val(),
        EmailAddress: $('#ManageEmailAddress').val(),
        Type: 'I',
    };
    if (email_id_idvalidate("ManageEmailAddress")) {
        if (ObjmanageContact != null && ObjmanageContact.MobileNumber != "" && ObjmanageContact.EmailAddress != "" && ObjmanageContact.Gender != "-1") {
            $.ajax({
                type: "POST",
                url: saveUrl,
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ viewModel: ObjmanageContact }),
                dataType: "json",
                success: function (data) {
                    if (data != null && data.Status == 'Failure') {
                        $("#divLoading").hide();
                        $("#alertmsg").text(data.InfoMessage);
                        $("#alertValidationPopup").show();
                        $('#ManageEmailAddress').focus();
                    }
                    else if (data != null && data.IsSuccess == 'Success') {
                        $("#divLoading").hide();
                        //alertModel("Contact is created successfully. Login details are sent to contact's email id.");
                        alertModel("Contact is created successfully");
                        ClearAll();
                        $('#divManageContact').modal('hide');
                    }
                    else {
                        $("#divLoading").hide();
                        $("#alertmsgSuccess").text("Some Error ir Occurred, Please try after some time.");
                        $("#alertpopup").show();
                    }
                    contactlist();
                    return;
                },
                error: function (result) {
                    $("#divLoading").hide();
                    $(this).find("input[type=submit]").prop("disabled", false);
                }
            });
        }
        else {
            $("#divLoading").hide();
            $("#alertmsg").text("Please Enter/Select All Mandatory Fields");
            $("#alertValidationPopup").show();
        }
    }
}

function AadharValidationCheck() {
    $("#divLoading").show();
    var url = $("#btnVerifyAadhaar").data("action-url");
    var aadhaarNumber = $("#ManageAadhaarNumber").val();
    var contactName = $("#ContactNameLocation").val();

    var gender = $("#AddBatchGender").find("option:selected").text();

    if (aadhaarNumber != "" && contactName != "" && gender != "Select") {
        if (aadhaarNumber.length == 12) {
            //   $("#divLoading").show();
            $("#btnVerifyAadhaar").attr("disabled", true);

            $.ajax({
                type: "GET",
                url: url,
                contentType: "json",

                data: { AadharNumber: aadhaarNumber, ContactName: contactName, Gender: gender },
                success: function (data) {
                    JSON.stringify(data);
                    if (data == "Authentication Successfull.") {
                        $("#btnVerifyAadhaar").removeAttr("disabled");
                        $("#Aadhar_timer").text("");
                        $("#AadhaarVerificationStatusId").val("Successful");
                        $("#nGender").val($("#AddBatchGender").val());
                        $("#tDateofBirth").val($("#DateofBirth").val());
                        $("#tYearofBirth").val($("#YearofBirth").val());
                        $("#ContactNameLocation").attr("readonly", true);
                        $("#ManageAadhaarNumber").attr("readonly", true);
                        $("#AddBatchGender").attr("disabled", "disabled");

                        $("#btnVerifyAadhaar").attr("disabled", "disabled");

                        $("#alertmsg").text("Aadhaar verification is successful.");
                        $("#alertValidationPopup").show();
                    }
                    else {
                        var str = "Authentication Failed. Reason:Identity data mismatch  - code:100";
                        var str1 = "Authentication Failed. Reason:Invalid Aadhaar Number Aadhaar number is incorrect. Resident shall use correct Aadhaar. - code:998";
                        if (data.indexOf(str1) !== -1) {
                            $("#AadhaarVerificationStatusId").val("Failure");
                            $("#alertmsg").text("Aadhaar verification failed. Reason:Invalid Aadhaar Number Aadhaar number is incorrect. Resident shall use correct Aadhaar.");
                            $("#alertValidationPopup").show();
                            $("#divLoading").hide();
                        }
                        else if (data.indexOf(str) !== -1) {
                            $("#AadhaarVerificationStatusId").val("Failure");
                            $("#alertmsg").text("Aadhaar verification failed. Please check contact Name, Gender.");
                            $("#alertValidationPopup").show();
                            $("#divLoading").hide();
                        }
                        else {
                            $("#AadhaarVerificationStatusId").val("Yet to be verified");
                            $("#alertmsg").text(data);
                            $("#alertValidationPopup").show();
                        }

                        $("#btnVerifyAadhaar").removeAttr("disabled");
                        clearTimeout(OTPTimer1);
                        $("#Aadhar_timer").text("");
                        $("#ContactNameLocation").attr("readonly", false);
                        $("#ManageAadhaarNumber").attr("readonly", false);
                        $("#AddBatchGender").removeAttr("disabled");

                    }
                    $("#AadhaarVerificationStatus").val($("#AadhaarVerificationStatusId").val());
                    $("#divLoading").hide();
                },
                error: function (x, e) {
                    $("#alertmsg").text("The call to the server side failed." + x.responseText);
                    $("#alertValidationPopup").show();
                    $("#divLoading").hide();
                }
            });
        }
        else {
            $("#alertmsg").text("Aadhaar Number should be 12 digit");
            $("#alertValidationPopup").show();
        }
    }
    else {

        $("#alertmsg").text("Aadhaar Number, Contact Name, Gender are mandatory for Aadhaar Number Check");
        $("#alertValidationPopup").show();
        $("#divLoading").hide();
    }
}

function GetMobileOTP() {
    var url = $("#otpurl").data("action-url");
    var mobileNo = $("#ManageMobileNumber").val();
    if (mobileNo.length == 10) {
        $("#EnterOTP").val("");
        $("#btngenerateresendotp").attr("disabled", true);
        $("#divLoading").show();
        //c();
        $.ajax({
            type: "GET",
            url: url,
            contentType: "json",
            data: { MobileNo: mobileNo, MsgBody: "" },
            success: function (data) {
                JSON.stringify(data);
                if (data == "Success") {
                    $("#btnGenerateResendOTP").removeAttr("disabled");
                    $("#btnGenerateResendOTP").text("Resend OTP");
                    $("#s_timer").text("");
                    $("#alertmsg").text("Mobile OTP Successfully sent");
                    $("#alertValidationPopup").show();
                }
                else {
                    $("#btnGenerateResendOTP").removeAttr("disabled");
                    $("#btnGenerateResendOTP").text("Resend OTP");
                    $("#s_timer").text("");
                    $("#alertmsg").text("Mobile OTP Failed to send");
                    $("#alertValidationPopup").show();
                }
                $("#divLoading").hide();
            },
            error: function (x, e) {
                $("#alertmsg").text("The call to the server side failed." + x.responseText);
                $("#alertValidationPopup").show();
                $("#divLoading").hide();
            }
        });
    }
    else {
        $("#alertmsg").text("Mobile Number should be 10 digit");
        $("#alertValidationPopup").show();
        $("#ManageMobileNumber").focus();
    }
}

function EnterOTPCheck(enterOTP) {
    var url = $(".eotp").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { EnterOTP: enterOTP },
        success: function (data) {
            JSON.stringify(data);
            if (data == true) {
                $("#MobileOTPVerificationStatusId").val("Successful");
                $("#btnGenerateResendOTP").attr("disabled", "disabled");
                $("#ManageMobileNumber").attr("readonly", true);
                $("#EnterOTP").attr("readonly", true);
            }
            else {
                $("#MobileOTPVerificationStatusId").val("Failure");
                $("#btnGenerateResendOTP").removeAttr("disabled");
                $("#ManageMobileNumber").attr("readonly", false);
                $("#EnterOTP").attr("readonly", false);
            }
            $("#MobileOTPVerificationStatus").val($("#MobileOTPVerificationStatusId").val());
            //$(".selectpicker").selectpicker("refresh");
            //$(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertValidationPopup").show();
            $("#divLoading").hide();
        }
    });
}

function modifyContactDetails(obj) {
    var manageContactId = $(obj).attr("id");
    var UserID = $('#CreatedBy').val();
    $.ajax({
        url: GetEditContactUrl,
        contentType: "application/json; charset=utf-8",
        data: { userID: UserID, manageContactID: manageContactId },
        async: true,
        type: "GET",
        datatype: "html",
        success: function (data) {
            if (data.length != 0) {
                $("#divCoursePartialView").html(data);
                $('#clspop').show();
            }
        }
    });

}

function contactlist() {
    $('#ContactData').DataTable().destroy();
    var UserID = $('#CreatedBy').val();;
    var dataTabOptions = {
        "processing": true,
        "serverSide": true,
        "autoWidth": true,
        "paging": true,
        "lengthMenu": [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
        "pageLength": 5,
        "searching": false,
        "ajax": {
            "url": GetAllContactUrl,
            "type": "POST",
            "datatype": "json",
            "data": { "userID": UserID, "manageContactID": null },
        },
        'columnDefs': [{
            'targets': 0,
            'searchable': false,
            'orderable': true

        }],
        'order': [[1, 'asc']],
        columns: [{ title: "Contact Name", "data": "ContactName", "name": "ContactName" },
               //{ title: "Contact ID", "data": "ManageContactID" , },
               { title: "Email Address", "data": "EmailAddress" },
               { title: "Mobile Number", "data": "MobileNumber" },
               { title: "Aadhaar Number", "data": "AadhaarNumber" },
                {
                    title: "", "render": function (data, type, full, meta) {
                        return '<a  href="#" id=" ' + full.ManageContactID + '" onclick="modifyContactDetails(this)">Edit</a>';
                    }
                }],
    }
    $('#ContactData').DataTable(dataTabOptions);
}

function AadharValidation() {

    var TempValue = $('#ManageAadhaarNumber').val();
    var mm = TempValue.replace(/ +/g, "");
    $('#ManageAadhaarNumber').val(mm);
    var aadharNo = $('#ManageAadhaarNumber').val();
    if (aadharNo.length > 0 && aadharNo.length !== 12) {

        $('#AadhaarNumberSpan').show();
        $('#alertmsg').text('Please enter 12 Digit Aadhar Number');
        $('#alertValidationPopup').show();
        $('#ManageAadhaarNumber').focus();
        return false;
    }
    else {
        $('#AadhaarNumberSpan').hide();
    }
}

function AadharValidationCheckForEdit() {
    var TempValue = $('#txtAadhaarNumber').val();
    var mm = TempValue.replace(/ +/g, "");
    $('#txtAadhaarNumber').val(mm);
    var aadharNo = $('#txtAadhaarNumber').val();
    if (aadharNo.length > 0 && aadharNo.length !== 12) {
        $('#alertmsg').text('Please enter 12 Digit Aadhar Number');
        $('#alertValidationPopup').show();
        $('#txtAadhaarNumber').focus();
        return false;
    }
    else {
        //$('#AadhaarNumberSpan').hide();
    }
}

function AadharValidationStatusCheckForEdit() {
    $("#divLoading").show();
    var url = $("#btnVerifyAadhaar1").data("action-url");
    var aadhaarNumber = $("#txtAadhaarNumber").val();
    var contactName = $("#ContactNameLocation").val();
    var gender = $("#ddlGender").find("option:selected").text();
    if (aadhaarNumber != "" && contactName != "" && gender != "Select") {
        if (aadhaarNumber.length == 12) {
            $("#btnVerifyAadhaar1").attr("disabled", true);
            $.ajax({
                type: "GET",
                url: url,
                contentType: "json",

                data: { AadharNumber: aadhaarNumber, ContactName: contactName, Gender: gender },
                success: function (data) {
                    JSON.stringify(data);
                    if (data == "Authentication Successfull.") {
                        $("#btnVerifyAadhaar1").removeAttr("disabled");
                        $("#AadhaarStatusIdForEdit").val("Successful");
                        $("#ContactNameLocation").attr("readonly", true);
                        $("#txtAadhaarNumber").attr("readonly", true);
                        $("#ddlGender").attr("disabled", "disabled");
                        $("#btnVerifyAadhaar1").attr("disabled", "disabled");
                        $("#alertmsg").text("Aadhaar verification is successful.");
                        $("#alertValidationPopup").show();
                    }
                    else {
                        var str = "Authentication Failed. Reason:Identity data mismatch  - code:100";
                        var str1 = "Authentication Failed. Reason:Invalid Aadhaar Number Aadhaar number is incorrect. Resident shall use correct Aadhaar. - code:998";
                        if (data.indexOf(str1) !== -1) {
                            $("#AadhaarStatusIdForEdit").val("Failure");
                            $("#alertmsg").text("Aadhaar verification failed. Reason:Invalid Aadhaar Number Aadhaar number is incorrect. Resident shall use correct Aadhaar.");
                            $("#alertValidationPopup").show();
                            $("#divLoading").hide();
                        }
                        else if (data.indexOf(str) !== -1) {
                            $("#AadhaarStatusIdForEdit").val("Failure");
                            $("#alertmsg").text("Aadhaar verification failed. Please check contact Name, Gender.");
                            $("#alertValidationPopup").show();
                            $("#divLoading").hide();
                        }
                        else {
                            $("#AadhaarStatusIdForEdit").val("Yet to be verified");
                            $("#alertmsg").text(data);
                            $("#alertValidationPopup").show();
                        }

                        $("#btnVerifyAadhaar1").removeAttr("disabled");
                        clearTimeout(OTPTimer1);
                        $("#Aadhar_timer").text("");
                        $("#ContactNameLocation").attr("readonly", false);
                        $("#txtAadhaarNumber").attr("readonly", false);
                        $("#ddlGender").removeAttr("disabled");

                    }
                    $("#AadhaarVerificationStatus").val($("#AadhaarStatusIdForEdit").val());
                    $("#divLoading").hide();
                },
                error: function (x, e) {
                    $("#alertmsg").text("The call to the server side failed." + x.responseText);
                    $("#alertValidationPopup").show();
                    $("#divLoading").hide();
                }
            });
        }
        else {
            $("#alertmsg").text("Aadhaar Number should be 12 digit");
            $("#alertValidationPopup").show();
        }
    }
    else {

        $("#alertmsg").text("Aadhaar Number, Contact Name, Gender are mandatory for Aadhaar Number Check");
        $("#alertValidationPopup").show();
        $("#divLoading").hide();
    }
}

function GetMobileOTPForEdit() {
    var url = $("#otpUrlforEdit").data("action-url");
    var mobileNo = $("#txtMobileNumber").val();
    if (mobileNo.length == 10) {
        $("#txtenterOtp").val("");
        $("#btnGenerateOTPForEdit").attr("disabled", true);
        $("#divLoading").show();
        //c();
        $.ajax({
            type: "GET",
            url: url,
            contentType: "json",
            data: { MobileNo: mobileNo, MsgBody: "" },
            success: function (data) {
                JSON.stringify(data);
                if (data == "Success") {
                    $("#btnGenerateOTPForEdit").removeAttr("disabled");
                    $("#btnGenerateOTPForEdit").text("Resend OTP");
                    //clearTimeout(OTPTimer);
                    $("#s_timer").text("");
                    $("#alertmsg").text("Mobile OTP Successfully sent");
                    $("#alertValidationPopup").show();
                }
                else {
                    $("#btnGenerateOTPForEdit").removeAttr("disabled");
                    $("#btnGenerateOTPForEdit").text("Resend OTP");
                    // clearTimeout(OTPTimer);
                    $("#s_timer").text("");
                    $("#alertmsg").text("Mobile OTP Failed to send");
                    $("#alertValidationPopup").show();
                }
                $("#divLoading").hide();
            },
            error: function (x, e) {
                $("#alertmsg").text("The call to the server side failed." + x.responseText);
                $("#alertValidationPopup").show();
                $("#divLoading").hide();
            }
        });
    }
    else {
        $("#alertmsg").text("Mobile Number should be 10 digit");
        $("#alertValidationPopup").show();
        $("#txtMobileNumber").focus();
    }
}

function EnterOTPCheckEdit(enterOTP) {
    var url = $(".eotp").data("action-url");
    $("#divLoading").show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        // url:url,
        data: { EnterOTP: enterOTP },
        success: function (data) {
            JSON.stringify(data);
            if (data == true) {
                $("#MobileOTPStatusForEdit").val("Successful");

                $("#btnGenerateOTPForEdit").attr("disabled", "disabled");

                $("#txtMobileNumber").attr("readonly", true);
                $("#txtenterOtp").attr("readonly", true);
            }
            else {
                $("#MobileOTPStatusForEdit").val("Failure");
                $("#btnGenerateOTPForEdit").removeAttr("disabled");
                $("#txtMobileNumber").attr("readonly", false);
                $("#txtenterOtp").attr("readonly", false);
            }
            $("#MobileOTPVerificationStatus").val($("#MobileOTPStatusForEdit").val());
            //$(".selectpicker").selectpicker("refresh");
            //$(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
            $("#divLoading").hide();
        },
        error: function (x, e) {
            //alert("The call to the server side failed. " + x.responseText);
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertValidationPopup").show();
            $("#divLoading").hide();
        }
    });
}

//Email ID Validation-------
function email_id_idvalidate(id) {
    var sEmail = $("#" + id).val();
    var filter = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);

    if (sEmail.length > 0 && !filter.test(sEmail)) {
        $("#alertmsg").text("Please enter Correct E-Mail ID");
        $("#alertValidationPopup").show();
        $("#TraineeEmailAddress").focus();
        return false;
    }
    else
        $("#ErrorMessageForEmail").hide();
    return true;
}

function RemoteServerValidationEmail(id, controlType) {
    var controlValue = $('#' + id).val()
    var CalledBy = 'Manage Contact';
    var serverValidationPass = true;
    var validationSpanMsg = 'is already used by';
    if (controlValue !== "" && controlType !== "") {
        $("#divLoading").show();
        $.ajax({
            type: "GET",
            url: validationUrl,
            contentType: "json",
            async: true,
            dataType: "json",
            data: { controlValue: controlValue, controlType: controlType, CalledBy: CalledBy },
            success: function (data) {
                if (data.length > 0) {
                    var msg = controlType + " " + validationSpanMsg + " " + data[0].tDisplayName + "-" + data[0].nIndex;
                    $("#alertmsg").text(msg);
                    $("#alertValidationPopup").show();
                    serverValidationPass = false;
                }
                $("#divLoading").hide();
                return serverValidationPass;
            },
            error: function (x, e) {
                //alert("The call to the server side failed. " + x.responseText);
                $("#alertmsg").text("The call to the server side failed.");
                console.log("The call to the server side failed." + x.responseText);
                $("#alertValidationPopup").show();
                $("#divLoading").hide();
                serverValidationPass = false;
                return serverValidationPass;
            }
        });
    } else {
        return serverValidationPass;
    }
}

function mobile_idvalidate() {
    var inputVal1 = $("#ManageMobileNumber").val();
    var Value = inputVal1.replace(/^0+/, "");
    $("#ManageMobileNumber").val(Value);

    var numericReg = new RegExp("^\[0-9]{10}$");

    var inputVal = $("#ManageMobileNumber").val();

    if (inputVal1.length > 0 && !numericReg.test(inputVal)) {

        $("#alertmsg").text("Please enter 10 Digit Mobile Number");
        $("#alertValidationPopup").show();
        $("#ManageMobileNumber").focus();
        return false;
    }
    else {

    }
}

function OTPClear() {
    var url = $(".motps").data("action-url");
    //$('#divLoading').show();
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        success: function (data) {
            JSON.stringify(data);
        },
        error: function (x, e) {
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertValidationPopup").show();
            //$('#divLoading').hide();
        }
    });
}

function OTPClearEdit() {
    var url = $(".motpEdit").data("action-url");
    $.ajax({
        type: "GET",
        url: url,
        contentType: "json",
        async: true,
        success: function (data) {
            JSON.stringify(data);
        },
        error: function (x, e) {
            $("#alertmsg").text("The call to the server side failed." + x.responseText);
            $("#alertValidationPopup").show();
        }
    });
}

function sortTable() {
    $("table").trigger("destroy");
    $('table').tablesorter({
    });
}

function closeModelManageContact() {
    $("#divManageContact").modal('hide');
}
