﻿
function getPlacementTraingCenterDetails() {
    debugger
    if ($("#ddlTrainingType").val() != '') {
        var dataToSend = { tringTypeID: $("#ddlTrainingType").val(), verificationStatusID: $("#ddlVerficationStatus").val() }
        $.ajax({
            type: "GET",
            cache: false,
            url: GetPlacementTCDetails,
            contentType: 'application/json; charset=utf-8',
            async: true,
            data: dataToSend,
            success: function (data) {
                debugger
                $("#divTCDetails").html(data);
                $('#tblTCDetails').DataTable().destroy();
                $('#tblTCDetails').DataTable(
                    {
                        "PagingType": "full_numbers",
                        "searching": false,
                        "lengthChange": false,
                    }
                    );
            },
            error: function (x, e) {
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    else {
        alertModel("Please select Training type");
    }
}

function getPlacementBatchDetails() {
    debugger
    var dataToSend = { locationID: $("#hdnLocationID").val(), fromDate: $("#AssessmentStartDate").val(), todate: $("#AssessmentEndDate").val(), traingTypeID: $("#ddlTrainingType").val(), statusID: $("#ddlVerficationStatus").val() }
    $.ajax({
        type: "GET",
        cache: false,
        url: GetPlacemetBatchDetails,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: dataToSend,
        success: function (data) {
              $("#divBatchDetails").html(data);
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}

function GetCandidateDetailByID() {
    var dataToSend = { batchID: $("#hdnBatchID").val(), candID: $("#ddlCandidate").val(), locationID: $("#hdnLocationID").val() };
    $.ajax({
        type: "POST",
        cache: false,
        url: GetCandidateDetailsByID,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: JSON.stringify(dataToSend),
        success: function (data) {
            $("#divPlacementDetails").html(data.PartialCandidateEmploymentModelList);
            $("#divPostPlacementEligible").html(data.PartialPostPlacementEligible);
            $("#lblGender").html(data.CandEnrolment.Gender);
            $("#lblDateofBirth").html(data.CandEnrolment.DateofBirth);
            $("#lblBatchAssesmentDate").html(data.CandEnrolment.BatchAssessmentDate);
        },
        error: function (x, e) {
            debugger
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}

function SubmitVerificationStatus(status) {
    debugger
    var errorMsg = '';
    if (status == "Reject") {
        if ($("#ddlReasonID").val() == "") {
            errorMsg = "Please select Reason";
           
        }
        if ($("#ddlReasonID :selected").text() == "Other") {
            if ($("#txtOtherDesc").val() == "") {
                if (errorMsg == "")
                    errorMsg = "Please enter other Reason";
                else
                    errorMsg = errorMsg + "<br/> Please enter other Reason";
            }
        }
    }
    if (errorMsg == "") {
        var dataToSend = {EmploymentDetailID: $("#hdnEmploymentDetailID").val(), ReasonID: $("#ddlReasonID").val(), OtherDisription: $("#txtOtherDesc").val() };
        $.ajax({
            type: "POST",
            cache: false,
            url: SubmitCandidateVerification,
            contentType: 'application/json; charset=utf-8',
            async: true,
            data: JSON.stringify(dataToSend),
            success: function (data) {
                if(data.status=="Success")
                    alertModel("Employment status updated Successfully");
                else
                    alertModel("Some Error is Occurred, Please try after some time");
            },
            error: function (x, e) {
                debugger
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    else {
        alertModel(errorMsg);
    }
}


