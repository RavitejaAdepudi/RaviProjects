﻿
///*
// * date created: 2017-02-17
// * ver201610180115
// * Created by Prashanth.
// */
$(document).ready(function () {
    $("[data-id='JobRole']").searchableOptionList();
    $("[data-id='LocationJobRole']").searchableOptionList();
    var tblSearchPIA = "#tblSearchPIA";
    var activeSearchClass = ".activeSearchClass";
    var activeSearch = "activeSearch";
    $(tblSearchPIA).on("click", "tr", function () {
        $(".activeSearchClass").removeClass(activeSearch);
        $(this).toggleClass(activeSearch);
        $(this).find("input[type='radio']").prop("checked", true);
    });

    $("#buttonLogoFilter").on("click", function () {
        var filterVal = $("#txtFilter").val();
        var logotype = $("#LogoSelected").val();
        var logoNo = $("#LogoNumber").val();
        debugger;
        filterVal = filterVal == "" ? "null" : filterVal;

        if (filterVal != "" && typeof filterVal !== 'undefined') {
            var $panelToFill = $("#searchTablePanel");
            var dataToSend = { logoType: logotype, filterText: filterVal, controllToAssign: logoNo }
            partialViewLoader(GetSearchCustomTemplatePartial, dataToSend, $panelToFill);
        }
        else {
            alertModel("Please enter some text to filter");
        }
    });

    $("#certificateLogoTable").on("click", "tr", function () {
        $(".activeSearchClass").removeClass(activeSearch);
        $(this).toggleClass(activeSearch);
        $("#certificateLogoTable").find('input').removeAttr('checked');
        $(this).find("input[type='radio']").prop("checked", true);
    });
    $("#certificateLogoTable").on("click", "input", function () {
        $("#certificateLogoTable").find('input').removeAttr('checked');
        $(this).prop("checked", true);
    });

    $("#ddlCustomTemplate").change(function () {
        fillPartial();
    });
 
});

//$("#SPIALocationForm").submit(function (event) {
//    alert("Handler for .submit() called.");
//    event.preventDefault();
//});

///required functions 

function selectLogo() {
    debugger;
    var assetId;
    var ctrlToFill = $("#selectLogo").data("idattr");
    var assetCtrlTofill = $("#selectLogo").data("assetattr");
    var srcFiletofill = $("#selectLogo").data("srcfile");

    var imgSrc;
    var isChecked;
    var logoNumber = $("#LogoNumber").val();
    var logoName = $("#LogoSelected").val();

    $('#certificateLogoTable').find('tr').each(function () {
        var row = $(this);
        if (row.find('input[type="radio"]').is(':checked')) {
            assetId = row.find('td input[type=hidden]').val();
            imgSrc = $("#path" + assetId).val();
            isChecked = true;
        }
    });
    if (isChecked == true) {
        $("#" + ctrlToFill).attr("src", imgSrc);
        $("#" + assetCtrlTofill).val(assetId);
        $("#" + srcFiletofill).val(imgSrc);

        var index = parseInt($("#" + srcFiletofill).data('index'));
        var type = $("#" + srcFiletofill).data('type');
        var id = type === "G" ? "#GovtPos" : "#CorpPos";
        var pos = $("#" + srcFiletofill).data('position');
        $(id+index).val(pos);

        $("#divsearchLogo").modal('hide');
    }
    else {
        alertModel('Please select Logo');
    }
}
$.fn.serializeObject = function() {
    var o = {};
    var a = this.serializeArray();
    $.each(a,
         function() {
             if (o[this.name]) {
                 if (!o[this.name].push) {
                     o[this.name] = [o[this.name]];
                 }
                 o[this.name].push(this.value || '');
             } else {
                 o[this.name] = this.value || '';
             }
         });
    return o;
};

function dropdownEmptyOptionFiller (controlToFill) {
    var emptyOption = "<option value=\"-1\" data-hidden=\"true\">Select</option>";
    controlToFill.html(emptyOption);
}
function customTemplateDropDownFiller() {
    $.ajax({
        type: "GET",
        url: GetCustomTemplateList,
        contentType: "json",
        async: true,
        data: {},
        success: function (data) {
            $("#ddlCustomTemplate").html("");
            var options = "";
            $.each(data,
                function (key, value) {
                    if (value.nIndex === -1)
                        options += "<option value=\"" + value.Id + "\" data-hidden=\"true\">" + value.CustomType + "</option>";
                    else
                        options += "<option " +
                                   "data-govtlogocount=\"" + value.GovtLogoCount +
                                   "\" data-corporatelogocount=\"" + value.CorporateLogoCount +
                                   "\" data-position=\"" + value.Position + "\" value=\"" + value.Id + "\">" + value.CustomType + "</option>";
                });
            $("#ddlCustomTemplate").html(options);
        },
        error: function (x, e) {
        },
        complete: function () {
            $(".selectpicker").selectpicker("refresh");
            
        }
    });
}
function selectPIA() {
    var PartnerID = '';
    var PartnerName = '';
    var isChecked = false;
    $('#tblSearchPIA').find('tr').each(function () {
        var row = $(this);
        if (row.find('input[type="radio"]').is(':checked')) {
            PartnerID = row.find('td input[type=hidden]').val();
            PartnerName = row[0].cells[2].innerHTML;
            isChecked = true;
        }
    });
    if (isChecked == true) {
        $("#TrainingPartnerID").val(PartnerID);
        $("#AccountID").val(PartnerID);
        $("#TrainingPartner").val(PartnerName);
        $('#divPIASelect').modal('hide');
    }
    else {
        alertModel('Please select PIA');
    }
}

$(function () {
    // initialize sol
    $("[data-id='JobRole']").searchableOptionList();
    $("[data-id='LocationJobRole']").searchableOptionList();
});
var jobRoleSelectionValidation = function () {
    $("[data-id='JobRole']").off();
    $("[data-id='ProjectJobRole']").change(function () {
        var $form = $(this).closest("form");
        var jobroleCodes = [];
        var sectorIds = [];
        $("option:selected", this).each(function (i, selected) {
            jobroleCodes[i] = $(selected).data("jobrole-code");
            sectorIds[i] = $(selected).data("sector-id");
        });

        $form.find("[data-id='JobRoleCode']").text(jobroleCodes.join(", "));
        $form.find("[data-id='SectorID']").val(sectorIds.join(", "));
        var $errorMsgControl = $form.find("[data-id='validationMessageForJobRole']");
        var selected = $("option:selected", this).length;
        if (selected < 1) {
            $errorMsgControl.show();
        } else {
            $errorMsgControl.hide();
        }
        $(".selectpicker").selectpicker("refresh");
        $(".selectpicker").parents("form:first").validate().settings.ignore = ":not(select:hidden, input:visible, textarea:visible)";
    });
};

$("#chkHasBridgeCourse").change(function () {
    if (this.checked) {
        $("#txtBridgeCourseDuration").prop("disabled", false);
        $("#txtBridgeCourseDuration").val(0);
        $('#txtBridgeCourseDiscount').prop('disabled', false);
        $('#txtBridgeCourseDiscount').val(0);
    }
    else {
        $("#txtBridgeCourseDuration").prop("disabled", true);
        $("#txtBridgeCourseDuration").val(0);
        $('#txtBridgeCourseDiscount').prop('disabled', true);
        $('#txtBridgeCourseDiscount').val(0);
    }
});

function ValidateFile(event) {
    var controlId = event.target.id;
    var control = $("#" + controlId);
    var validFilesTypes = [".png", ".jpg", ".jpeg", ".pdf"];
    var ext = "";

    if ($(control).length > 0) {
        if ($(control)[0].files[0].size > 524288) {
            $(control).replaceWith($(control).clone(true));
            alertModel("File Size should not exceeds 500 kb.");
            $("#CustomTemplateLogo").val("");
            return false;
        } else {
            var file = $(control)[0].files[0];
            var fileName = file.name;
            ext = "." + fileName.split(".").pop();
            ext = ext.toLowerCase();

            var isValidFile = false;
            for (var i = 0; i < validFilesTypes.length; i++) {
                if (ext == validFilesTypes[i]) {
                    isValidFile = true;
                    break;
                }
            }
            if (!isValidFile) {
                $(control).val("");
                alertModel("Invalid File Format");
                return false;
            }
            else {
                return true;
            }
        }
    }
    else {
        alertModel("No documents found. Please upload your document.");
        return false;
    }
}

//$("#SPIALocationForm").submit(function (event) {
//    event.preventDefault();
//    var $form = $(this);
//    var url = $form.attr('action');
//    $.ajax({
//        type: "POST",
//        url: url,
//        data: $(this).serialize(), // serializes the form's elements.
//        success: function (data, status, request) {
//            debugger
//            if (data.Status == 'Success') {
//                //$("#divLocationJobRoleTarget").html(data.locationJobRoleResult);
//                //$("#divProjectJobRoleTarget").html(data.projectJobRolePartail);
//                //$("#divAddLocation").modal('hide');
//                alertModel("Project Details Saved Successfully");
//            }
//            else if (data.Status == 'Exists') {
//                alertModel("This Project Name is already exists, Please Enter diffrent Project Name");
//            }
//            else if (data.Status == 'Failure') {
//                 alertModel("Unable to save Location, Please try after sometime.");
//            }
//            else {
//                alertModel(data.InfoMessage);
//            }
//        },
//        beforeSend: function (xhr) {
//            $("#divLoading").show();
//        },
//        complete: function () {
//            $("#divLoading").hide();
//        },
//        error: function (xhr, ajaxOptions, thrownError) {
//            $("#divLoading").hide();
//        }
//    });

//});
function formSubmit() {

    //var validator = $("#SPIALocationForm").validate();
    //if(!$('#SPIALocationForm').valid()){
    //    var submitErrorsList = new Object();
    //    for (var i=0;i<validator.errorList.length;i++){
    //        submitErrorsList[validator.errorList[i].element.name] = validator.errorList[i].message;
    //    }
    //}

    $("#CertificateTemplate").val($('#ddlCertificateTemplate :selected').text());
    $("#ProjectType").val($("#ddlProject :selected").text());
    $("#SPIALocationForm").submit();
}

function addLocationJobRole() {
    debugger
    var locationID = $('#ddlLocationNameList').val();
    if (locationID != "") {
        var selectedlocations = [];
        var selectedlocationsText = [];

        $("#JobRoleLocation :selected").each(function () {
            selectedlocations.push($(this).val());
            selectedlocationsText.push($(this).text() + ',');
        });
        var dataToSend = { LocationID: locationID, LocationName: $("#ddlLocationNameList :selected").text(), SelectedJobRoleList: selectedlocations, SelectedJobRolesNames: selectedlocationsText.toString() };
        $.ajax({
            type: "POST",
            url: AddProjectLocationJobRole,
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(dataToSend),
            success: function (data) {
                if (data.length != 0) {
                    if (data == 'Exists') {
                        alertModel("This Job Role Id is already selected. Please select another");
                    }
                    else {
                        $("#dvViewLocation").html(data);
                    }
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alertModel("Some Error is Occurred, Please try after some time");
            }
        });
    }
    else {
        alertModel("Please select Location");
    }
}
function removeLocation(id) {
    $.ajax({
        type: "GET",
        url: RemoveProjectLocationJobRole,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { locationID: id },
        success: function (data) {
            if (data.length != 0) {
                $("#dvViewLocation").html(data);
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function addProjectJobRole() {
    //bala
    debugger;
    if (document.getElementById('chkHasBridgeCourse')) {
        if ($('#chkHasBridgeCourse')[0].checked) {
            var bridgeCourseDuration = $('#txtBridgeCourseDuration').val();
            var bridgeCourseDiscount = $('#txtBridgeCourseDiscount').val();
            if (bridgeCourseDuration == '0' && bridgeCourseDiscount == '0') {
                alertModel('Please enter Either BridgeCourseDuration or BridgeCourseDiscount');
                return;
            }
        }
    }
    var projectJobRoleTarget = $("#ProjectJobRoleTarget").val();
    if (projectJobRoleTarget != "" && projectJobRoleTarget != undefined) {
        var sectorID = $('#ddlSector').val();
        var errorMessage = "";
        if (sectorID == "") {
            errorMessage = "Please select the Sector";
            errorMessage += "</br>";
        }
        if ($('#ddlProjectJobRole').val() == "") {
            errorMessage += "Please select the JobRole";
            errorMessage += "</br>";
        }
        if ($('#txtProjectJobRoleTarget').val().toString().trim() == "") {
            errorMessage += "The Target Field is required";
            errorMessage += "</br>";
        }
        if ($('#txtBridgeCourseDuration').val() != "") {
            if (parseInt($('#txtBridgeCourseDuration').val()) > parseInt($("#BridgeCourseHours").val())) {
                errorMessage += "The Bridge Course Duration Hours Should not be greater than " + $("#BridgeCourseHours").val();
                errorMessage += "</br>";
            }
        }
        if (parseInt($('#ProjectJobRoleTarget').val()) <= 0) {
            errorMessage += "Project Job Role Target should be greater than zero";
            errorMessage += "</br>";
        }
        if (parseInt($('#txtProjectJobRoleTarget').val()) <= 0) {
            errorMessage += "Job Role Details Target should be greater than zero";
            errorMessage += "</br>";
        }
        if (errorMessage == "") {
            var target = 0;
            $('#tblLocationJobRole').find('tr').each(function () {
                var row = $(this);
                var trainingType = $('#TrainingType').val().trim();
                if (trainingType == 'RPL') {
                    if (row[0].cells[2] != undefined) {
                        if (!isNaN(row[0].cells[2].innerHTML)) {
                            target += parseInt(row[0].cells[2].innerHTML);
                        }
                    }
                }
                else {
                    if (row[0].cells[5] != undefined) {
                        if (!isNaN(row[0].cells[5].innerHTML)) {
                            target += parseInt(row[0].cells[5].innerHTML);
                        }
                    }
                }
            });
            target += parseInt($("#txtProjectJobRoleTarget").val());
            if (parseInt(target) <= parseInt(projectJobRoleTarget)) {
                var sectorName = $('#ddlSector option:selected').text();
                var projectJobRoleID = $('#ddlProjectJobRole').val();
                var projectJobRoleName = $('#ddlProjectJobRole option:selected').text();
                var projectTarget = $('#txtProjectJobRoleTarget').val();
                var hasBridgeCourse = $('#chkHasBridgeCourse').is(':checked');
                var bridgeCourseDuration = $('#txtBridgeCourseDuration').val();
                var bridgeCourseDiscount = $('#txtBridgeCourseDiscount').val();

                var resu;

                var dataToSend = {
                    JobroleID: projectJobRoleID,
                    selectedJobRoleText: projectJobRoleName,
                    SectorID: sectorID,
                    Sector: sectorName,
                    JobRoleTarget: projectTarget,
                    HasBridgeCourse: hasBridgeCourse,
                    BridgeCourseDuration: bridgeCourseDuration,
                    BridgeCourseDiscount: bridgeCourseDiscount
                }
                $.ajax({
                    type: "POST",
                    url: AddProjectJobRole,
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(dataToSend),
                    success: function (data) {
                        if (data.length != 0) {
                            if (data == 'Exists') {
                                alertModel("This Job Role is already selected. Please select another");
                            }
                            else {
                                if ($("#TrainingType").val() == "RPL") {
                                    $("#dvRPLProjectJobRole").html(data);
                                }
                                else {
                                    $("#dvProjectJobRole").html(data);
                                    $("#txtProjectJobRoleTarget").val('');
                                    $("#ddlProjectJobRole").val('');
                                    $("#ddlSector").val('');
                                }
                                $("#txtProjectJobRoleTarget").val('');
                                $("#ddlProjectJobRole").val('');
                                $("#ddlSector").val('');
                                $("#txtBridgeCourseDuration").val('');
                                $("#txtBridgeCourseDuration").prop('disabled', true);
                                $('#chkHasBridgeCourse').prop('checked', false);
                                var projectJobRole = '<option value="">Select</option>';
                                $('#ddlProjectJobRole').html(projectJobRole);
                                var ddlSector = '<option value="">Select</option>';
                                $('#ddlSector').html(ddlSector);
                                $('#ddlSectorType').val('');
                                $('#txtBridgeCourseDiscount').val('');
                                $('#txtBridgeCourseDiscount').prop('disabled', true);
                            }
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alertModel("Some Error is Occurred, Please try after some time");
                    }
                });
            }
            else {
                alertModel("Job Role Target Should not Exceed Project Target");
            }
        }
        else {
            alertModel(errorMessage);
        }
    }
    else {
        alertModel("Please Select Project Target");
        $("#ProjectJobRoleTarget").focus();
    }
}
function removeProject(id) {
    $.ajax({
        type: "GET",
        url: RemoveProjectJobRole,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { jobRoleID: id },
        success: function (data) {
            if (data.length > 0) {
                if ($("#TrainingType").val() == "RPL") {
                    $("#dvRPLProjectJobRole").html(data);
                }
                else {
                    $("#dvProjectJobRole").html(data);
                }
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function getEndDate() {
    var duration = $("#ProjectDuration").val();
    var startDate = new Date($('#txtFromDate').val());
    if (duration != null || duration != undefined)
        var endDate = new Date(startDate.getDate(), startDate.getMonth() + duration, startDate.getFullYear());
    $("#EndDate").val(endDate);
}
function getPIADetails() {
    $.ajax({
        type: "GET",
        url: GetPIADetails,
        contentType: 'application/json; charset=utf-8',
        async: true,
        cache: false,
        data: { piaName: $("#txtPIAName").val() },
        success: function (data) {
            if (data.length > 0) {
                $("#dvTraingPartnerList").html(data);
                //$('#tblSearchPIA').DataTable({ "pagingType": "full_numbers" });
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function clearTPInsert() {
    $("#txtPartnerName").val('');
    $("#txtSPOCName").val('');
    $("#txtSPOCEmail").val('');
    $("#txtSPOCMobile").val('');
}


//function addPIADetails() {
//    var dataToSend = { PartnerName: $("#txtPartnerName").val(), SPOCName: $("#txtSPOCName").val(), SPOCEmail: $("#txtSPOCEmail").val(), SPOCMobile: $("#txtSPOCMobile").val() };
//    $.ajax({
//        type: "GET",
//        url: CreatePIA,
//        contentType: 'application/json; charset=utf-8',
//        async: true,
//        data: dataToSend,
//        success: function (data) {
//            if (data.length > 0) {
//                if (data == 'Successfully Updated') {
//                    alertModel('PIA Details has been successfully inserted');
//                }
//                else {
//                    alertModel("SPOC Mobile Number Or SPOC Email already exists, Please enter another");
//                }
//            }
//        },
//        error: function (x, e) {
//            alertModel("Some Error is Occurred, Please try after some time");
//        }
//    });
//}

function getSectorBySectorType() {
    $.ajax({
        type: "GET",
        url: GetSectorBySectorType,
        cache: false,
        contentType: 'application/json; charset=utf-8',
        async: false,
        data: { sectorTypeID: $("#ddlSectorType").val() },
        success: function (data) {
            var appenddata = "<option value=''> Select </option>";
            if (data.length > 0) {
                $.each(data, function (key, value) {
                    appenddata += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
                });
                $('#ddlSector').html(appenddata);
                $('.selectpicker').selectpicker('refresh');
            }
            else {
                $('#ddlSector').html(appenddata);
                $('#ddlProjectJobRole').html(appenddata);
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}

function getJobRoleBySector() {
    $.ajax({
        type: "GET",
        url: GetJobRoleBySector,
        cache: false,
        contentType: 'application/json; charset=utf-8',
        async: false,
        data: { sectorID: $("#ddlSector").val(), SectorTypeID: $("#ddlSectorType").val() },
        success: function (data) {
            var appenddata = "<option value=''> Select </option>";
            if (data.length > 0) {
                $.each(data, function (key, value) {
                    appenddata += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
                });
                $('#ddlProjectJobRole').html(appenddata);
                $('.selectpicker').selectpicker('refresh');
            }
            else {
                $('#ddlProjectJobRole').html(appenddata);
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function getSectorByJobRoleType() {
    $.ajax({
        type: "GET",
        url: GetJobRoleBySector,
        contentType: 'application/json; charset=utf-8',
        cache: false,
        async: true,
        data: { sectorID: $("#ddlSector").val() },
        success: function (data) {
            if (data.length > 0) {
                var appenddata = "<option value=''> Select </option>";
                $.each(data, function (key, value) {
                    appenddata += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
                });
                $('#ddlProjectJobRole').html(appenddata);
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function getDisbursementModeByPlacement() {
    $.ajax({
        type: "GET",
        url: GetDisbursementModeByPlacement,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { placementID: $("#ddlIsDisbursement").val() },
        success: function (data) {
            if (data.length > 0) {
                var appenddata = "<option value=''> Select </option>";
                $.each(data, function (key, value) {
                    appenddata += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
                });
                $('#ddlDisbursement').html(appenddata);
                $('.selectpicker').selectpicker('refresh');
            }
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function monthDiff(start, end) {
    var months;
    months = (end.getFullYear() - start.getFullYear()) * 12;
    months -= start.getMonth() + 1;
    months += end.getMonth();
    return months <= 0 ? 0 : months;
}
function calcDays() {
    var start = $("#StartDate").datepicker("getDate");
    var end = $("#EndDate").datepicker("getDate");
    if (start > end) {
        alertModel('End Date should be greater than Start Date');
        $("#EndDate").val('');
    } else {
        var months;
        months = (end.getFullYear() - start.getFullYear()) * 12;
        months -= ((start.getMonth()) + 1);
        months += (end.getMonth());
        $("#ProjectDuration").val(months + 1 <= 0 ? 0 : months + 1);
    }

    //monthDiff(start, end)
    //if (start != undefined && end != undefined) {
    //    days = (end - start) / (1000 * 60 * 60 * 24);
    //    $("#ProjectDuration").val(Math.round(days));
    //}
}




