﻿

$('#ddlTrainingType').on('change', function () {
    $('#ProjectsContent').hide();
});

function getProjectTypeByTrainingType() {
    $.ajax({
        type: "GET",
        url: GetProjectTypeByTrainingType,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { trainingType: $("#ddlTrainingType :selected").text() },
        success: function (data) {
            var appenddata = "<option value=''> Select </option>";
            $.each(data, function (key, value) {
                appenddata += '<option value="' + value.nIndex + '">' + value.tDisplayName + '</option>';
            });
            $("#ddlProjectType").html(appenddata);
            $('.selectpicker').selectpicker('refresh');
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function getJobRoleBySector() {
    $.ajax({
        type: "GET",
        url: GetJobRoleBySector,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { sectorID: $("#ddlSector").val() },
        success: function (data) {
            var appenddata = "<option value=''> Select </option>";
            if (data.length > 0) {
                $.each(data, function (key, value) {
                    appenddata += "<option value=\"" + value.nIndex + "\">" + value.tDisplayName + "</option>";
                });
            }
            $('#ddlProjectJobRole').html(appenddata);
            $('.selectpicker').selectpicker('refresh');
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}


function getProjectDetails() {
    if ($("#ddlTrainingType").val() != "") {
        $.ajax({
            type: "GET",
            cache: false,
            url: GetProjectList,
            data: { trainingTypeID: $("#ddlTrainingType").val(), partnerID: $("#TrainingPartnerID").val(), projectTypeID: $("#ddlProjectType").val(), sectorID: $("#ddlSector").val(), jobRoleID: $("#ddlProjectJobRole").val(), trainingTypeName: $("#ddlTrainingType :selected").text() },
            contentType: 'json',
            success: function (data) {
                if (data.length > 0) {
                    $("#divProjectDetails").html(data);
                }
                $('#projectslist').DataTable().destroy();
                $('#projectslist').DataTable(
                    {
                        "PagingType": "full_numbers",
                        "searching": false,
                        "lengthChange": false
                    });
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alertModel("Some Error is Occurred, Please try after some time");
                $('#projectslist').DataTable().destroy();
                $('#projectslist').DataTable(
                    {
                        "PagingType": "full_numbers",
                        "searching": false,
                        "lengthChange": false
                    });
            }
        });
    }
    else {
        alertModel("Please Select Training Type");
    }
}

$(document).ready(function () {
    $('#ProjectsContent').hide();
});

$('#ProjectPartner').on('click', function () {
    $.ajax({
        type: "GET",
        contentType: 'application/json; charset=utf-8',
        async: false,
        url: urlprojectpartnerdetails,
        success: function (state) {
            $('#dvViewProject').html(state);
            $('#clspopup1').find('#dvViewProject').html(state);
            $('#clspopup1').show();
        }
    });
});

function getPIADetails() {
    $.ajax({
        type: "GET",
        url: GetPIADetails,
        contentType: 'application/json; charset=utf-8',
        async: true,
        data: { piaName: $("#txtPIAName").val() },
        success: function (data) {
            if (data.length > 0) {
                $("#dvTraingPartnerList").html(data);
            }
            $('#projectslist').DataTable().destroy();
            $('#projectslist').DataTable(
                {
                    "PagingType": "full_numbers",
                    "searching": false,
                    "lengthChange": false
                });
        },
        error: function (x, e) {
            alertModel("Some Error is Occurred, Please try after some time");
        }
    });
}
function viewProjectDetails(projectID, trainingTypeID) {
    if (projectID != "" && trainingTypeID != "") {
        $.ajax({
            type: "GET",
            contentType: 'application/json; charset=utf-8',
            async: true,
            cache: false,
            url: urlprojectprojectdetails,
            data: { projectid: projectID, trainingtypeid: trainingTypeID },
            success: function (data) {
                $('#dvViewProject_View').html(data);
                $("#clspopup2").show();
                // $('#divViewProjectDetails').modal({ backdrop: 'static', keyboard: false, show: true });
            }
        });
    }
}
function selectPIA() {
    var PartnerID = '';
    var PartnerName = '';
    var isChecked = false;
    $('#tblSearchPIA').find('tr').each(function () {
        var row = $(this);
        if (row.find('input[type="radio"]').is(':checked')) {
            PartnerID = row.find('td input[type=hidden]').val();
            PartnerName = row[0].cells[2].innerHTML;
            isChecked = true;
        }
    });
    if (isChecked == true) {
        $("#TrainingPartnerID").val(PartnerID);
        //$("#AccountID").val(PartnerID);
        $("#TrainingPartner").val(PartnerName);
        $('#divPIASelect').modal('hide');
    }
    else {
        alertModel('Please select PIA');
    }
}

function manageTargetDetails(projectID, trainingtypeid, trainingTypeName, isSubmittedToPmu) {
    if (trainingTypeName == 'RPL' || isSubmittedToPmu == 'true') {
        if (projectID != "" && trainingtypeid != "") {
            window.location.href = getTargetAllocation + "?trainingtypeid=" + trainingtypeid + "&projectid=" + projectID + "&trainingTypeName=" + trainingTypeName
        }
    }
    else {
        alertModel("SPIA Profile details are not filled yet. We have sent a reminder mail to SPIA to fill the profile details.");
    }
}
//Partial View Filter Button Click Function
function getPartnerSpocDetails() {
    $('#Partialspocdetails').hide();
    $("#divLoading").show();
    var tempname = $('#PartnerNames').val(); //$('#ProjectsContent tr td').eq(1).text();
    if (tempname != "") {
        $.ajax({
            type: "GET",
            contentType: 'application/json; charset=utf-8',
            async: true,
            url: urlprojectpartnernamedetails,
            data: { partnername: tempname },
            success: function (state) {
                $("#divLoading").hide();
                $('#dvViewProject').html(state);
                $('#clspopup1').show();
                $('#Partialspocdetails').show();

                if ($('#Viewpartnererror').val() != "") {
                    $('#clspopup').find('.ary_surecont_yes').text("No recors Found for TP name Entered");
                    $('#clspopup').show();
                    $('#Partialspocdetails').hide();
                }
            }
        });
    }
    else {
        $("#divLoading").hide();
        $('#ProjectsContent').hide();
        $('#clspopup').find('.ary_surecont_yes').text("Please Enter Partner Name");
        $('#clspopup').show();
    }
}

function formProjectSubmit() {
    if ($("#ddlTrainingType").val() != '') {
        var tempttype = $("#ddlTrainingType :selected").text();
        $('#ProjectsTrainingType').val(tempttype);

        try {
            $("#ProjectsModel").submit();
        } catch (e) {
            console.log(e.description);
        }
    }
    else {
        alertModel('Please Select Training Type');
    }
}

function clearProjectDetails() {
    $("#TrainingPartnerID").val(0);
    $("#ddlTrainingType,#TrainingPartner,#ddlProjectType,#ddlSector,#ddlProjectJobRole").val('');
    var appenddata = "<option value=''> Select </option>";
    var appenddata1 = "<option value=''> Select </option>";
    $("#ddlProjectJobRole").html(appenddata);
    $("#ddlProjectType").html(appenddata1);
}


