Date.isLeapYear = function (year) { 
    return (((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0)); 
};

Date.getDaysInMonth = function (year, month) {
    return [31, (Date.isLeapYear(year) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
};

Date.prototype.isLeapYear = function () { 
    return Date.isLeapYear(this.getFullYear()); 
};

Date.prototype.getDaysInMonth = function () { 
    return Date.getDaysInMonth(this.getFullYear(), this.getMonth());
};

Date.prototype.addMonths = function (value) {
    var n = this.getDate();
    this.setDate(1);
    this.setMonth(this.getMonth() + value);
    this.setDate(Math.min(n, this.getDaysInMonth()));
    return this;
};

$(function () {
	var x = new Date();
	var year= x.getFullYear();
	var month = x.getMonth();
	var day = x.getDate()-1;
function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
  return new Date(d.setDate(diff));
}
var holidays= ["2016/12/13", "2017/01/26"];

var firstDayOfWeek = getMonday(new Date()); // Mon Nov 08 2010
var lastDayOfWeek = getMonday(new Date());
    lastDayOfWeek.addDays(4);
	var thisMonthFirstDay = new Date(year, month, 1);
	var thisMonth = new Date(year, month, 1);
	var firstDayof4thMonth = thisMonth.addMonths(3);
	var lastDayof3rdMonth = new Date(firstDayof4thMonth);
	lastDayof3rdMonth.addDays(-1);

	//console.log(lastDayof3rdMonth);
		
	//$('.3-calendars').pickmeup({
	//	flat		: true,
	//	date		: [
	//		firstDayOfWeek,
	//		lastDayOfWeek
	//	],
	//	select_month: false,
	//	select_year: false,
	//	mode		: 'range',
	//	calendars	: 3,
	//	min: thisMonthFirstDay,
	//	max: lastDayof3rdMonth,
	//	render : function (date) {

	//		for (var i = 0; i < holidays.length; i++) {
			
    //        if (new Date(holidays[i]).toString() === date.toString()) {
    //             return {class_name : 'holiday-date'};
    //        }
    //    }
	//}
	//});
});
